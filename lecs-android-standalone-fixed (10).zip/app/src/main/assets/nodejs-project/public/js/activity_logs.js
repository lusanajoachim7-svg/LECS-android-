let currentPage = 1;
let totalPages = 1;

function escapeHtml(s){
return String(s || "").replace(/[&<>"']/g, c => ({
"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"
}[c]));
}

async function loadLogs(){

try{

    const search =
    document.getElementById("search")
    ? document.getElementById("search").value
    : "";

    const res =
    await fetch(
        `/api/activity-logs?page=${currentPage}&limit=50&search=${encodeURIComponent(search)}`
    );

    const result =
    await res.json();

    const table =
    document.getElementById("logsTable");

    if(!table) return;

    table.innerHTML = "";

    if(!result.data || result.data.length === 0){

        table.innerHTML = `
        <tr>
            <td colspan="4">Hakuna logs zilizopatikana</td>
        </tr>
        `;

    }else{

        result.data.forEach(log => {

            table.innerHTML += `
            <tr>
                <td>${escapeHtml(log.username || "-")}</td>
                <td>${escapeHtml(log.action || "-")}</td>
                <td>${escapeHtml(log.description || "-")}</td>
                <td>${new Date(log.created_at).toLocaleString()}</td>
            </tr>
            `;

        });

    }

    document.getElementById("totalLogs").innerText =
    result.totalRows || 0;

    totalPages = result.totalPages || 1;

    const pageInfo =
    document.getElementById("pageInfo");

    if(pageInfo){
        pageInfo.innerText = `Page ${currentPage} of ${totalPages}`;
    }

}catch(err){

    console.error(err);

}

}

function searchLogs(){

    currentPage = 1;
    loadLogs();

}

function nextPage(){

    if(currentPage < totalPages){
        currentPage++;
        loadLogs();
    }

}

function previousPage(){

    if(currentPage > 1){
        currentPage--;
        loadLogs();
    }

}

document.addEventListener("DOMContentLoaded", loadLogs);
