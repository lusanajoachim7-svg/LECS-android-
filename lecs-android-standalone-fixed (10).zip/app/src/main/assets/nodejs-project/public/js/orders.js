let currentOrder = null; // { id, supplier_id, jumla_order, kiasi_kilicholipwa, kiasi_baki }

function fmt(n){
    return Number(n || 0).toLocaleString("en-US");
}

async function loadSuppliers(){

    try{

        const res = await fetch("/api/orders/suppliers");
        const data = await res.json();

        const select = document.getElementById("supplier");
        if(!select) return;

        select.innerHTML = "";

        data.forEach(item=>{
            select.innerHTML += `<option value="${item.id}">${item.jina}</option>`;
        });

    }catch(err){
        console.error(err);
    }

}

async function anzaOrder(){

    try{

        const supplier_id = document.getElementById("supplier").value;

        if(!supplier_id){
            alert("Chagua supplier kwanza.");
            return;
        }

        const res = await fetch("/api/orders", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ supplier_id, jumla_order: 0, kiasi_kilicholipwa: 0 })
        });

        const data = await res.json();

        if(!res.ok || data.success === false){
            alert(data.message || "Imeshindikana kuanza order.");
            return;
        }

        currentOrder = {
            id: data.id,
            supplier_id,
            jumla_order: 0,
            kiasi_kilicholipwa: 0,
            kiasi_baki: 0
        };

        document.getElementById("newOrderCard").style.display = "none";
        document.getElementById("itemsCard").style.display = "block";
        document.getElementById("payBox").style.display = "none";
        document.getElementById("payResult").innerText = "";
        renderItems([]);
        renderSummary();
        loadOrdersHistory();

    }catch(err){
        alert("Hitilafu: " + err.message);
    }

}

async function ongezaBidhaa(){

    if(!currentOrder){
        alert("Anza order kwanza.");
        return;
    }

    const bidhaa_jina = document.getElementById("itemJina").value.trim();
    const idadi = Number(document.getElementById("itemIdadi").value || 0);
    const bei_kununua = Number(document.getElementById("itemBei").value || 0);

    if(!bidhaa_jina || idadi <= 0 || bei_kununua <= 0){
        alert("Jaza jina, idadi, na bei sahihi.");
        return;
    }

    try{

        const res = await fetch("/api/orders/item", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                order_id: currentOrder.id,
                bidhaa_jina,
                idadi,
                bei_kununua
            })
        });

        const data = await res.json();

        if(!res.ok || data.success === false){
            alert(data.message || "Imeshindikana kuongeza bidhaa.");
            return;
        }

        currentOrder.jumla_order = data.jumla_order;
        currentOrder.kiasi_baki = data.kiasi_baki;

        document.getElementById("itemJina").value = "";
        document.getElementById("itemIdadi").value = "";
        document.getElementById("itemBei").value = "";

        await loadItems();
        renderSummary();
        loadOrdersHistory();

    }catch(err){
        alert("Hitilafu: " + err.message);
    }

}

async function loadItems(){

    if(!currentOrder) return;

    try{

        const res = await fetch("/api/orders/items/" + currentOrder.id);
        const rows = await res.json();
        renderItems(rows);

    }catch(err){
        console.error(err);
    }

}

function renderItems(rows){

    const tbody = document.getElementById("itemsTable");

    if(!rows || rows.length === 0){
        tbody.innerHTML = `<tr><td colspan="4">Bado hakuna bidhaa</td></tr>`;
        return;
    }

    tbody.innerHTML = rows.map(r => `
        <tr>
            <td>${escapeHtml(r.bidhaa_jina)}</td>
            <td>${r.idadi}</td>
            <td>${fmt(r.bei_kununua)}</td>
            <td>${fmt(r.jumla)}</td>
        </tr>
    `).join("");

}

function escapeHtml(s){
    return String(s || "").replace(/[&<>"']/g, c => ({
        "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
    }[c]));
}

function renderSummary(){
    if(!currentOrder) return;
    document.getElementById("summaryJumla").innerText = fmt(currentOrder.jumla_order);
    document.getElementById("summaryPaid").innerText = fmt(currentOrder.kiasi_kilicholipwa);
    document.getElementById("summaryBaki").innerText = fmt(currentOrder.kiasi_baki);
}

function openPayBox(){
    if(!currentOrder){
        alert("Anza order kwanza.");
        return;
    }
    document.getElementById("payBox").style.display = "flex";
}

function jazaKiasiChote(){
    if(!currentOrder) return;
    document.getElementById("malipo").value = currentOrder.kiasi_baki;
}

async function lipaOrder(){

    if(!currentOrder) return;

    const amount = Number(document.getElementById("malipo").value || 0);
    const resultEl = document.getElementById("payResult");

    if(amount <= 0){
        resultEl.innerText = "Weka kiasi sahihi.";
        return;
    }

    try{

        const res = await fetch("/api/payments", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                supplier_id: currentOrder.supplier_id,
                order_id: currentOrder.id,
                kiasi: amount
            })
        });

        const data = await res.json();

        if(!res.ok || data.success === false){
            resultEl.innerText = data.message || "Malipo yameshindikana.";
            return;
        }

        currentOrder.kiasi_kilicholipwa = data.kiasi_kilicholipwa;
        currentOrder.kiasi_baki = data.kiasi_baki;

        renderSummary();
        document.getElementById("malipo").value = "";
        resultEl.innerText = "✅ Malipo yamefanikiwa. Deni Litakalobaki: " + fmt(data.kiasi_baki);
        loadOrdersHistory();

    }catch(err){
        resultEl.innerText = "Hitilafu: " + err.message;
    }

}

function orderNyingine(){
    currentOrder = null;
    document.getElementById("newOrderCard").style.display = "block";
    document.getElementById("itemsCard").style.display = "none";
    document.getElementById("payResult").innerText = "";
    loadSuppliers();
}

async function loadOrdersHistory(){

try{

const res = await fetch("/api/orders?limit=20");
const data = await res.json();

const tbody = document.getElementById("ordersHistoryTable");
if(!tbody) return;

const rows = data.data || [];

if(rows.length === 0){
tbody.innerHTML = `<tr><td colspan="6">Bado hakuna orders</td></tr>`;
return;
}

tbody.innerHTML = rows.map(o => `
<tr>
<td>${escapeHtml(o.supplier_name || "-")}</td>
<td>${fmt(o.jumla_order)}</td>
<td>${fmt(o.kiasi_kilicholipwa)}</td>
<td>${fmt(o.kiasi_baki)}</td>
<td>${escapeHtml(o.status || "-")}</td>
<td>${(o.created_at || "").slice(0,10)}</td>
</tr>
`).join("");

}catch(err){
console.error(err);
const tbody = document.getElementById("ordersHistoryTable");
if(tbody) tbody.innerHTML = `<tr><td colspan="6">Imeshindikana kupakia historia</td></tr>`;
}

}

function escapeHtml(s){
return String(s || "").replace(/[&<>"']/g, c => ({
"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"
}[c]));
}

document.addEventListener("DOMContentLoaded", () => {
loadSuppliers();
loadOrdersHistory();
setInterval(loadOrdersHistory, 6000);
});
