function fedha(n){

return Number(n || 0)
.toLocaleString("en-US");

}

function escapeHtml(s){
return String(s || "").replace(/[&<>"']/g, c => ({
"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"
}[c]));
}

Chart.register(
ChartDataLabels
);

let charts = {};

function createChart(
canvasId,
type,
label,
labels,
values
){

if(charts[canvasId]){

    charts[canvasId]
    .destroy();

}

charts[canvasId] =
new Chart(

    document.getElementById(
        canvasId
    ),

    {

        type:type,

        data:{

            labels:labels,

            datasets:[{

                label:label,

                data:values,

                borderWidth:3,

                borderRadius:12,

                tension:.4,

                fill:false

            }]

        },

        options:{

            responsive:true,

            maintainAspectRatio:false,

            animation:{
                duration:1500
            },

            plugins:{

                legend:{
                    display:true
                },

                tooltip:{
                    callbacks:{
                        label:(ctx)=>
                        fedha(
                            ctx.raw
                        )
                    }
                },

                datalabels:{

                    color:"#ffffff",

                    formatter:(v)=>
                    fedha(v),

                    anchor:"end",

                    align:"top"

                }

            }

        }

    }

);

}

async function loadTopProducts(){

try{

    const res =
    await fetch(
        "/api/reports/top-products"
    );

    const data =
    await res.json();

    const table =
    document.getElementById(
        "topProductsTable"
    );

    if(!table) return;

    table.innerHTML = "";

    data.data.forEach(item=>{

        table.innerHTML += `
        <tr>

            <td>
                ${escapeHtml(item.jina)}
            </td>

            <td>
                ${item.totalSold}
            </td>

            <td>
                ${fedha(
                    item.totalSales
                )}
            </td>

        </tr>
        `;

    });

}catch(err){

    console.log(err);

}

}

async function loadLowStock(){

try{

    const res =
    await fetch(
        "/api/reports/low-stock"
    );

    const data =
    await res.json();

    const table =
    document.getElementById(
        "lowStockTable"
    );

    if(!table) return;

    table.innerHTML = "";

    data.data.forEach(item=>{

        table.innerHTML += `
        <tr>

            <td>
                ${escapeHtml(item.jina)}
            </td>

            <td class="low-stock">
                ${item.idadi}
            </td>

        </tr>
        `;

    });

}catch(err){

    console.log(err);

}

}

async function loadReports(){

try{

    const res =
    await fetch(
        "/api/reports"
    );

    const data =
    await res.json();

    document.getElementById(
        "mauzoMwaka"
    ).innerText =
    fedha(
        data.mauzoMwaka
    );

    document.getElementById(
        "mauzoWiki"
    ).innerText =
    fedha(
        data.mauzoWiki
    );

    document.getElementById(
        "mauzoMwezi"
    ).innerText =
    fedha(
        data.mauzoMwezi
    );

    document.getElementById(
        "faidaWiki"
    ).innerText =
    fedha(
        data.faidaWiki
    );

    document.getElementById(
        "faidaMwezi"
    ).innerText =
    fedha(
        data.faidaMwezi
    );

    document.getElementById(
        "faidaMwaka"
    ).innerText =
    fedha(
        data.faidaMwaka
    );

    createChart(
        "weeklySalesChart",
        "line",
        "Weekly Sales",
        data.weeklySales.labels,
        data.weeklySales.values
    );

    createChart(
        "weeklyProfitChart",
        "line",
        "Weekly Profit",
        data.weeklyProfit.labels,
        data.weeklyProfit.values
    );

    createChart(
        "monthlySalesChart",
        "bar",
        "Monthly Sales",
        data.monthSales.labels,
        data.monthSales.values
    );

    createChart(
        "monthlyProfitChart",
        "bar",
        "Monthly Profit",
        data.monthProfit.labels,
        data.monthProfit.values
    );

    createChart(
        "yearlySalesChart",
        "bar",
        "Yearly Sales",
        data.yearSales.labels,
        data.yearSales.values
    );

    createChart(
        "yearlyProfitChart",
        "bar",
        "Yearly Profit",
        data.yearProfit.labels,
        data.yearProfit.values
    );

    await loadTopProducts();

    await loadLowStock();

}catch(err){

    console.error(err);

    alert(
        "Imeshindikana kupakia reports"
    );

}

}

function exportPDF(){

window.open(
    "/api/reports/export/pdf",
    "_blank"
);

}

function exportExcel(){

window.open(
    "/api/reports/export/csv",
    "_blank"
);

}

/* =====================
SEARCH REPORTS BY DATE
===================== */

async function searchReport(){

try{

    const date =
    document.getElementById(
        "reportDate"
    ).value;

    const url =
    date
    ? `/api/reports/sales-by-date?date=${encodeURIComponent(date)}`
    : "/api/reports/sales-by-date";

    const res =
    await fetch(url);

    const result =
    await res.json();

    const table =
    document.getElementById(
        "salesDateTable"
    );

    if(!table) return;

    if(!result.data || result.data.length === 0){

        table.innerHTML = `
        <tr>
            <td colspan="3">Hakuna mauzo tarehe hii</td>
        </tr>
        `;

        return;

    }

    table.innerHTML =
    result.data.map(item => `
        <tr>
            <td>${escapeHtml(item.mteja_jina || "-")}</td>
            <td>${fedha(item.jumla)}</td>
            <td>${new Date(item.created_at).toLocaleString()}</td>
        </tr>
    `).join("");

}catch(err){

    console.error(err);

}

}

setInterval(
loadReports,
30000
);

document.addEventListener(
"DOMContentLoaded",
() => {

    const dateInput =
    document.getElementById("reportDate");

    if(dateInput){
        dateInput.value =
        new Date().toISOString().split("T")[0];
    }

    loadReports();
    searchReport();

}
);