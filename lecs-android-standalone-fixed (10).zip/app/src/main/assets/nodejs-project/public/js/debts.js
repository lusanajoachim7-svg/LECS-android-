function escapeHtml(s){
return String(s || "").replace(/[&<>"']/g, c => ({
"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"
}[c]));
}

async function loadDebts(){

try{

const res =
await fetch(
"/api/orders/debts"
);

const data =
await res.json();

const table =
document.getElementById(
"debtTable"
);

if(!table) return;

table.innerHTML = "";

if(!data.length){

table.innerHTML = `
<tr>
<td colspan="5">
Hakuna madeni
</td>
</tr>
`;

return;

}

data.forEach(item=>{

table.innerHTML += `
<tr>

<td>${escapeHtml(item.supplier_name || "-")}</td>

<td>${item.jumla_order || 0}</td>

<td>${item.kiasi_kilicholipwa || 0}</td>

<td>${item.kiasi_baki || 0}</td>

<td>${escapeHtml(item.status || "-")}</td>

</tr>
`;

});

}catch(err){

console.error(err);

}

}

document.addEventListener(
"DOMContentLoaded",
loadDebts
);