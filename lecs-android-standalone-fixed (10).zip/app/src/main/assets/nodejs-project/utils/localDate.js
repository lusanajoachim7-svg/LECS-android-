/**
 * True local-time date boundaries, computed in JavaScript.
 *
 * Why this exists: sql.js (the WASM build of SQLite this app uses,
 * see database/db.js) has no real timezone database. SQLite's own
 * `DATE('now','localtime')` / `strftime(...,'now')` silently behave
 * like UTC in this environment. Since East Africa Time is UTC+3, that
 * shifted every "today" / "this week" / "this month" boundary by 3
 * hours — sales made late evening could land on the wrong day, and
 * weekly/monthly totals could be quietly wrong.
 *
 * Node's own Date object DOES know the device's real timezone (it
 * reads the OS/ICU timezone data, which nodejs-mobile has access to)
 * — so instead of asking SQLite to do timezone-aware date math, we
 * compute the boundary once in JS and pass it as a plain UTC ISO
 * string parameter. Every route then just compares created_at (also
 * stored as a UTC ISO string) directly: `WHERE created_at >= ?`.
 * No DATE()/strftime() timezone gymnastics needed anywhere.
 */

function localOffsetMs() {
    return -new Date().getTimezoneOffset() * 60000;
}

// Start of "today" in local time, expressed as a UTC ISO string.
function startOfTodayUTC() {
    const now = new Date();
    const local = new Date(now.getTime() + localOffsetMs());
    const startLocal = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate());
    return new Date(startLocal - localOffsetMs()).toISOString();
}

// Start of the current week (Sunday 00:00) in local time, as UTC ISO.
function startOfWeekUTC() {
    const now = new Date();
    const local = new Date(now.getTime() + localOffsetMs());
    const dow = local.getUTCDay(); // 0=Sunday
    const startLocal = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate() - dow);
    return new Date(startLocal - localOffsetMs()).toISOString();
}

// Start of the current month in local time, as UTC ISO.
function startOfMonthUTC() {
    const now = new Date();
    const local = new Date(now.getTime() + localOffsetMs());
    const startLocal = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), 1);
    return new Date(startLocal - localOffsetMs()).toISOString();
}

// End of the current week (Saturday 23:59:59.999) in local time, as UTC ISO.
function endOfWeekUTC() {
    const now = new Date();
    const local = new Date(now.getTime() + localOffsetMs());
    const dow = local.getUTCDay(); // 0=Sunday..6=Saturday
    // Saturday is (6 - dow) days after today; end of that day, local time.
    const endLocal = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate() + (6 - dow) + 1) - 1;
    return new Date(endLocal - localOffsetMs()).toISOString();
}

// End of the current month (last day, 23:59:59.999) in local time, as UTC ISO.
function endOfMonthUTC() {
    const now = new Date();
    const local = new Date(now.getTime() + localOffsetMs());
    // Day 0 of next month = last day of this month.
    const endLocal = Date.UTC(local.getUTCFullYear(), local.getUTCMonth() + 1, 1) - 1;
    return new Date(endLocal - localOffsetMs()).toISOString();
}

// Start of the current year in local time, as UTC ISO.
function startOfYearUTC() {
    const now = new Date();
    const local = new Date(now.getTime() + localOffsetMs());
    const startLocal = Date.UTC(local.getUTCFullYear(), 0, 1);
    return new Date(startLocal - localOffsetMs()).toISOString();
}

// Start of "N days ago" (inclusive rolling window, e.g. last 7 days
// including today = daysAgoStartUTC(6)), in local time, as UTC ISO.
function daysAgoStartUTC(n) {
    const now = new Date();
    const local = new Date(now.getTime() + localOffsetMs());
    const startLocal = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate() - n);
    return new Date(startLocal - localOffsetMs()).toISOString();
}

// Local calendar date ("YYYY-MM-DD") for an arbitrary stored UTC
// timestamp — for GROUP BY day in charts, computed correctly per row.
function localDateLabel(utcIsoString) {
    const d = new Date(utcIsoString);
    const local = new Date(d.getTime() + localOffsetMs());
    const y = local.getUTCFullYear();
    const m = String(local.getUTCMonth() + 1).padStart(2, "0");
    const day = String(local.getUTCDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
}

// Which local day-of-week "now" is (0=Sunday..6=Saturday) — used for
// the zaka/sadaka Sunday-through-Friday accumulation logic.
function todayLocalWeekday() {
    const now = new Date();
    const local = new Date(now.getTime() + localOffsetMs());
    return local.getUTCDay();
}

module.exports = {
    startOfTodayUTC,
    startOfWeekUTC,
    endOfWeekUTC,
    startOfMonthUTC,
    endOfMonthUTC,
    startOfYearUTC,
    daysAgoStartUTC,
    localDateLabel,
    todayLocalWeekday
};
