/**
 * LECS role & permission policy — single source of truth.
 *
 * Before this file existed, "admin-only" restrictions only lived as
 * ad-hoc `isAdmin` checks inside two frontend files (mauzo.js,
 * stock.js) that merely hid a button. The actual backend routes had
 * no matching check at all — meaning a cashier could still delete
 * products, sales, or suppliers, create new users, wipe/replace
 * company settings, or download the full database backup, simply by
 * calling the API directly (e.g. via browser dev tools), regardless
 * of what the UI showed them.
 *
 * This file defines what each role can do, and requireAdmin() /
 * requirePermission() (used in server.js) actually enforce it on the
 * backend — the frontend UI hiding buttons is just a courtesy on top
 * of real enforcement, not a substitute for it.
 *
 * Roles:
 *   admin   — full access to everything.
 *   cashier — day-to-day operational work (sell, add stock, record
 *             customer/supplier payments, view reports) but CANNOT
 *             delete records, manage other users, change company
 *             settings, or download database backups.
 */

const ADMIN_ONLY_ACTIONS = new Set([
    "delete_product",
    "delete_sale",
    "delete_supplier",
    "delete_customer",
    "delete_order",
    "manage_users",
    "manage_company_settings",
    "download_backup"
]);

function isAdmin(user) {
    return !!user && user.role === "admin";
}

function can(user, action) {
    if (!user) return false;
    if (user.role === "admin") return true;
    return !ADMIN_ONLY_ACTIONS.has(action);
}

/**
 * Express middleware: blocks the request with a clear 403 message
 * unless the logged-in user is an admin. Use on any route matching
 * one of the ADMIN_ONLY_ACTIONS above.
 */
function requireAdmin(actionLabel) {
    return (req, res, next) => {
        if (!isAdmin(req.session.user)) {
            return res.status(403).json({
                success: false,
                message: `Huna ruhusa — hatua hii (${actionLabel}) ni ya admin pekee.`
            });
        }
        next();
    };
}

module.exports = { isAdmin, can, requireAdmin, ADMIN_ONLY_ACTIONS };
