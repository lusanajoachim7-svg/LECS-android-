const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../database/db");
const { requireAdmin } = require("../utils/permissions");

const router = express.Router();

/* =========================
SAVE ACTIVITY LOG
========================= */

function saveLog(username, action, description) {

db.run(
    `INSERT INTO activity_logs
    (
        id,
        username,
        action,
        description,
        created_at
    )
    VALUES (?,?,?,?,?)`,
    [
        uuidv4(),
        username,
        action,
        description,
        new Date().toISOString()
    ]
);

}

/* =========================
CREATE NOTIFICATION
========================= */

function createNotification(title, message, type = "INFO") {

db.run(
    `INSERT INTO notifications
    (
        id,
        title,
        message,
        type,
        created_at
    )
    VALUES (?,?,?,?,?)`,
    [
        uuidv4(),
        title,
        message,
        type,
        new Date().toISOString()
    ]
);

}

/* =========================
GET ALL PRODUCTS
========================= */

router.get("/", (req, res) => {

const page = parseInt(req.query.page) || 1;
const limit = parseInt(req.query.limit) || 20;
const search = req.query.search || "";

const offset = (page - 1) * limit;

db.all(
    `
    SELECT
    bidhaa.*,
    suppliers.jina AS supplier_name

    FROM bidhaa

    LEFT JOIN suppliers
    ON suppliers.id = bidhaa.supplier_id

    WHERE bidhaa.deleted = 0
    AND bidhaa.idadi > 0
    AND bidhaa.jina LIKE ?

    ORDER BY bidhaa.jina ASC

    LIMIT ?
    OFFSET ?
    `,
    [
        `%${search}%`,
        limit,
        offset
    ],
    (err, rows) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Database Error"
            });
        }

        db.get(
            `
            SELECT COUNT(*) total
            FROM bidhaa
            WHERE deleted = 0
            AND idadi > 0
            AND jina LIKE ?
            `,
            [
                `%${search}%`
            ],
            (err, count) => {

                if (err) {
                    return res.status(500).json({
                        success: false
                    });
                }

                res.json({
                    success: true,
                    data: rows,
                    currentPage: page,
                    totalRows: count.total,
                    totalPages: Math.ceil(count.total / limit)
                });

            }
        );

    }
);

});

/* =========================
GET SINGLE PRODUCT
========================= */

router.get("/:id", (req, res) => {

db.get(
    `
    SELECT *
    FROM bidhaa
    WHERE id = ?
    AND deleted = 0
    `,
    [req.params.id],
    (err, row) => {

        if (err) {
            return res.status(500).json({
                success: false
            });
        }

        res.json(row || {});

    }
);

});

/* =========================
ADD PRODUCT
========================= */

router.post("/", (req, res) => {

const {
    jina,
    idadi,
    bei_kununua,
    bei_kuuza,
    barcode,
    supplier_id,
    low_stock_limit
} = req.body;

if (!jina) {

    return res.status(400).json({
        success: false,
        message: "Jina la bidhaa linahitajika"
    });

}

const now = new Date().toISOString();
const addQty = Number(idadi || 0);

// If a product with this exact name already exists — including one
// currently hidden because it hit zero stock — top it up instead of
// creating a second row. This is what was causing duplicate rows like
// two separate "Juma jack" entries.
db.get(
    `SELECT id, idadi FROM bidhaa WHERE LOWER(TRIM(jina)) = LOWER(TRIM(?)) LIMIT 1`,
    [jina],
    (err, existing) => {

        if (err) {
            return res.status(500).json({ success: false, message: "Database Error" });
        }

        if (existing) {

            const newQty = Number(existing.idadi || 0) + addQty;

            db.run(
                `UPDATE bidhaa
                 SET idadi = ?,
                     bei_kununua = COALESCE(NULLIF(?, 0), bei_kununua),
                     bei_kuuza = COALESCE(NULLIF(?, 0), bei_kuuza),
                     barcode = COALESCE(NULLIF(?, ''), barcode),
                     supplier_id = COALESCE(NULLIF(?, ''), supplier_id),
                     low_stock_limit = ?,
                     deleted = CASE WHEN ? > 0 THEN 0 ELSE 1 END,
                     updated_at = ?
                 WHERE id = ?`,
                [
                    newQty,
                    Number(bei_kununua || 0),
                    Number(bei_kuuza || 0),
                    barcode || "",
                    supplier_id || "",
                    Number(low_stock_limit || 2),
                    newQty,
                    now,
                    existing.id
                ],
                (err) => {

                    if (err) {
                        return res.status(500).json({ success: false, message: "Imeshindikana kuongeza bidhaa" });
                    }

                    saveLog("SYSTEM", "TOPUP_PRODUCT", `Bidhaa ${jina} imeongezwa stock (jumla mpya: ${newQty})`);

                    res.json({ success: true, id: existing.id, merged: true, idadi: newQty });

                }
            );

            return;

        }

        const id = uuidv4();

        db.run(
            `
            INSERT INTO bidhaa
            (
                id,
                jina,
                idadi,
                bei_kununua,
                bei_kuuza,
                barcode,
                supplier_id,
                low_stock_limit,
                created_at,
                updated_at,
                deleted,
                synced
            )
            VALUES
            (?,?,?,?,?,?,?,?,?,?,?,0)
            `,
            [
                id,
                jina,
                addQty,
                Number(bei_kununua || 0),
                Number(bei_kuuza || 0),
                barcode || "",
                supplier_id || "",
                Number(low_stock_limit || 2),
                now,
                now,
                addQty > 0 ? 0 : 1
            ],
            (err) => {

                if (err) {

                    return res.status(500).json({
                        success: false,
                        message: "Imeshindikana kuongeza bidhaa"
                    });

                }

                saveLog(
                    "SYSTEM",
                    "ADD_PRODUCT",
                    `Bidhaa ${jina} imeongezwa`
                );

                if (addQty <= Number(low_stock_limit || 2)) {

                    createNotification(
                        "LOW STOCK",
                        `${jina} imebaki ${addQty}`,
                        "WARNING"
                    );

                }

                res.json({
                    success: true,
                    id
                });

            }
        );

    }
);

});

/* =========================
UPDATE PRODUCT
========================= */

router.put("/:id", (req, res) => {

const {
    jina,
    idadi,
    bei_kununua,
    bei_kuuza,
    barcode,
    supplier_id,
    low_stock_limit
} = req.body;

db.run(
    `
    UPDATE bidhaa
    SET
    jina = ?,
    idadi = ?,
    bei_kununua = ?,
    bei_kuuza = ?,
    barcode = ?,
    supplier_id = ?,
    low_stock_limit = ?,
    deleted = CASE WHEN ? > 0 THEN 0 ELSE 1 END,
    updated_at = ?

    WHERE id = ?
    `,
    [
        jina,
        idadi,
        bei_kununua,
        bei_kuuza,
        barcode,
        supplier_id,
        low_stock_limit,
        idadi,
        new Date().toISOString(),
        req.params.id
    ],
    function (err) {

        if (err) {

            return res.status(500).json({
                success: false
            });

        }

        saveLog(
            "SYSTEM",
            "UPDATE_PRODUCT",
            `Bidhaa ${jina} imehaririwa`
        );

        if (Number(idadi) <= Number(low_stock_limit || 2)) {

            createNotification(
                "LOW STOCK",
                `${jina} imebaki ${idadi}`,
                "WARNING"
            );

        }

        res.json({
            success: true,
            changes: this.changes
        });

    }
);

});

/* =========================
DELETE PRODUCT
========================= */

router.delete("/:id", requireAdmin("delete_product"), (req, res) => {

db.run(
    `
    UPDATE bidhaa
    SET
    deleted = 1,
    updated_at = ?

    WHERE id = ?
    `,
    [
        new Date().toISOString(),
        req.params.id
    ],
    function (err) {

        if (err) {

            return res.status(500).json({
                success: false
            });

        }

        saveLog(
            "SYSTEM",
            "DELETE_PRODUCT",
            `Bidhaa ${req.params.id} imefutwa`
        );

        res.json({
            success: true
        });

    }
);

});

/* =========================
LOW STOCK PRODUCTS
========================= */

router.get("/alerts/low-stock", (req, res) => {

db.all(
    `
    SELECT *
    FROM bidhaa

    WHERE deleted = 0
    AND idadi <= low_stock_limit

    ORDER BY idadi ASC
    `,
    [],
    (err, rows) => {

        if (err) {

            return res.status(500).json({
                success: false
            });

        }

        res.json(rows);

    }
);

});

module.exports = router;