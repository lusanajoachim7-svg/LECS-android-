/**
 * Manual, file-based sync between independent LECS devices.
 *
 * Every device runs its own local database and works fully offline.
 * Pressing "Export Sync File" packages up everything that changed since
 * the last export into a small JSON file. The user moves that file to
 * another device however they like (Bluetooth, WhatsApp, USB, email).
 * Pressing "Import Sync File" on the other device merges those changes
 * into its own local database.
 *
 * Conflict rule: last write wins, compared by each row's `updated_at`.
 * This is simple and predictable — if two devices edited the same row
 * while apart, whichever edit happened later in real time overwrites
 * the other. Good enough for a small shop; not a strong guarantee for
 * high-contention concurrent edits, which this app doesn't have.
 */

const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const db = require("../database/db");
const { requireAdmin } = require("../utils/permissions");

const router = express.Router();

// Every table that participates in cross-device sync. Each one has
// updated_at, deleted and synced columns in the schema. Tables that
// don't (settings, activity_logs, notifications, stock_alerts,
// report_cache, backups, role_permissions) are intentionally left out —
// they're either per-device or safe to regenerate locally.
const SYNCED_TABLES = [
    "users",
    "suppliers",
    "customers",
    "bidhaa",
    "mauzo",
    "madeni_kudai",
    "customer_payments",
    "orders",
    "order_items",
    "supplier_payments"
];

// SECURITY: column names for INSERT/UPDATE during sync import were
// previously taken directly from Object.keys() of an incoming row —
// i.e. straight from another device's request body — and interpolated
// directly into SQL with no validation at all. A malicious or
// compromised peer device could send a row with a crafted key like
// "x); DROP TABLE users; --" and it would execute as-is. This
// whitelist (matching the real schema in database/schema.js exactly)
// is checked before any column name ever reaches a SQL string —
// anything not on this list is silently dropped from the row.
const ALLOWED_COLUMNS = {
    users: ["id","username","password_hash","jina","role","must_change_password","created_at","updated_at","deleted"],
    suppliers: ["id","jina","simu","account_namba","benki","tin","created_at","updated_at","deleted"],
    customers: ["id","jina","simu","created_at","updated_at","deleted"],
    bidhaa: ["id","jina","idadi","bei_kununua","bei_kuuza","barcode","supplier_id","low_stock_limit","created_at","updated_at","deleted"],
    mauzo: ["id","bidhaa_id","customer_id","mteja_jina","idadi","bei_kuuza","jumla","kiasi_kilicholipwa","faida_ghafi","zaka","sadaka","faida_halisi","status","created_at","updated_at","deleted"],
    madeni_kudai: ["id","mauzo_id","customer_id","mteja_jina","kiasi_asili","kiasi_kilicholipwa","kiasi_baki","status","created_at","updated_at","deleted"],
    customer_payments: ["id","customer_id","deni_id","kiasi","reference","created_at","updated_at","deleted"],
    orders: ["id","supplier_id","jumla_order","kiasi_kilicholipwa","kiasi_baki","status","created_at","updated_at","deleted"],
    order_items: ["id","order_id","bidhaa_id","bidhaa_jina","idadi","bei_kununua","jumla","created_at","updated_at","deleted"],
    supplier_payments: ["id","supplier_id","order_id","kiasi","reference","created_at","updated_at","deleted"]
};

function sanitizeRowColumns(table, row) {
    const allowed = new Set(ALLOWED_COLUMNS[table] || []);
    const clean = {};
    for (const key of Object.keys(row)) {
        if (allowed.has(key)) clean[key] = row[key];
    }
    return clean;
}

const dataDir = process.env.LECS_DATA_DIR || path.join(__dirname, "..", "data");
const deviceFilePath = path.join(dataDir, "device.json");

const MAX_SYNCED_DEVICES = 6;

/**
 * Checks whether `deviceId` is allowed to sync with this device.
 * Returns { allowed: true } if it's already registered, or if there's
 * still room under the cap (and registers it). Returns
 * { allowed: false, deviceCount } if the cap is already full and this
 * is a brand new device.
 */
async function checkDeviceAllowed(deviceId, deviceName) {

    const existing = await queryGet(
        "SELECT id FROM registered_devices WHERE id = ?",
        [deviceId]
    );

    const now = new Date().toISOString();

    if (existing) {
        await runSql(
            "UPDATE registered_devices SET last_synced_at = ?, device_name = ? WHERE id = ?",
            [now, deviceName || "Kifaa", deviceId]
        );
        return { allowed: true };
    }

    const countRow = await queryGet(
        "SELECT COUNT(*) as total FROM registered_devices",
        []
    );
    const deviceCount = countRow ? countRow.total : 0;

    if (deviceCount >= MAX_SYNCED_DEVICES) {
        return { allowed: false, deviceCount };
    }

    await runSql(
        "INSERT INTO registered_devices (id, device_name, first_seen, last_synced_at) VALUES (?, ?, ?, ?)",
        [deviceId, deviceName || "Kifaa", now, now]
    );

    return { allowed: true };
}

function loadDeviceInfo() {

    if (fs.existsSync(deviceFilePath)) {
        try {
            return JSON.parse(fs.readFileSync(deviceFilePath, "utf8"));
        } catch (err) {
            console.error("device.json corrupt, regenerating:", err.message);
        }
    }

    const { v4: uuidv4 } = require("uuid");

    const info = {
        device_id: uuidv4(),
        device_name: process.env.LECS_DEVICE_NAME || "Kifaa",
        last_export_at: null
    };

    fs.writeFileSync(deviceFilePath, JSON.stringify(info, null, 2));
    return info;
}

function saveDeviceInfo(info) {
    fs.writeFileSync(deviceFilePath, JSON.stringify(info, null, 2));
}

function queryAll(sql, params) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
}

function queryGet(sql, params) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
}

function runSql(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) reject(err);
            else resolve(this);
        });
    });
}

/* ======================
GET /api/sync/status
Quick summary of what's pending, for the settings UI.
====================== */

function requireLogin(req, res, next) {
    if (!req.session || !req.session.user) {
        return res.status(401).json({ success: false, message: "Login required" });
    }
    next();
}

function isPrivateLanIp(ip) {
    const cleaned = (ip || "").replace("::ffff:", "");
    return (
        cleaned === "127.0.0.1" ||
        cleaned.startsWith("10.") ||
        cleaned.startsWith("192.168.") ||
        /^172\.(1[6-9]|2\d|3[0-1])\./.test(cleaned)
    );
}

// /import accepts EITHER a logged-in browser session (manual "Import
// Sync File" button) OR an unauthenticated request from another
// device's own LECS server on the same LAN (the automatic peer push).
// There's no shared password to configure automatically between a
// shop's own devices, so LAN-origin is the trust boundary here — same
// tradeoff as any other device on your WiFi being "trusted".
/**
 * Sync passphrase — closes the "anyone on this WiFi can push data"
 * hole. Previously, allowSessionOrLan() trusted ANY request from a
 * private LAN IP with no authentication at all — a device that simply
 * joined the same WiFi network (shop WiFi, a shared building network,
 * a compromised device) could POST fabricated data straight into the
 * database via /api/sync/import.
 *
 * Fix: the shop admin sets one shared passphrase (Settings → Auto-Sync)
 * and enters the SAME passphrase on every device that should
 * participate — a one-time setup step per device. Every sync request
 * must then include a valid HMAC token proving the sender knows that
 * passphrase; devices that don't know it are rejected outright.
 *
 * Backward compatible: if no passphrase has been set yet, sync falls
 * back to the old LAN-trust behavior — but the Settings screen shows a
 * clear, persistent warning until one is configured, since that
 * fallback is not secure and shouldn't be the long-term state.
 */
function getSyncPassphraseHash() {
    const info = loadDeviceInfo();
    return info.sync_passphrase_hash || null;
}

function makeSyncToken(passphrase, deviceId, timestamp) {
    return crypto.createHmac("sha256", passphrase)
        .update(`${deviceId}:${timestamp}`)
        .digest("hex");
}

function verifySyncToken(req) {
    const passphraseHash = getSyncPassphraseHash();

    // No passphrase configured on this device yet — fall back to the
    // old LAN-trust check (still better than nothing, but the
    // Settings UI flags this clearly as insecure).
    if (!passphraseHash) {
        return isPrivateLanIp(req.ip);
    }

    const token = req.headers["x-lecs-sync-token"];
    const timestamp = req.headers["x-lecs-sync-timestamp"];
    const deviceId = req.body && req.body.from_device_id;

    if (!token || !timestamp || !deviceId) return false;

    // Reject stale requests (>5 min old) to limit replay-attack value.
    const age = Date.now() - Number(timestamp);
    if (!Number.isFinite(age) || age < 0 || age > 5 * 60 * 1000) return false;

    const expected = crypto.createHmac("sha256", passphraseHash)
        .update(`${deviceId}:${timestamp}`)
        .digest("hex");

    // Constant-time comparison — avoids leaking how many characters
    // matched via response-timing differences.
    try {
        return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(expected));
    } catch {
        return false; // length mismatch etc — definitely not equal
    }
}

async function isAlreadyAuthorizedDevice(deviceId) {
    if (!deviceId) return false;
    const row = await queryGet(
        "SELECT id FROM registered_devices WHERE id = ?",
        [deviceId]
    );
    return !!row;
}

async function allowSessionOrLan(req, res, next) {
    if (req.session && req.session.user) return next();

    const deviceId = req.body && req.body.from_device_id;

    // A device that has already been authorized once (it passed the
    // 6-device cap check under whatever method was valid at the time —
    // a passphrase token, or the original LAN-trust bootstrap before a
    // passphrase existed) stays trusted for every future sync, exactly
    // like a paired Bluetooth device or a linked WhatsApp device does.
    //
    // This closes a real bug: if a passphrase was only ever typed into
    // ONE device's Settings (easy to do, easy to forget the other
    // phones), that one device could receive everyone else's changes
    // fine, but its OWN changes would get silently rejected everywhere
    // else — because every other device demanded a matching token this
    // device never had. Requiring the exact same passphrase on every
    // single push, forever, doesn't match how "authorized devices"
    // should behave once they've already been let in.
    //
    // An admin can always revoke a device from Settings → Auto-Sync at
    // any time, which immediately un-trusts it again.
    if (await isAlreadyAuthorizedDevice(deviceId)) return next();

    // Brand new, not-yet-registered device: still needs either a valid
    // passphrase-proof token, or — if no passphrase has been
    // configured anywhere yet — plain LAN trust to complete its first
    // pairing (after which it becomes "already authorized" above).
    if (verifySyncToken(req)) return next();

    return res.status(403).json({ success: false, message: "Forbidden" });
}

router.get("/status", requireLogin, async (req, res) => {

    try {

        const info = loadDeviceInfo();
        let unsyncedCount = 0;

        for (const table of SYNCED_TABLES) {
            const row = await queryGet(
                `SELECT COUNT(*) AS c FROM ${table} WHERE synced = 0`,
                []
            );
            unsyncedCount += row ? Number(row.c) : 0;
        }

        res.json({
            success: true,
            device_id: info.device_id,
            device_name: info.device_name,
            last_export_at: info.last_export_at,
            unsynced_rows: unsyncedCount
        });

    } catch (err) {
        console.error("Sync status error:", err.message);
        res.status(500).json({ success: false, message: "Imeshindwa kupata hali ya sync" });
    }

});

/* ======================
GET /api/sync/peers
Devices currently visible on the WiFi, for the settings screen.
====================== */

router.get("/peers", requireLogin, (req, res) => {

    try {
        const peerSync = require("../services/peerSync");
        const peers = peerSync.getKnownPeers();

        res.json({
            success: true,
            peers: Object.values(peers).map(p => ({
                device_name: p.device_name,
                last_seen_at: p.last_seen_at,
                last_synced_at: p.last_synced_at
            }))
        });
    } catch (err) {
        res.json({ success: true, peers: [] });
    }

});

/* ======================
GET /api/sync/export
Builds and returns the sync file as a download.
====================== */

async function buildExportPayload(fromDeviceId, fromDeviceName, since) {

    const payload = {
        lecs_sync_version: 1,
        from_device_id: fromDeviceId,
        from_device_name: fromDeviceName,
        exported_at: new Date().toISOString(),
        since: since || null,
        tables: {}
    };

    for (const table of SYNCED_TABLES) {

        const rows = since
            ? await queryAll(
                `SELECT * FROM ${table} WHERE updated_at IS NOT NULL AND updated_at > ?`,
                [since]
            )
            : await queryAll(`SELECT * FROM ${table}`, []);

        payload.tables[table] = rows;
    }

    return payload;
}

function payloadHasRows(payload) {
    return Object.values(payload.tables).some(rows => rows.length > 0);
}

router.get("/export", requireLogin, async (req, res) => {

    try {

        const info = loadDeviceInfo();
        const since = info.last_export_at;

        const payload = await buildExportPayload(info.device_id, info.device_name, since);

        // Mark exported rows as synced=1 locally too, purely so the
        // settings screen's "X unsynced items" counter stays accurate.
        for (const table of SYNCED_TABLES) {
            if (since) {
                await runSql(
                    `UPDATE ${table} SET synced = 1 WHERE updated_at IS NOT NULL AND updated_at > ?`,
                    [since]
                );
            } else {
                await runSql(`UPDATE ${table} SET synced = 1`, []);
            }
        }

        info.last_export_at = payload.exported_at;
        saveDeviceInfo(info);

        const filename = `lecs-sync-${info.device_name.replace(/\s+/g, "_")}-${payload.exported_at.slice(0, 10)}.json`;

        res.setHeader("Content-Type", "application/json");
        res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
        res.send(JSON.stringify(payload, null, 2));

    } catch (err) {
        console.error("Sync export error:", err.message);
        res.status(500).json({ success: false, message: "Imeshindwa ku-export data" });
    }

});

/* ======================
POST /api/sync/import
Body: the raw JSON contents of a sync file produced by another device's
/api/sync/export.
====================== */

router.post("/import", express.json({ limit: "25mb" }), allowSessionOrLan, async (req, res) => {

    try {

        const payload = req.body;

        if (!payload || payload.lecs_sync_version !== 1 || !payload.tables) {
            return res.status(400).json({
                success: false,
                message: "Faili hii si sync file sahihi ya LECS"
            });
        }

        const info = loadDeviceInfo();

        if (payload.from_device_id === info.device_id) {
            return res.status(400).json({
                success: false,
                message: "Huwezi ku-import faili iliyotoka kwenye kifaa hiki hiki"
            });
        }

        const deviceCheck = await checkDeviceAllowed(payload.from_device_id, payload.from_device_name);

        if (!deviceCheck.allowed) {
            return res.status(403).json({
                success: false,
                message: `Kikomo cha vifaa ${MAX_SYNCED_DEVICES} kimefikiwa. Kifaa hiki (${payload.from_device_name || "kipya"}) hakiwezi kuunganishwa hadi ` +
                          `kifaa kingine kiondolewe kwenye Settings.`
            });
        }

        const summary = {
            from_device_name: payload.from_device_name || "Kifaa kingine",
            exported_at: payload.exported_at,
            inserted: 0,
            updated: 0,
            skipped: 0,
            errors: 0
        };

        for (const table of SYNCED_TABLES) {

            const rows = payload.tables[table];
            if (!Array.isArray(rows) || rows.length === 0) continue;

            for (const rawRow of rows) {

                try {

                    // Strip any column name not in our known schema
                    // BEFORE it's used anywhere — this is what actually
                    // closes the SQL injection: no key from the
                    // incoming payload reaches a SQL string unless it's
                    // on the whitelist for this exact table.
                    const row = sanitizeRowColumns(table, rawRow);

                    if (!row.id) {
                        summary.errors++;
                        continue;
                    }

                    const existing = await queryGet(
                        `SELECT id, updated_at FROM ${table} WHERE id = ?`,
                        [row.id]
                    );

                    if (!existing) {

                        const columns = Object.keys(row);
                        const placeholders = columns.map(() => "?").join(",");
                        const values = columns.map(c => row[c]);

                        await runSql(
                            `INSERT INTO ${table} (${columns.join(",")}, synced) VALUES (${placeholders}, 1)`,
                            values
                        );

                        summary.inserted++;

                    } else {

                        const incomingIsNewer =
                            row.updated_at &&
                            (!existing.updated_at || row.updated_at > existing.updated_at);

                        if (!incomingIsNewer) {
                            summary.skipped++;
                            continue;
                        }

                        const columns = Object.keys(row).filter(c => c !== "id");
                        const setClause = columns.map(c => `${c} = ?`).join(", ");
                        const values = columns.map(c => row[c]);

                        await runSql(
                            `UPDATE ${table} SET ${setClause}, synced = 1 WHERE id = ?`,
                            [...values, row.id]
                        );

                        summary.updated++;
                    }

                } catch (rowErr) {
                    console.error(`Sync import row error (${table}, id=${rawRow.id}):`, rowErr.message);
                    summary.errors++;
                }
            }
        }

        // Sync runs continuously in the background every few seconds —
        // if this import brought in a product with the same name as one
        // already here (e.g. two devices each added "Hisense tv inch 43"
        // while apart, then reconnected), merge them now instead of
        // leaving a visible duplicate until someone happens to restart
        // the app. Cheap no-op if there's nothing to merge.
        try {
            await require("../utils/mergeDuplicateProducts")();
        } catch (mergeErr) {
            console.error("Post-sync duplicate cleanup failed (non-fatal):", mergeErr.message);
        }

        res.json({ success: true, summary });

    } catch (err) {
        console.error("Sync import error:", err.message);
        res.status(500).json({ success: false, message: "Imeshindwa ku-import data" });
    }

});

/**
 * GET /api/sync/registered-devices
 * The durable, capped device registry (not just currently-visible
 * peers) — shows how many of the 6 device slots are used and by whom.
 */
router.get("/registered-devices", requireLogin, async (req, res) => {

    try {

        const rows = await new Promise((resolve, reject) => {
            db.all(
                "SELECT id, device_name, first_seen, last_synced_at FROM registered_devices ORDER BY first_seen ASC",
                [],
                (err, rows) => err ? reject(err) : resolve(rows)
            );
        });

        res.json({
            success: true,
            max_devices: MAX_SYNCED_DEVICES,
            count: rows.length,
            devices: rows
        });

    } catch (err) {
        res.status(500).json({ success: false, message: "Database Error" });
    }

});

/**
 * POST /api/sync/set-passphrase
 * Admin sets the shared sync passphrase for this device. The SAME
 * passphrase must be entered on every device that should be able to
 * sync with this one — only the hash is ever stored, never the
 * plaintext, and it's never transmitted between devices.
 */
router.post("/set-passphrase", requireLogin, requireAdmin("manage_sync_security"), (req, res) => {

    const { passphrase } = req.body;

    if (!passphrase || String(passphrase).length < 8) {
        return res.status(400).json({
            success: false,
            message: "Nywila ya sync iwe na herufi/namba angalau 8"
        });
    }

    const info = loadDeviceInfo();
    info.sync_passphrase_hash = crypto.createHash("sha256").update(String(passphrase)).digest("hex");
    saveDeviceInfo(info);

    res.json({ success: true });

});

/**
 * GET /api/sync/passphrase-status
 * Whether this device currently has a passphrase configured — the
 * settings screen uses this to show a clear security warning if not.
 */
router.get("/passphrase-status", requireLogin, (req, res) => {
    res.json({ success: true, configured: !!getSyncPassphraseHash() });
});

/**
 * DELETE /api/sync/registered-devices/:id
 * Revoke a device's authorization — frees its slot in the 6-device
 * cap and stops accepting any further sync data from it (it would
 * need to be re-authorized, i.e. count as a brand new device, to
 * rejoin — and only if a slot is free again).
 */
router.delete("/registered-devices/:id", requireLogin, requireAdmin("revoke_device"), async (req, res) => {

    try {

        const result = await runSql(
            "DELETE FROM registered_devices WHERE id = ?",
            [req.params.id]
        );

        res.json({ success: true, removed: result.changes > 0 });

    } catch (err) {
        res.status(500).json({ success: false, message: "Database Error" });
    }

});

module.exports = router;
module.exports.SYNCED_TABLES = SYNCED_TABLES;
module.exports.loadDeviceInfo = loadDeviceInfo;
module.exports.saveDeviceInfo = saveDeviceInfo;
module.exports.buildExportPayload = buildExportPayload;
module.exports.payloadHasRows = payloadHasRows;
module.exports.queryGet = queryGet;
module.exports.runSql = runSql;
