const express = require("express");
const bcrypt = require("bcryptjs");

const db = require("../database/db");

const router = express.Router();

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;

/* =========================
LOGIN
========================= */
router.post("/login", (req, res) => {

    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            success: false,
            message: "Jaza username na password"
        });
    }

    db.get(
        "SELECT * FROM users WHERE username = ? AND deleted = 0",
        [username],
        async (err, user) => {

            if (err) {
                console.error(err);
                return res.status(500).json({
                    success: false,
                    message: "Server Error"
                });
            }

            if (!user) {
                return res.status(401).json({
                    success: false,
                    message: "Username au Password si sahihi"
                });
            }

            // Account lockout — independent of the per-IP rate limiter,
            // this stops repeated attempts against one specific account
            // regardless of which device/IP they come from.
            if (user.locked_until && new Date(user.locked_until) > new Date()) {
                const minutesLeft = Math.ceil((new Date(user.locked_until) - new Date()) / 60000);
                return res.status(423).json({
                    success: false,
                    message: `Akaunti hii imefungwa kwa muda kutokana na majaribio mengi. Jaribu tena baada ya dakika ${minutesLeft}.`
                });
            }

            const valid = await bcrypt.compare(password, user.password_hash);

            if (!valid) {

                const attempts = (user.failed_login_attempts || 0) + 1;
                const lockNow = attempts >= MAX_FAILED_ATTEMPTS;

                db.run(
                    "UPDATE users SET failed_login_attempts = ?, locked_until = ? WHERE id = ?",
                    [
                        lockNow ? 0 : attempts,
                        lockNow ? new Date(Date.now() + LOCKOUT_MS).toISOString() : null,
                        user.id
                    ]
                );

                return res.status(401).json({
                    success: false,
                    message: lockNow
                        ? `Majaribio mengi yasiyo sahihi. Akaunti imefungwa kwa dakika 15.`
                        : "Username au Password si sahihi"
                });
            }

            // Successful login — clear any accumulated failed attempts.
            db.run(
                "UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?",
                [user.id]
            );

            /* SAVE SESSION */
            req.session.user = {
                id: user.id,
                username: user.username,
                jina: user.jina,
                role: user.role,
                must_change_password: !!user.must_change_password
            };

            return res.json({
                success: true,
                message: "Login successful",
                user: req.session.user
            });

        }
    );

});

/* =========================
CURRENT USER
========================= */
router.get("/me", (req, res) => {

    if (!req.session.user) {
        return res.status(401).json({
            success: false,
            message: "Unauthorized"
        });
    }

    res.json({
        success: true,
        user: req.session.user
    });

});

/* =========================
LOGOUT
========================= */
router.post("/logout", (req, res) => {

    req.session.destroy(() => {
        res.json({
            success: true,
            message: "Logged out"
        });
    });

});

/* =========================
CHECK LOGIN STATUS
========================= */
router.get("/check", (req, res) => {

    res.json({
        loggedIn: !!req.session.user,
        user: req.session.user || null
    });

});

module.exports = router;