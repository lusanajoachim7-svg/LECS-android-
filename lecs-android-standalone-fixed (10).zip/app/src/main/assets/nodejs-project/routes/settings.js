const express = require("express");
const { v4: uuidv4 } = require("uuid");
const bcrypt = require("bcryptjs");
const path = require("path");
const fs = require("fs");
const db = require("../database/db");
const { requireAdmin } = require("../utils/permissions");

// Shared password policy: at least 8 characters, and a mix of letters
// and numbers — a plain 6-character all-lowercase word (the previous
// minimum) is guessable quickly by any offline brute-force attempt if
// this device or its backup file was ever lost or stolen.
function isPasswordStrong(pw) {
    if (!pw || pw.length < 8) return false;
    const hasLetter = /[a-zA-Z]/.test(pw);
    const hasDigit = /[0-9]/.test(pw);
    return hasLetter && hasDigit;
}

const router = express.Router();

/* =========================
ADMIN-ONLY GUARD
(any logged-in user could otherwise create accounts
or download the full database — restrict to admins)
========================= */

/* requireAdmin is now imported from ../utils/permissions (see top of
   file) — the version previously defined here was never actually
   applied to any route. */

/* =========================
SYSTEM INFO
========================= */

router.get("/system", (req, res) => {

    db.get(
        "SELECT (SELECT COUNT(*) FROM users WHERE deleted=0) totalUsers, (SELECT COUNT(*) FROM bidhaa WHERE deleted=0) totalProducts, (SELECT COUNT(*) FROM suppliers WHERE deleted=0) totalSuppliers",
        [],
        (err, row) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json({
                version: "LECS v2.0",
                totalUsers: row.totalUsers,
                totalProducts: row.totalProducts,
                totalSuppliers: row.totalSuppliers
            });

        }
    );

});

/* =========================
COMPANY INFO (used on receipts / reports)
========================= */

router.get("/company", (req, res) => {

    db.get(
        "SELECT * FROM settings LIMIT 1",
        [],
        (err, row) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json({
                success: true,
                data: row || {}
            });

        }
    );

});

router.put("/company", requireAdmin("manage_company_settings"), (req, res) => {

    const {
        company_name,
        company_phone,
        company_email,
        company_address,
        currency
    } = req.body;

    db.get(
        "SELECT id FROM settings LIMIT 1",
        [],
        (err, row) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            const now = new Date().toISOString();

            if (!row) {

                return db.run(
                    `INSERT INTO settings
                    (id, company_name, company_phone, company_email, company_address, currency, version, created_at, updated_at)
                    VALUES (?,?,?,?,?,?,?,?,?)`,
                    [
                        uuidv4(),
                        company_name || "",
                        company_phone || "",
                        company_email || "",
                        company_address || "",
                        currency || "TZS",
                        "LECS v2.0",
                        now,
                        now
                    ],
                    (err) => {

                        if (err) {
                            return res.status(500).json({ success: false });
                        }

                        res.json({ success: true, message: "Taarifa za kampuni zimehifadhiwa" });

                    }
                );

            }

            db.run(
                `UPDATE settings SET
                company_name = ?,
                company_phone = ?,
                company_email = ?,
                company_address = ?,
                currency = ?,
                updated_at = ?
                WHERE id = ?`,
                [
                    company_name || "",
                    company_phone || "",
                    company_email || "",
                    company_address || "",
                    currency || "TZS",
                    now,
                    row.id
                ],
                (err) => {

                    if (err) {
                        return res.status(500).json({ success: false });
                    }

                    res.json({ success: true, message: "Taarifa za kampuni zimehifadhiwa" });

                }
            );

        }
    );

});

/* =========================
GET USERS
========================= */

router.get("/users", requireAdmin("manage_users"), (req, res) => {

    db.all(
        "SELECT id, username, jina, role, must_change_password FROM users WHERE deleted=0 ORDER BY jina ASC",
        [],
        (err, rows) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json(rows);

        }
    );

});

/* =========================
ADD USER
========================= */

router.post("/users", requireAdmin("manage_users"), async (req, res) => {

    try {

        const {
            username,
            jina,
            password,
            role
        } = req.body;

        if (!username || !jina || !password) {

            return res.status(400).json({
                success: false,
                message: "Jaza taarifa zote"
            });

        }

        if (!isPasswordStrong(password)) {

            return res.status(400).json({
                success: false,
                message: "Password iwe na herufi angalau 8, ikichanganya namba na herufi"
            });

        }

        const finalRole = role === "admin" ? "admin" : "cashier";

        const hash = await bcrypt.hash(password, 10);

        db.run(
            "INSERT INTO users( id, username, password_hash, jina, role, must_change_password, created_at, updated_at, deleted, synced ) VALUES(?,?,?,?,?,0,?,?,0,0)",
            [
                uuidv4(),
                username,
                hash,
                jina,
                finalRole,
                new Date().toISOString(),
                new Date().toISOString()
            ],
            (err) => {

                if (err) {

                    return res.status(500).json({
                        success: false,
                        message: "Username ipo tayari"
                    });

                }

                res.json({
                    success: true,
                    message: "User ameongezwa"
                });

            }
        );

    } catch (err) {

        res.status(500).json({
            success: false
        });

    }

});

/* =========================
CHANGE PASSWORD
========================= */

router.post("/change-password", async (req, res) => {

    try {

        const {
            oldPassword,
            newPassword
        } = req.body;

        if (!req.session.user) {

            return res.status(401).json({
                success: false,
                message: "Unauthorized"
            });

        }

        if (!isPasswordStrong(newPassword)) {

            return res.status(400).json({
                success: false,
                message: "Password mpya iwe na herufi angalau 8, ikichanganya namba na herufi"
            });

        }

        db.get(
            "SELECT * FROM users WHERE id=?",
            [req.session.user.id],
            async (err, user) => {

                if (err || !user) {

                    return res.status(404).json({
                        success: false,
                        message: "User not found"
                    });

                }

                const match = await bcrypt.compare(oldPassword, user.password_hash);

                if (!match) {

                    return res.json({
                        success: false,
                        message: "Password ya zamani si sahihi"
                    });

                }

                const hash = await bcrypt.hash(newPassword, 10);

                db.run(
                    "UPDATE users SET password_hash=?, must_change_password=0, updated_at=? WHERE id=?",
                    [
                        hash,
                        new Date().toISOString(),
                        user.id
                    ],
                    (err) => {

                        if (err) {

                            return res.status(500).json({
                                success: false
                            });

                        }

                        req.session.user.must_change_password = false;

                        res.json({
                            success: true,
                            message: "Password imebadilishwa"
                        });

                    }
                );

            }
        );

    } catch (err) {

        res.status(500).json({
            success: false
        });

    }

});

/* =========================
BACKUP DATABASE (real file download)
========================= */

router.get("/backup", requireAdmin("download_backup"), (req, res) => {

    db.flushSync();

    const dbPath = path.join(process.env.LECS_DATA_DIR || path.join(__dirname, "..", "data"), "lecs.db");

    if (!fs.existsSync(dbPath)) {

        return res.status(404).json({
            success: false,
            message: "Database file haipo"
        });

    }

    const stamp = new Date().toISOString().replace(/[:.]/g, "-");

    res.download(dbPath, `lecs-backup-${stamp}.db`, (err) => {

        if (err && !res.headersSent) {

            res.status(500).json({
                success: false,
                message: "Backup imeshindikana"
            });

        }

    });

});

module.exports = router;
