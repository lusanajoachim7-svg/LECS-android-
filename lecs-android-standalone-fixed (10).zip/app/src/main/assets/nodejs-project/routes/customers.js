const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../database/db");
const { requireAdmin } = require("../utils/permissions");

const router = express.Router();

/* =========================
GET ALL CUSTOMERS
========================= */

router.get("/", (req, res) => {

    const search = req.query.search || "";

    db.all(
        "SELECT * FROM customers WHERE deleted = 0 AND jina LIKE ? ORDER BY jina ASC",
        [`%${search}%`],
        (err, rows) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Database Error"
                });
            }

            res.json({
                success: true,
                data: rows
            });

        }
    );

});

/* =========================
CUSTOMER PURCHASE HISTORY
(used by the Wateja page: name + date filters,
 joins sales with product names)
========================= */

router.get("/purchases", (req, res) => {

    const name = req.query.name || "";
    const date = req.query.date || "";

    let sql = `
        SELECT
        mauzo.mteja_jina,
        bidhaa.jina AS bidhaa,
        mauzo.jumla,
        mauzo.kiasi_kilicholipwa,
        (mauzo.jumla - mauzo.kiasi_kilicholipwa) AS baki,
        mauzo.created_at
        FROM mauzo
        LEFT JOIN bidhaa ON bidhaa.id = mauzo.bidhaa_id
        WHERE mauzo.deleted = 0
        AND mauzo.mteja_jina LIKE ?
    `;

    const params = [`%${name}%`];

    if (date) {
        // Compare against a true local-day window instead of the raw
        // UTC-extracted date, which drifts by the local UTC offset in
        // sql.js (see utils/localDate.js for why).
        const dayStart = new Date(date + "T00:00:00");
        const localOffsetMs = -new Date().getTimezoneOffset() * 60000;
        const dayStartUTC = new Date(dayStart.getTime() - localOffsetMs).toISOString();
        const dayEndUTC = new Date(dayStart.getTime() - localOffsetMs + 24 * 60 * 60 * 1000).toISOString();
        sql += " AND mauzo.created_at >= ? AND mauzo.created_at < ? ";
        params.push(dayStartUTC, dayEndUTC);
    }

    sql += " ORDER BY mauzo.created_at DESC ";

    db.all(sql, params, (err, rows) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Database Error"
            });
        }

        res.json(rows);

    });

});

/* =========================
GET SINGLE CUSTOMER
========================= */

router.get("/:id", (req, res) => {

    db.get(
        "SELECT * FROM customers WHERE id = ? AND deleted = 0",
        [req.params.id],
        (err, row) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json(row || {});

        }
    );

});

/* =========================
ADD CUSTOMER
========================= */

router.post("/", (req, res) => {

    const { jina, simu } = req.body;

    if (!jina) {

        return res.status(400).json({
            success: false,
            message: "Jina linahitajika"
        });

    }

    db.run(
        "INSERT INTO customers( id, jina, simu, created_at, updated_at, deleted, synced ) VALUES(?,?,?,?,?,0,0)",
        [
            uuidv4(),
            jina,
            simu || "",
            new Date().toISOString(),
            new Date().toISOString()
        ],
        (err) => {

            if (err) {

                return res.status(500).json({
                    success: false,
                    message: "Imeshindikana kuhifadhi"
                });

            }

            res.json({
                success: true,
                message: "Customer ameongezwa"
            });

        }
    );

});

/* =========================
UPDATE CUSTOMER
========================= */

router.put("/:id", (req, res) => {

    const { jina, simu } = req.body;

    db.run(
        "UPDATE customers SET jina=?, simu=?, updated_at=? WHERE id=?",
        [
            jina,
            simu,
            new Date().toISOString(),
            req.params.id
        ],
        function (err) {

            if (err) {

                return res.status(500).json({
                    success: false
                });

            }

            res.json({
                success: true,
                changes: this.changes
            });

        }
    );

});

/* =========================
DELETE CUSTOMER
========================= */

router.delete("/:id", requireAdmin("delete_customer"), (req, res) => {

    db.run(
        "UPDATE customers SET deleted = 1, updated_at = ? WHERE id = ?",
        [
            new Date().toISOString(),
            req.params.id
        ],
        function (err) {

            if (err) {

                return res.status(500).json({
                    success: false
                });

            }

            res.json({
                success: true
            });

        }
    );

});

/* =========================
CUSTOMER SUMMARY
========================= */

router.get("/summary/stats", (req, res) => {

    db.get(
        "SELECT COUNT(*) totalCustomers FROM customers WHERE deleted = 0",
        [],
        (err, row) => {

            if (err) {

                return res.status(500).json({
                    success: false
                });

            }

            res.json(row);

        }
    );

});

module.exports = router;
