require("dotenv").config();

const express = require("express");
const cors = require("cors");
const path = require("path");
const session = require("express-session");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const { v4: uuidv4 } = require("uuid");

const db = require("./database/db");

const app = express();

/* ======================
WIFI SHIELD — network-level invisibility
======================
Before this, the whole app (login page, dashboard, every /api/*
business route) was reachable by ANY device on the same WiFi, simply
by visiting http://<this-phone's-LAN-IP>:3000 in a browser — the
login page and its rate-limiter offered some protection, but the app
was still fully visible and reachable over the network.

This device's server only ever needs to be reached from two places:
  1. This device's own WebView, which always talks to 127.0.0.1
     (loopback) — see MainActivity.java.
  2. Other paired LECS devices' sync requests, hitting /api/sync/*
     specifically — already protected by the HMAC passphrase token
     system above (see verifySyncToken/allowSessionOrLan).

Everything else now gets silently dropped — not a 403, not any HTTP
response at all, just a closed connection — for any request that
isn't from localhost and isn't targeting the sync API. A phone
scanning the WiFi network for open ports/services gets nothing
identifiable back from this one.
====================== */

function isLoopbackAddress(ip) {
    if (!ip) return false;
    return (
        ip === "127.0.0.1" ||
        ip === "::1" ||
        ip === "::ffff:127.0.0.1"
    );
}

app.use((req, res, next) => {

    const remoteIp = req.socket.remoteAddress;

    if (isLoopbackAddress(remoteIp)) {
        return next();
    }

    // Only the sync API is allowed to be reached from other devices on
    // the LAN — and only because it independently requires a valid
    // HMAC token proving the shared passphrase (see routes/sync.js).
    if (req.url.startsWith("/api/sync/")) {
        return next();
    }

    // Anything else from a non-localhost address: drop it silently.
    // No response body, no status code identifying this as a web
    // server at all — just close the connection.
    req.socket.destroy();

});

/* ======================
MIDDLEWARE
====================== */

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Basic security headers. This server is never directly exposed to
// the public internet, but it IS reachable from other devices on the
// same WiFi (for sync) — these cost nothing and rule out a few classes
// of browser-level attacks (MIME-sniffing, clickjacking) as one more
// layer, on top of the auth/permission/rate-limit protections below.
app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "no-referrer");
    next();
});

const fs = require("fs");
const crypto = require("crypto");

function getSessionSecret() {

    if (process.env.SESSION_SECRET) {
        return process.env.SESSION_SECRET;
    }

    // No secret configured — generate a real random one the first time
    // this device runs, then reuse it forever after so existing sessions
    // don't get invalidated on every restart. Every device ends up with
    // its own unique secret instead of every install sharing one
    // hardcoded string.
    const dataDir = process.env.LECS_DATA_DIR || path.join(__dirname, "data");
    const secretPath = path.join(dataDir, ".session_secret");

    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

    if (fs.existsSync(secretPath)) {
        return fs.readFileSync(secretPath, "utf8").trim();
    }

    const generated = crypto.randomBytes(48).toString("hex");
    fs.writeFileSync(secretPath, generated);
    return generated;
}

app.use(
    session({
        secret: getSessionSecret(),
        resave: false,
        saveUninitialized: false,
        cookie: {
            // This server always serves plain HTTP — 127.0.0.1 on-device,
            // or plain HTTP to LAN peers — never HTTPS. A Secure cookie
            // requires HTTPS; setting this true here would make the
            // browser silently refuse to store the session cookie after
            // every login, causing an infinite login loop. Do not tie
            // this to NODE_ENV — it must stay false for this app.
            secure: false,
            httpOnly: true,
            maxAge: 1000 * 60 * 60 * 24
        }
    })
);

/* ======================
STATIC FILES
====================== */

app.use(express.static(path.join(__dirname, "public")));

/* ======================
AUTH MIDDLEWARE
====================== */

function auth(req, res, next) {
    if (!req.session.user) {
        // API calls (fetch/AJAX) need a real error response, not a
        // redirect — a redirect gets silently followed by fetch() and
        // returns HTML instead of JSON, which is why actions like
        // "delete" could fail with zero visible error before this fix.
        if (req.originalUrl.startsWith("/api/") || req.xhr || req.headers.accept === "application/json") {
            return res.status(401).json({ success: false, message: "Session imeisha, tafadhali ingia tena" });
        }
        return res.redirect("/");
    }
    next();
}

/* ======================
ROLE MIDDLEWARE
====================== */

function role(roleName) {
    return (req, res, next) => {

        if (!req.session.user) {
            return res.redirect("/");
        }

        if (
            req.session.user.role !== roleName &&
            req.session.user.role !== "admin"
        ) {
            return res.status(403).json({
                success: false,
                message: "No Access"
            });
        }

        next();
    };
}

/* ======================
RATE LIMITING (LOGIN)
====================== */

const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // 10 attempts per window per IP
    standardHeaders: true,
    legacyHeaders: false,
    message: {
        success: false,
        message: "Majaribio mengi ya kuingia. Jaribu tena baada ya dakika 15."
    }
});

/* ======================
FIRST-RUN ADMIN CREATION
On a phone there's no terminal to run `npm run create-admin`, so if no
users exist yet at all, create a default admin the first time the server
starts and force a password change on first login.
====================== */

function ensureAdminExists() {
    return new Promise((resolve) => {

        db.get("SELECT id FROM users LIMIT 1", [], async (err, row) => {

            if (err) {
                console.error("Admin check error:", err.message);
                return resolve();
            }

            if (row) {
                return resolve();
            }

            const defaultPassword = process.env.ADMIN_PASSWORD || "admin123";
            const passwordHash = await bcrypt.hash(defaultPassword, 10);

            db.run(
                `INSERT INTO users
                (id, username, password_hash, jina, role, must_change_password, created_at, updated_at, deleted, synced)
                VALUES (?,?,?,?,?,?,?,?,?,?)`,
                [
                    uuidv4(),
                    "admin",
                    passwordHash,
                    "Administrator",
                    "admin",
                    1,
                    new Date().toISOString(),
                    new Date().toISOString(),
                    0,
                    0
                ],
                (err) => {
                    if (err) {
                        console.error("Admin creation error:", err.message);
                    } else {
                        console.log("======================================");
                        console.log("✅ First run: default admin created");
                        console.log("   Username: admin");
                        console.log("   Password: " + defaultPassword);
                        console.log("   You'll be asked to change it on first login.");
                        console.log("======================================");
                    }
                    resolve();
                }
            );
        });
    });
}

/* ======================
ROUTES
====================== */

function mountRoutes() {

    const authRoutes = require("./routes/auth");
    app.use("/api/auth/login", loginLimiter);
    app.use("/api/auth", authRoutes);

    app.use("/api/dashboard", auth, require("./routes/dashboard"));
    app.use("/api/reports", auth, require("./routes/reports"));

    app.use("/api/bidhaa", auth, require("./routes/bidhaa"));
    app.use("/api/mauzo", auth, require("./routes/mauzo"));

    app.use("/api/customers", auth, require("./routes/customers"));
    app.use("/api/customer-payments", auth, require("./routes/customer_payments"));

    app.use("/api/suppliers", auth, require("./routes/suppliers"));
    app.use("/api/payments", auth, require("./routes/payments"));

    app.use("/api/orders", auth, require("./routes/orders"));
    app.use("/api/madeni", auth, require("./routes/debts"));

    app.use("/api/activity-logs", auth, require("./routes/activity_logs"));
    app.use("/api/settings", auth, require("./routes/settings"));
    app.use("/api/notifications", auth, require("./routes/notifications"));

    // Not behind the session `auth` middleware — /api/sync/import has to
    // be reachable by other devices' own LECS servers on the same WiFi,
    // which have no browser session cookie. It protects itself instead
    // (see routes/sync.js: session OR same-LAN origin required).
    app.use("/api/sync", require("./routes/sync"));

    /* ======================
    HEALTH CHECK
    ====================== */

    app.get("/api/health", (req, res) => {
        res.json({
            app: "LECS FINAL SYSTEM",
            status: "RUNNING",
            time: new Date().toISOString()
        });
    });

    /* ======================
    LOGIN PAGE
    ====================== */

    app.get("/", (req, res) => {
        res.sendFile(path.join(__dirname, "public", "login.html"));
    });

    /* ======================
    PROTECTED PAGES
    ====================== */

    const pages = [
        "dashboard.html",
        "stock.html",
        "mauzo.html",
        "suppliers.html",
        "orders.html",
        "payments.html",
        "debts.html",
        "customers.html",
        "customer_payments.html",
        "reports.html",
        "settings.html",
        "activity_logs.html"
    ];

    pages.forEach(page => {
        app.get("/" + page, auth, (req, res) => {
            res.sendFile(path.join(__dirname, "public", page));
        });
    });

    /* ======================
    LOGOUT
    ====================== */

    app.get("/logout", (req, res) => {
        req.session.destroy(() => {
            res.redirect("/");
        });
    });

    /* ======================
    404 HANDLER
    ====================== */

    app.use((req, res) => {
        res.status(404).json({
            success: false,
            message: "Route haipatikani"
        });
    });

    /* ======================
    ERROR HANDLER
    ====================== */

    app.use((err, req, res, next) => {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Internal Server Error"
        });
    });
}

/* ======================
START SERVER
Everything that touches the database (schema creation, route handlers,
first-run admin) has to wait until the sql.js WebAssembly module has
finished loading — that's the one async step this on-device version
needs that a normal always-on server didn't.
====================== */

const PORT = process.env.PORT || 3000;

async function start() {
    await db.init();

    require("./database/schema");

    await ensureAdminExists();

    try {
        await require("./utils/mergeDuplicateProducts")();
    } catch (err) {
        console.error("Duplicate product cleanup failed (non-fatal):", err.message);
    }

    mountRoutes();

    app.listen(PORT, () => {
        console.log("🚀 LECS FINAL SYSTEM RUNNING (on-device)");
        console.log("🌐 http://localhost:" + PORT);

        // Clear any previous crash log now that startup actually succeeded.
        try {
            const dataDir = process.env.LECS_DATA_DIR || path.join(__dirname, "data");
            const crashLogPath = path.join(dataDir, "last_crash.log");
            if (fs.existsSync(crashLogPath)) fs.unlinkSync(crashLogPath);
        } catch (e) { /* non-fatal */ }

        try {
            require("./services/peerSync").start(PORT);
        } catch (err) {
            console.error("Auto-sync service failed to start:", err.message);
        }
    });
}

start().catch(err => {
    console.error("❌ LECS failed to start:", err);

    // Also write the failure to a plain file MainActivity can read and
    // show directly in the app's error panel. This lets you see the
    // actual crash reason on the phone screen itself — no computer, no
    // Logcat app, no file export needed.
    try {
        const fs = require("fs");
        const path = require("path");
        const dataDir = process.env.LECS_DATA_DIR || path.join(__dirname, "data");
        if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
        const crashText =
            "LECS failed to start\n" +
            new Date().toISOString() + "\n\n" +
            (err && err.stack ? err.stack : String(err));
        fs.writeFileSync(path.join(dataDir, "last_crash.log"), crashText);
    } catch (writeErr) {
        console.error("Could not write crash log file:", writeErr.message);
    }

    // IMPORTANT: no process.exit() here. This Node runtime is embedded
    // inside the Android app's own process (via node::Start() in
    // native-lib.cpp) — calling process.exit() doesn't just end "the
    // server," it kills the entire host app instantly, with no chance
    // for this error to reach Logcat or for MainActivity's error panel
    // to show. Leaving the process alive (but not listening) lets
    // MainActivity's own health-check timeout surface a normal,
    // recoverable error screen instead of a silent crash.
});
