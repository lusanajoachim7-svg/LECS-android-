const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../database/db");

const router = express.Router();

/* =========================
GET ALL SUPPLIERS
========================= */

router.get("/", (req,res)=>{

const search =
req.query.search || "";

const page =
parseInt(req.query.page) || 1;

const limit =
parseInt(req.query.limit) || 20;

const offset =
(page - 1) * limit;

db.all(
`
SELECT *
FROM suppliers

WHERE deleted = 0
AND jina LIKE ?

ORDER BY jina ASC

LIMIT ?
OFFSET ?
`,
[
`%${search}%`,
limit,
offset
],
(err,rows)=>{

if(err){

return res.status(500).json({
success:false,
message:"Database Error"
});

}

db.get(
`
SELECT COUNT(*) total
FROM suppliers

WHERE deleted = 0
AND jina LIKE ?
`,
[
`%${search}%`
],
(err,count)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json({

success:true,

data:rows,

currentPage:page,

totalRows:count.total,

totalPages:
Math.ceil(
count.total / limit
)

});

});

});

});

/* =========================
SUPPLIER PURCHASE HISTORY
Every item ever ordered from this supplier — quantity, buying price,
date, which order it belongs to — plus a summary of how much of it
has actually been paid for.
========================= */

router.get("/:id/purchases", (req, res) => {

    const supplierId = req.params.id;

    db.all(
        `
        SELECT
            order_items.id AS item_id,
            order_items.bidhaa_jina,
            order_items.idadi,
            order_items.bei_kununua,
            order_items.jumla,
            order_items.created_at AS tarehe,
            orders.id AS order_id,
            orders.status AS order_status,
            orders.jumla_order,
            orders.kiasi_kilicholipwa AS order_kiasi_kilicholipwa,
            orders.kiasi_baki AS order_kiasi_baki

        FROM order_items

        JOIN orders
        ON orders.id = order_items.order_id

        WHERE orders.supplier_id = ?
        AND order_items.deleted = 0
        AND orders.deleted = 0

        ORDER BY order_items.created_at DESC
        `,
        [supplierId],
        (err, items) => {

            if (err) {
                return res.status(500).json({ success: false, message: "Database Error" });
            }

            db.get(
                `
                SELECT
                    suppliers.jina AS supplier_jina,
                    IFNULL(SUM(orders.jumla_order), 0) AS jumla_yote,
                    IFNULL(SUM(orders.kiasi_kilicholipwa), 0) AS jumla_kilicholipwa,
                    IFNULL(SUM(orders.kiasi_baki), 0) AS jumla_baki

                FROM suppliers

                LEFT JOIN orders
                ON orders.supplier_id = suppliers.id
                AND orders.deleted = 0

                WHERE suppliers.id = ?
                AND suppliers.deleted = 0

                GROUP BY suppliers.id
                `,
                [supplierId],
                (err2, summaryRow) => {

                    if (err2) {
                        return res.status(500).json({ success: false, message: "Database Error" });
                    }

                    const summary = summaryRow || { supplier_jina: "", jumla_yote: 0, jumla_kilicholipwa: 0, jumla_baki: 0 };

                    res.json({
                        success: true,
                        supplier_jina: summary.supplier_jina,
                        items: items,
                        jumla_yote: summary.jumla_yote,
                        jumla_kilicholipwa: summary.jumla_kilicholipwa,
                        jumla_baki: summary.jumla_baki,
                        fully_paid: Number(summary.jumla_baki) <= 0
                    });
                }
            );
        }
    );

});

/* =========================
GET SINGLE SUPPLIER
========================= */

router.get("/:id",(req,res)=>{

db.get(
`
SELECT *
FROM suppliers
WHERE id = ?
AND deleted = 0
`,
[
req.params.id
],
(err,row)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(row || {});

});

});

/* =========================
ADD SUPPLIER
========================= */

router.post("/",(req,res)=>{

let {
jina,
simu,
account_namba,
benki,
tin
} = req.body;

jina =
(jina || "").trim();

if(!jina){

return res.status(400).json({
success:false,
message:"Jina la supplier linahitajika"
});

}

db.run(
`
INSERT INTO suppliers(

id,
jina,
simu,
account_namba,
benki,
tin,
created_at,
updated_at,
deleted,
synced

)

VALUES(
?,?,?,?,?,?,?,?,0,0
)
`,
[
uuidv4(),
jina,
simu || "",
account_namba || "",
benki || "",
tin || "",
new Date().toISOString(),
new Date().toISOString()
],
(err)=>{

if(err){

return res.status(500).json({
success:false,
message:"Imeshindikana kuongeza supplier"
});

}

res.json({
success:true,
message:"Supplier ameongezwa"
});

});

});

/* =========================
UPDATE SUPPLIER
========================= */

router.put("/:id",(req,res)=>{

const {
jina,
simu,
account_namba,
benki,
tin
} = req.body;

db.run(
`
UPDATE suppliers

SET
jina = ?,
simu = ?,
account_namba = ?,
benki = ?,
tin = ?,
updated_at = ?

WHERE id = ?
`,
[
jina,
simu,
account_namba,
benki,
tin,
new Date().toISOString(),
req.params.id
],
function(err){

if(err){

return res.status(500).json({
success:false
});

}

res.json({
success:true,
changes:this.changes
});

});

});

/* =========================
SUPPLIER STATS
========================= */

router.get("/stats/summary",(req,res)=>{

db.get(
`
SELECT
COUNT(*) total_suppliers

FROM suppliers

WHERE deleted = 0
`,
[],
(err,row)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(row);

});

});

/* =========================
DELETE SUPPLIER
========================= */

router.delete("/:id",(req,res)=>{

db.run(
`
UPDATE suppliers

SET
deleted = 1,
updated_at = ?

WHERE id = ?
`,
[
new Date().toISOString(),
req.params.id
],
function(err){

if(err){

return res.status(500).json({
success:false
});

}

res.json({
success:true
});

});

});

module.exports = router;