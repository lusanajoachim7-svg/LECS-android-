/**
 * Manual, file-based sync between independent LECS devices.
 *
 * Every device runs its own local database and works fully offline.
 * Pressing "Export Sync File" packages up everything that changed since
 * the last export into a small JSON file. The user moves that file to
 * another device however they like (Bluetooth, WhatsApp, USB, email).
 * Pressing "Import Sync File" on the other device merges those changes
 * into its own local database.
 *
 * Conflict rule: last write wins, compared by each row's `updated_at`.
 * This is simple and predictable — if two devices edited the same row
 * while apart, whichever edit happened later in real time overwrites
 * the other. Good enough for a small shop; not a strong guarantee for
 * high-contention concurrent edits, which this app doesn't have.
 */

const express = require("express");
const fs = require("fs");
const path = require("path");
const db = require("../database/db");

const router = express.Router();

// Every table that participates in cross-device sync. Each one has
// updated_at, deleted and synced columns in the schema. Tables that
// don't (settings, activity_logs, notifications, stock_alerts,
// report_cache, backups, role_permissions) are intentionally left out —
// they're either per-device or safe to regenerate locally.
const SYNCED_TABLES = [
    "users",
    "suppliers",
    "customers",
    "bidhaa",
    "mauzo",
    "madeni_kudai",
    "customer_payments",
    "orders",
    "order_items",
    "supplier_payments"
];

const dataDir = process.env.LECS_DATA_DIR || path.join(__dirname, "..", "data");
const deviceFilePath = path.join(dataDir, "device.json");

function loadDeviceInfo() {

    if (fs.existsSync(deviceFilePath)) {
        try {
            return JSON.parse(fs.readFileSync(deviceFilePath, "utf8"));
        } catch (err) {
            console.error("device.json corrupt, regenerating:", err.message);
        }
    }

    const { v4: uuidv4 } = require("uuid");

    const info = {
        device_id: uuidv4(),
        device_name: process.env.LECS_DEVICE_NAME || "Kifaa",
        last_export_at: null
    };

    fs.writeFileSync(deviceFilePath, JSON.stringify(info, null, 2));
    return info;
}

function saveDeviceInfo(info) {
    fs.writeFileSync(deviceFilePath, JSON.stringify(info, null, 2));
}

function queryAll(sql, params) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
}

function queryGet(sql, params) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
}

function runSql(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) reject(err);
            else resolve(this);
        });
    });
}

/* ======================
GET /api/sync/status
Quick summary of what's pending, for the settings UI.
====================== */

function requireLogin(req, res, next) {
    if (!req.session || !req.session.user) {
        return res.status(401).json({ success: false, message: "Login required" });
    }
    next();
}

function isPrivateLanIp(ip) {
    const cleaned = (ip || "").replace("::ffff:", "");
    return (
        cleaned === "127.0.0.1" ||
        cleaned.startsWith("10.") ||
        cleaned.startsWith("192.168.") ||
        /^172\.(1[6-9]|2\d|3[0-1])\./.test(cleaned)
    );
}

// /import accepts EITHER a logged-in browser session (manual "Import
// Sync File" button) OR an unauthenticated request from another
// device's own LECS server on the same LAN (the automatic peer push).
// There's no shared password to configure automatically between a
// shop's own devices, so LAN-origin is the trust boundary here — same
// tradeoff as any other device on your WiFi being "trusted".
function allowSessionOrLan(req, res, next) {
    if (req.session && req.session.user) return next();
    if (isPrivateLanIp(req.ip)) return next();
    return res.status(403).json({ success: false, message: "Forbidden" });
}

router.get("/status", requireLogin, async (req, res) => {

    try {

        const info = loadDeviceInfo();
        let unsyncedCount = 0;

        for (const table of SYNCED_TABLES) {
            const row = await queryGet(
                `SELECT COUNT(*) AS c FROM ${table} WHERE synced = 0`,
                []
            );
            unsyncedCount += row ? Number(row.c) : 0;
        }

        res.json({
            success: true,
            device_id: info.device_id,
            device_name: info.device_name,
            last_export_at: info.last_export_at,
            unsynced_rows: unsyncedCount
        });

    } catch (err) {
        console.error("Sync status error:", err.message);
        res.status(500).json({ success: false, message: "Imeshindwa kupata hali ya sync" });
    }

});

/* ======================
GET /api/sync/peers
Devices currently visible on the WiFi, for the settings screen.
====================== */

router.get("/peers", requireLogin, (req, res) => {

    try {
        const peerSync = require("../services/peerSync");
        const peers = peerSync.getKnownPeers();

        res.json({
            success: true,
            peers: Object.values(peers).map(p => ({
                device_name: p.device_name,
                last_seen_at: p.last_seen_at,
                last_synced_at: p.last_synced_at
            }))
        });
    } catch (err) {
        res.json({ success: true, peers: [] });
    }

});

/* ======================
GET /api/sync/export
Builds and returns the sync file as a download.
====================== */

async function buildExportPayload(fromDeviceId, fromDeviceName, since) {

    const payload = {
        lecs_sync_version: 1,
        from_device_id: fromDeviceId,
        from_device_name: fromDeviceName,
        exported_at: new Date().toISOString(),
        since: since || null,
        tables: {}
    };

    for (const table of SYNCED_TABLES) {

        const rows = since
            ? await queryAll(
                `SELECT * FROM ${table} WHERE updated_at IS NOT NULL AND updated_at > ?`,
                [since]
            )
            : await queryAll(`SELECT * FROM ${table}`, []);

        payload.tables[table] = rows;
    }

    return payload;
}

function payloadHasRows(payload) {
    return Object.values(payload.tables).some(rows => rows.length > 0);
}

router.get("/export", requireLogin, async (req, res) => {

    try {

        const info = loadDeviceInfo();
        const since = info.last_export_at;

        const payload = await buildExportPayload(info.device_id, info.device_name, since);

        // Mark exported rows as synced=1 locally too, purely so the
        // settings screen's "X unsynced items" counter stays accurate.
        for (const table of SYNCED_TABLES) {
            if (since) {
                await runSql(
                    `UPDATE ${table} SET synced = 1 WHERE updated_at IS NOT NULL AND updated_at > ?`,
                    [since]
                );
            } else {
                await runSql(`UPDATE ${table} SET synced = 1`, []);
            }
        }

        info.last_export_at = payload.exported_at;
        saveDeviceInfo(info);

        const filename = `lecs-sync-${info.device_name.replace(/\s+/g, "_")}-${payload.exported_at.slice(0, 10)}.json`;

        res.setHeader("Content-Type", "application/json");
        res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
        res.send(JSON.stringify(payload, null, 2));

    } catch (err) {
        console.error("Sync export error:", err.message);
        res.status(500).json({ success: false, message: "Imeshindwa ku-export data" });
    }

});

/* ======================
POST /api/sync/import
Body: the raw JSON contents of a sync file produced by another device's
/api/sync/export.
====================== */

router.post("/import", express.json({ limit: "25mb" }), allowSessionOrLan, async (req, res) => {

    try {

        const payload = req.body;

        if (!payload || payload.lecs_sync_version !== 1 || !payload.tables) {
            return res.status(400).json({
                success: false,
                message: "Faili hii si sync file sahihi ya LECS"
            });
        }

        const info = loadDeviceInfo();

        if (payload.from_device_id === info.device_id) {
            return res.status(400).json({
                success: false,
                message: "Huwezi ku-import faili iliyotoka kwenye kifaa hiki hiki"
            });
        }

        const summary = {
            from_device_name: payload.from_device_name || "Kifaa kingine",
            exported_at: payload.exported_at,
            inserted: 0,
            updated: 0,
            skipped: 0,
            errors: 0
        };

        for (const table of SYNCED_TABLES) {

            const rows = payload.tables[table];
            if (!Array.isArray(rows) || rows.length === 0) continue;

            for (const row of rows) {

                try {

                    const existing = await queryGet(
                        `SELECT id, updated_at FROM ${table} WHERE id = ?`,
                        [row.id]
                    );

                    if (!existing) {

                        const columns = Object.keys(row);
                        const placeholders = columns.map(() => "?").join(",");
                        const values = columns.map(c => row[c]);

                        await runSql(
                            `INSERT INTO ${table} (${columns.join(",")}, synced) VALUES (${placeholders}, 1)`,
                            values
                        );

                        summary.inserted++;

                    } else {

                        const incomingIsNewer =
                            row.updated_at &&
                            (!existing.updated_at || row.updated_at > existing.updated_at);

                        if (!incomingIsNewer) {
                            summary.skipped++;
                            continue;
                        }

                        const columns = Object.keys(row).filter(c => c !== "id");
                        const setClause = columns.map(c => `${c} = ?`).join(", ");
                        const values = columns.map(c => row[c]);

                        await runSql(
                            `UPDATE ${table} SET ${setClause}, synced = 1 WHERE id = ?`,
                            [...values, row.id]
                        );

                        summary.updated++;
                    }

                } catch (rowErr) {
                    console.error(`Sync import row error (${table}, id=${row.id}):`, rowErr.message);
                    summary.errors++;
                }
            }
        }

        res.json({ success: true, summary });

    } catch (err) {
        console.error("Sync import error:", err.message);
        res.status(500).json({ success: false, message: "Imeshindwa ku-import data" });
    }

});

module.exports = router;
module.exports.SYNCED_TABLES = SYNCED_TABLES;
module.exports.loadDeviceInfo = loadDeviceInfo;
module.exports.saveDeviceInfo = saveDeviceInfo;
module.exports.buildExportPayload = buildExportPayload;
module.exports.payloadHasRows = payloadHasRows;
module.exports.queryGet = queryGet;
module.exports.runSql = runSql;
