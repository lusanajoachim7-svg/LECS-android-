const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../database/db");

const router = express.Router();

/* =========================
GET PRODUCTS FOR SALES
========================= */

router.get("/bidhaa", (req, res) => {

    db.all(
        `SELECT *
         FROM bidhaa
         WHERE deleted = 0
         ORDER BY jina ASC`,
        [],
        (err, rows) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json(rows);
        }
    );

});

/* =========================
GET SALES + SEARCH + PAGINATION
========================= */

router.get("/", (req, res) => {

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const search = req.query.search || "";

    const offset = (page - 1) * limit;

    db.all(
        `
        SELECT *
        FROM mauzo
        WHERE deleted = 0
        AND mteja_jina LIKE ?
        ORDER BY created_at DESC
        LIMIT ?
        OFFSET ?
        `,
        [
            `%${search}%`,
            limit,
            offset
        ],
        (err, rows) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            db.get(
                `
                SELECT COUNT(*) total
                FROM mauzo
                WHERE deleted = 0
                AND mteja_jina LIKE ?
                `,
                [`%${search}%`],
                (err, count) => {

                    if (err) {
                        return res.status(500).json({
                            success: false
                        });
                    }

                    res.json({
                        success: true,
                        data: rows,
                        currentPage: page,
                        totalRows: count.total,
                        totalPages: Math.ceil(
                            count.total / limit
                        )
                    });

                }
            );

        }
    );

});

/* =========================
GET SALE RECEIPT (for printing)
========================= */

router.get("/:id/receipt", (req, res) => {

    db.get(
        `
        SELECT
        mauzo.*,
        bidhaa.jina AS bidhaa_jina,
        bidhaa.barcode AS bidhaa_barcode
        FROM mauzo
        LEFT JOIN bidhaa ON bidhaa.id = mauzo.bidhaa_id
        WHERE mauzo.id = ?
        AND mauzo.deleted = 0
        `,
        [req.params.id],
        (err, sale) => {

            if (err) {
                return res.status(500).json({ success: false });
            }

            if (!sale) {
                return res.status(404).json({ success: false, message: "Mauzo hayapo" });
            }

            db.get(
                "SELECT * FROM settings LIMIT 1",
                [],
                (err, company) => {

                    if (err) {
                        return res.status(500).json({ success: false });
                    }

                    res.json({
                        success: true,
                        sale,
                        company: company || {}
                    });

                }
            );

        }
    );

});

/* =========================
CREATE SALE
(wrapped in a transaction so stock/debt/customer/log writes
are atomic — a failure partway through no longer leaves
half-applied data)
========================= */

router.post("/", (req, res) => {

    const {
        bidhaa_id,
        mteja_jina,
        idadi,
        bei_kuuza,
        kiasi_kilicholipwa
    } = req.body;

    if (
        !bidhaa_id ||
        !idadi ||
        !bei_kuuza
    ) {

        return res.status(400).json({
            success: false,
            message: "Jaza taarifa zote"
        });

    }

    if (Number(idadi) <= 0 || Number(bei_kuuza) <= 0) {

        return res.status(400).json({
            success: false,
            message: "Idadi na bei lazima ziwe zaidi ya sifuri"
        });

    }

    db.get(
        `
        SELECT *
        FROM bidhaa
        WHERE id = ?
        AND deleted = 0
        `,
        [bidhaa_id],
        (err, bidhaa) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            if (!bidhaa) {

                return res.status(404).json({
                    success: false,
                    message: "Bidhaa haipo"
                });

            }

            if (
                Number(idadi) >
                Number(bidhaa.idadi)
            ) {

                return res.status(400).json({
                    success: false,
                    message: "Stock haitoshi"
                });

            }

            const jumla =
                Number(idadi) *
                Number(bei_kuuza);

            const malipo =
                Number(
                    kiasi_kilicholipwa || 0
                );

            const gharama =
                Number(idadi) *
                Number(
                    bidhaa.bei_kununua
                );

            const faidaGhafi =
                jumla - gharama;

            const zaka =
                faidaGhafi * 0.1;

            const sadaka =
                faidaGhafi * 0.1;

            const faidaHalisi =
                faidaGhafi -
                zaka -
                sadaka;

            const deni =
                Math.max(
                    0,
                    jumla - malipo
                );

            const saleId =
                uuidv4();

            const now =
                new Date().toISOString();

            /* ============ TRANSACTION START ============ */

            db.serialize(() => {

                db.run("BEGIN TRANSACTION");

                let failed = false;

                const fail = (message) => {

                    if (failed) return;
                    failed = true;

                    db.run("ROLLBACK", () => {
                        res.status(500).json({
                            success: false,
                            message: message || "Imeshindikana kuhifadhi mauzo"
                        });
                    });

                };

                db.run(
                    `
                    INSERT INTO mauzo(
                    id,
                    bidhaa_id,
                    mteja_jina,
                    idadi,
                    bei_kuuza,
                    jumla,
                    kiasi_kilicholipwa,
                    faida_ghafi,
                    zaka,
                    sadaka,
                    faida_halisi,
                    status,
                    created_at,
                    updated_at
                    )
                    VALUES(
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,?
                    )
                    `,
                    [
                        saleId,
                        bidhaa_id,
                        mteja_jina || "",
                        idadi,
                        bei_kuuza,
                        jumla,
                        malipo,
                        faidaGhafi,
                        zaka,
                        sadaka,
                        faidaHalisi,
                        deni > 0 ? "DENI" : "PAID",
                        now,
                        now
                    ],
                    (err) => {

                        if (err) return fail();
                        if (failed) return;

                        /* PUNGUZA STOCK */

                        db.run(
                            `
                            UPDATE bidhaa
                            SET idadi = idadi - ?
                            WHERE id = ?
                            `,
                            [idadi, bidhaa_id],
                            (err) => {

                                if (err) return fail();
                                if (failed) return;

                                const afterCustomer = () => {

                                    if (failed) return;

                                    const afterDeni = () => {

                                        if (failed) return;

                                        db.run(
                                            `
                                            INSERT INTO activity_logs(
                                            id, username, action, description, created_at
                                            )
                                            VALUES(?,?,?,?,?)
                                            `,
                                            [
                                                uuidv4(),
                                                req.session.user?.username || "",
                                                "SALE",
                                                `Ameuza ${idadi} ${bidhaa.jina}`,
                                                now
                                            ],
                                            (err) => {

                                                if (err) return fail();
                                                if (failed) return;

                                                const newIdadi = Number(bidhaa.idadi) - Number(idadi);

                                                const afterNotify = () => {

                                                    if (failed) return;

                                                    db.run("COMMIT", (err) => {

                                                        if (err) return fail();

                                                        res.json({
                                                            success: true,
                                                            saleId,
                                                            jumla,
                                                            faidaGhafi,
                                                            zaka,
                                                            sadaka,
                                                            faidaHalisi,
                                                            deni
                                                        });

                                                    });

                                                };

                                                if (newIdadi <= Number(bidhaa.low_stock_limit || 2)) {

                                                    db.run(
                                                        `
                                                        INSERT INTO notifications(id, title, message, type, created_at)
                                                        VALUES(?,?,?,?,?)
                                                        `,
                                                        [
                                                            uuidv4(),
                                                            "LOW STOCK",
                                                            `${bidhaa.jina} imebaki ${newIdadi}`,
                                                            "WARNING",
                                                            now
                                                        ],
                                                        (err) => {
                                                            if (err) return fail();
                                                            afterNotify();
                                                        }
                                                    );

                                                } else {
                                                    afterNotify();
                                                }

                                            }
                                        );

                                    };

                                    if (deni > 0) {

                                        db.run(
                                            `
                                            INSERT INTO madeni_kudai(
                                            id, mauzo_id, mteja_jina, kiasi_asili,
                                            kiasi_kilicholipwa, kiasi_baki, status, created_at, updated_at
                                            )
                                            VALUES(?,?,?,?,?,?,?,?,?)
                                            `,
                                            [
                                                uuidv4(), saleId, mteja_jina, jumla,
                                                malipo, deni, "DENI", now, now
                                            ],
                                            (err) => {
                                                if (err) return fail();
                                                afterDeni();
                                            }
                                        );

                                    } else {
                                        afterDeni();
                                    }

                                };

                                /* HIFADHI CUSTOMER */

                                if (mteja_jina) {

                                    db.get(
                                        "SELECT * FROM customers WHERE jina = ? AND deleted = 0",
                                        [mteja_jina],
                                        (err, customer) => {

                                            if (err) return fail();
                                            if (failed) return;

                                            if (!customer) {

                                                db.run(
                                                    `
                                                    INSERT INTO customers(id, jina, created_at, updated_at, deleted, synced)
                                                    VALUES(?,?,?,?,0,0)
                                                    `,
                                                    [uuidv4(), mteja_jina, now, now],
                                                    (err) => {
                                                        if (err) return fail();
                                                        afterCustomer();
                                                    }
                                                );

                                            } else {
                                                afterCustomer();
                                            }

                                        }
                                    );

                                } else {
                                    afterCustomer();
                                }

                            }
                        );

                    }
                );

            });

            /* ============ TRANSACTION END ============ */

        }
    );

});

module.exports = router;
