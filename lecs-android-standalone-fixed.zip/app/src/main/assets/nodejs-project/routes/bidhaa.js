const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../database/db");

const router = express.Router();

/* =========================
SAVE ACTIVITY LOG
========================= */

function saveLog(username, action, description) {

db.run(
    `INSERT INTO activity_logs
    (
        id,
        username,
        action,
        description,
        created_at
    )
    VALUES (?,?,?,?,?)`,
    [
        uuidv4(),
        username,
        action,
        description,
        new Date().toISOString()
    ]
);

}

/* =========================
CREATE NOTIFICATION
========================= */

function createNotification(title, message, type = "INFO") {

db.run(
    `INSERT INTO notifications
    (
        id,
        title,
        message,
        type,
        created_at
    )
    VALUES (?,?,?,?,?)`,
    [
        uuidv4(),
        title,
        message,
        type,
        new Date().toISOString()
    ]
);

}

/* =========================
GET ALL PRODUCTS
========================= */

router.get("/", (req, res) => {

const page = parseInt(req.query.page) || 1;
const limit = parseInt(req.query.limit) || 20;
const search = req.query.search || "";

const offset = (page - 1) * limit;

db.all(
    `
    SELECT
    bidhaa.*,
    suppliers.jina AS supplier_name

    FROM bidhaa

    LEFT JOIN suppliers
    ON suppliers.id = bidhaa.supplier_id

    WHERE bidhaa.deleted = 0
    AND bidhaa.jina LIKE ?

    ORDER BY bidhaa.jina ASC

    LIMIT ?
    OFFSET ?
    `,
    [
        `%${search}%`,
        limit,
        offset
    ],
    (err, rows) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Database Error"
            });
        }

        db.get(
            `
            SELECT COUNT(*) total
            FROM bidhaa
            WHERE deleted = 0
            AND jina LIKE ?
            `,
            [
                `%${search}%`
            ],
            (err, count) => {

                if (err) {
                    return res.status(500).json({
                        success: false
                    });
                }

                res.json({
                    success: true,
                    data: rows,
                    currentPage: page,
                    totalRows: count.total,
                    totalPages: Math.ceil(count.total / limit)
                });

            }
        );

    }
);

});

/* =========================
GET SINGLE PRODUCT
========================= */

router.get("/:id", (req, res) => {

db.get(
    `
    SELECT *
    FROM bidhaa
    WHERE id = ?
    AND deleted = 0
    `,
    [req.params.id],
    (err, row) => {

        if (err) {
            return res.status(500).json({
                success: false
            });
        }

        res.json(row || {});

    }
);

});

/* =========================
ADD PRODUCT
========================= */

router.post("/", (req, res) => {

const {
    jina,
    idadi,
    bei_kununua,
    bei_kuuza,
    barcode,
    supplier_id,
    low_stock_limit
} = req.body;

if (!jina) {

    return res.status(400).json({
        success: false,
        message: "Jina la bidhaa linahitajika"
    });

}

const id = uuidv4();
const now = new Date().toISOString();

db.run(
    `
    INSERT INTO bidhaa
    (
        id,
        jina,
        idadi,
        bei_kununua,
        bei_kuuza,
        barcode,
        supplier_id,
        low_stock_limit,
        created_at,
        updated_at,
        deleted,
        synced
    )
    VALUES
    (?,?,?,?,?,?,?,?,?,?,0,0)
    `,
    [
        id,
        jina,
        Number(idadi || 0),
        Number(bei_kununua || 0),
        Number(bei_kuuza || 0),
        barcode || "",
        supplier_id || "",
        Number(low_stock_limit || 2),
        now,
        now
    ],
    (err) => {

        if (err) {

            return res.status(500).json({
                success: false,
                message: "Imeshindikana kuongeza bidhaa"
            });

        }

        saveLog(
            "SYSTEM",
            "ADD_PRODUCT",
            `Bidhaa ${jina} imeongezwa`
        );

        if (Number(idadi || 0) <= Number(low_stock_limit || 2)) {

            createNotification(
                "LOW STOCK",
                `${jina} imebaki ${idadi}`,
                "WARNING"
            );

        }

        res.json({
            success: true,
            id
        });

    }
);

});

/* =========================
UPDATE PRODUCT
========================= */

router.put("/:id", (req, res) => {

const {
    jina,
    idadi,
    bei_kununua,
    bei_kuuza,
    barcode,
    supplier_id,
    low_stock_limit
} = req.body;

db.run(
    `
    UPDATE bidhaa
    SET
    jina = ?,
    idadi = ?,
    bei_kununua = ?,
    bei_kuuza = ?,
    barcode = ?,
    supplier_id = ?,
    low_stock_limit = ?,
    updated_at = ?

    WHERE id = ?
    `,
    [
        jina,
        idadi,
        bei_kununua,
        bei_kuuza,
        barcode,
        supplier_id,
        low_stock_limit,
        new Date().toISOString(),
        req.params.id
    ],
    function (err) {

        if (err) {

            return res.status(500).json({
                success: false
            });

        }

        saveLog(
            "SYSTEM",
            "UPDATE_PRODUCT",
            `Bidhaa ${jina} imehaririwa`
        );

        if (Number(idadi) <= Number(low_stock_limit || 2)) {

            createNotification(
                "LOW STOCK",
                `${jina} imebaki ${idadi}`,
                "WARNING"
            );

        }

        res.json({
            success: true,
            changes: this.changes
        });

    }
);

});

/* =========================
DELETE PRODUCT
========================= */

router.delete("/:id", (req, res) => {

db.run(
    `
    UPDATE bidhaa
    SET
    deleted = 1,
    updated_at = ?

    WHERE id = ?
    `,
    [
        new Date().toISOString(),
        req.params.id
    ],
    function (err) {

        if (err) {

            return res.status(500).json({
                success: false
            });

        }

        saveLog(
            "SYSTEM",
            "DELETE_PRODUCT",
            `Bidhaa ${req.params.id} imefutwa`
        );

        res.json({
            success: true
        });

    }
);

});

/* =========================
LOW STOCK PRODUCTS
========================= */

router.get("/alerts/low-stock", (req, res) => {

db.all(
    `
    SELECT *
    FROM bidhaa

    WHERE deleted = 0
    AND idadi <= low_stock_limit

    ORDER BY idadi ASC
    `,
    [],
    (err, rows) => {

        if (err) {

            return res.status(500).json({
                success: false
            });

        }

        res.json(rows);

    }
);

});

module.exports = router;