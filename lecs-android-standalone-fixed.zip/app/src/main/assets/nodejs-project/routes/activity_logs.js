const express = require("express");
const db = require("../database/db");

const router = express.Router();

/* =========================
GET ACTIVITY LOGS
========================= */

router.get("/", (req,res)=>{

const page =
parseInt(req.query.page) || 1;

const limit =
parseInt(req.query.limit) || 50;

const search =
req.query.search || "";

const offset =
(page - 1) * limit;

db.all(
    `
    SELECT *

    FROM activity_logs

    WHERE deleted = 0

    AND (
        username LIKE ?
        OR action LIKE ?
        OR description LIKE ?
    )

    ORDER BY created_at DESC

    LIMIT ?

    OFFSET ?
    `,
    [
        "%" + search + "%",
        "%" + search + "%",
        "%" + search + "%",
        limit,
        offset
    ],
    (err,rows)=>{

        if(err){

            return res.status(500).json({
                success:false,
                message:"Database Error"
            });

        }

        db.get(
            `
            SELECT COUNT(*) total

            FROM activity_logs

            WHERE deleted = 0

            AND (
                username LIKE ?
                OR action LIKE ?
                OR description LIKE ?
            )
            `,
            [
                "%" + search + "%",
                "%" + search + "%",
                "%" + search + "%"
            ],
            (err,count)=>{

                if(err){

                    return res.status(500).json({
                        success:false
                    });

                }

                res.json({

                    success:true,

                    data:rows,

                    currentPage:page,

                    totalRows:
                    count.total,

                    totalPages:
                    Math.ceil(
                        count.total /
                        limit
                    )

                });

            }
        );

    }
);

});

module.exports = router;