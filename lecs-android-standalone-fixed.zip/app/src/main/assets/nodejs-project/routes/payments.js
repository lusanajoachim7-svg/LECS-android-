const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../database/db");

const router = express.Router();

/* LIPA SUPPLIER */

router.post("/", (req,res)=>{

const {
supplier_id,
order_id,
kiasi,
reference
} = req.body;

const amount = Number(kiasi || 0);

if(!supplier_id || !order_id || amount <= 0){

return res.status(400).json({
success:false,
message:"Taarifa si sahihi"
});

}

db.get(
"SELECT * FROM orders WHERE id = ? AND deleted = 0",
[order_id],
(err,order)=>{

if(err){

return res.status(500).json({
success:false,
message:"Database Error"
});

}

if(!order){

return res.status(404).json({
success:false,
message:"Order haijapatikana"
});

}

/* CHECK OVERPAYMENT */
const currentPaid =
Number(order.kiasi_kilicholipwa);

const totalOrder =
Number(order.jumla_order);

let newPaid =
currentPaid + amount;

if(newPaid > totalOrder){
newPaid = totalOrder;
}

const newBalance =
totalOrder - newPaid;

const status =
newBalance <= 0 ? "PAID" : "DENI";

/* SAVE PAYMENT */
db.run(
"INSERT INTO supplier_payments ( id, supplier_id, order_id, kiasi, reference, created_at, updated_at ) VALUES (?,?,?,?,?,?,?)",
[
uuidv4(),
supplier_id,
order_id,
amount,
reference || "",
new Date().toISOString(),
new Date().toISOString()
],
(err)=>{

if(err){

return res.status(500).json({
success:false,
message:"Payment Save Error"
});

}

/* UPDATE ORDER */
db.run(
"UPDATE orders SET kiasi_kilicholipwa = ?, kiasi_baki = ?, status = ?, updated_at = ? WHERE id = ?",
[
newPaid,
newBalance,
status,
new Date().toISOString(),
order_id
],
(err)=>{

if(err){

return res.status(500).json({
success:false,
message:"Order Update Error"
});

}

res.json({
success:true,
kiasi_kilicholipwa:newPaid,
kiasi_baki:newBalance,
status
});

}
);

});

});

});

module.exports = router;