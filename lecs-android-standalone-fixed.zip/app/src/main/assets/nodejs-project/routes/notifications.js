const express = require("express");
const db = require("../database/db");

const router = express.Router();

/* =========================
GET NOTIFICATIONS (newest first)
========================= */

router.get("/", (req, res) => {

    const limit = parseInt(req.query.limit) || 50;

    db.all(
        `
        SELECT *
        FROM notifications
        WHERE deleted = 0
        ORDER BY created_at DESC
        LIMIT ?
        `,
        [limit],
        (err, rows) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Database Error"
                });
            }

            res.json(rows);

        }
    );

});

/* =========================
UNREAD COUNT (for a notification bell badge)
========================= */

router.get("/unread-count", (req, res) => {

    db.get(
        "SELECT COUNT(*) total FROM notifications WHERE deleted = 0 AND is_read = 0",
        [],
        (err, row) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json({ total: row.total });

        }
    );

});

/* =========================
MARK ONE AS READ
========================= */

router.put("/:id/read", (req, res) => {

    db.run(
        "UPDATE notifications SET is_read = 1 WHERE id = ?",
        [req.params.id],
        function (err) {

            if (err) {
                return res.status(500).json({ success: false });
            }

            res.json({ success: true, changes: this.changes });

        }
    );

});

/* =========================
MARK ALL AS READ
========================= */

router.put("/read-all", (req, res) => {

    db.run(
        "UPDATE notifications SET is_read = 1 WHERE deleted = 0 AND is_read = 0",
        [],
        function (err) {

            if (err) {
                return res.status(500).json({ success: false });
            }

            res.json({ success: true, changes: this.changes });

        }
    );

});

module.exports = router;
