const express = require("express");
const db = require("../database/db");

const router = express.Router();

/* HELPERS */

function get(sql, params = []) {

return new Promise((resolve, reject) => {

    db.get(sql, params, (err, row) => {

        if (err) reject(err);
        else resolve(row);

    });

});

}

function all(sql, params = []) {

return new Promise((resolve, reject) => {

    db.all(sql, params, (err, rows) => {

        if (err) reject(err);
        else resolve(rows);

    });

});

}

/* REPORTS DASHBOARD */

router.get("/", async (req, res) => {

try {

    const mauzoMwaka = await get(`
        SELECT COALESCE(SUM(jumla),0) total
        FROM mauzo
        WHERE deleted = 0
        AND strftime('%Y',created_at)=strftime('%Y','now')
    `);

    const mauzoMwezi = await get(`
        SELECT COALESCE(SUM(jumla),0) total
        FROM mauzo
        WHERE deleted = 0
        AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now')
    `);

    const mauzoWiki = await get(`
        SELECT COALESCE(SUM(jumla),0) total
        FROM mauzo
        WHERE deleted = 0
        AND DATE(created_at)>=DATE('now','-6 day')
    `);

    const faidaMwaka = await get(`
        SELECT COALESCE(SUM(faida_halisi),0) total
        FROM mauzo
        WHERE deleted = 0
        AND strftime('%Y',created_at)=strftime('%Y','now')
    `);

    const faidaMwezi = await get(`
        SELECT COALESCE(SUM(faida_halisi),0) total
        FROM mauzo
        WHERE deleted = 0
        AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now')
    `);

    const faidaWiki = await get(`
        SELECT COALESCE(SUM(faida_halisi),0) total
        FROM mauzo
        WHERE deleted = 0
        AND DATE(created_at)>=DATE('now','-6 day')
    `);

    const weeklySalesRows = await all(`
        SELECT
        DATE(created_at) date,
        COALESCE(SUM(jumla),0) total
        FROM mauzo
        WHERE deleted = 0
        AND DATE(created_at)>=DATE('now','-6 day')
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at)
    `);

    const weeklyProfitRows = await all(`
        SELECT
        DATE(created_at) date,
        COALESCE(SUM(faida_halisi),0) total
        FROM mauzo
        WHERE deleted = 0
        AND DATE(created_at)>=DATE('now','-6 day')
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at)
    `);

    const monthSalesRows = await all(`
        SELECT
        ((CAST(strftime('%d',created_at) AS INTEGER)-1)/7)+1 week_no,
        COALESCE(SUM(jumla),0) total
        FROM mauzo
        WHERE deleted=0
        AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now')
        GROUP BY week_no
        ORDER BY week_no
    `);

    const monthProfitRows = await all(`
        SELECT
        ((CAST(strftime('%d',created_at) AS INTEGER)-1)/7)+1 week_no,
        COALESCE(SUM(faida_halisi),0) total
        FROM mauzo
        WHERE deleted=0
        AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now')
        GROUP BY week_no
        ORDER BY week_no
    `);

    const yearSalesRows = await all(`
        SELECT
        strftime('%m',created_at) mwezi,
        COALESCE(SUM(jumla),0) total
        FROM mauzo
        WHERE deleted=0
        AND strftime('%Y',created_at)=strftime('%Y','now')
        GROUP BY mwezi
        ORDER BY mwezi
    `);

    const yearProfitRows = await all(`
        SELECT
        strftime('%m',created_at) mwezi,
        COALESCE(SUM(faida_halisi),0) total
        FROM mauzo
        WHERE deleted=0
        AND strftime('%Y',created_at)=strftime('%Y','now')
        GROUP BY mwezi
        ORDER BY mwezi
    `);

    res.json({

        success: true,

        mauzoMwaka: mauzoMwaka.total,
        mauzoMwezi: mauzoMwezi.total,
        mauzoWiki: mauzoWiki.total,

        faidaMwaka: faidaMwaka.total,
        faidaMwezi: faidaMwezi.total,
        faidaWiki: faidaWiki.total,

        weeklySales: {
            labels: weeklySalesRows.map(x => x.date),
            values: weeklySalesRows.map(x => x.total)
        },

        weeklyProfit: {
            labels: weeklyProfitRows.map(x => x.date),
            values: weeklyProfitRows.map(x => x.total)
        },

        monthSales: {
            labels: monthSalesRows.map(x => "Week " + x.week_no),
            values: monthSalesRows.map(x => x.total)
        },

        monthProfit: {
            labels: monthProfitRows.map(x => "Week " + x.week_no),
            values: monthProfitRows.map(x => x.total)
        },

        yearSales: {
            labels: yearSalesRows.map(x => x.mwezi),
            values: yearSalesRows.map(x => x.total)
        },

        yearProfit: {
            labels: yearProfitRows.map(x => x.mwezi),
            values: yearProfitRows.map(x => x.total)
        }

    });

} catch (err) {

    console.log(err);

    res.status(500).json({
        success: false,
        message: "Reports Error"
    });

}

});

/* =========================
TOP SELLING PRODUCTS
========================= */

router.get("/top-products", async (req, res) => {

    try {

        const rows = await all(`
            SELECT
            bidhaa.jina,
            COALESCE(SUM(mauzo.idadi), 0) totalSold,
            COALESCE(SUM(mauzo.jumla), 0) totalSales
            FROM mauzo
            LEFT JOIN bidhaa ON bidhaa.id = mauzo.bidhaa_id
            WHERE mauzo.deleted = 0
            GROUP BY mauzo.bidhaa_id
            ORDER BY totalSold DESC
            LIMIT 10
        `);

        res.json({ success: true, data: rows });

    } catch (err) {

        console.log(err);
        res.status(500).json({ success: false, message: "Reports Error" });

    }

});

/* =========================
LOW STOCK ALERTS
========================= */

router.get("/low-stock", async (req, res) => {

    try {

        const rows = await all(`
            SELECT jina, idadi, low_stock_limit
            FROM bidhaa
            WHERE deleted = 0
            AND idadi <= low_stock_limit
            ORDER BY idadi ASC
        `);

        res.json({ success: true, data: rows });

    } catch (err) {

        console.log(err);
        res.status(500).json({ success: false, message: "Reports Error" });

    }

});

/* =========================
SALES FOR A SPECIFIC DATE
========================= */

router.get("/sales-by-date", async (req, res) => {

    try {

        const date = req.query.date || new Date().toISOString().split("T")[0];

        const rows = await all(
            `
            SELECT mteja_jina, jumla, created_at
            FROM mauzo
            WHERE deleted = 0
            AND DATE(created_at) = ?
            ORDER BY created_at DESC
            `,
            [date]
        );

        res.json({ success: true, data: rows });

    } catch (err) {

        console.log(err);
        res.status(500).json({ success: false, message: "Reports Error" });

    }

});

/* =========================
EXPORT — CSV (opens directly in Excel)
========================= */

router.get("/export/csv", async (req, res) => {

    try {

        const rows = await all(`
            SELECT
            mauzo.created_at,
            mauzo.mteja_jina,
            bidhaa.jina AS bidhaa,
            mauzo.idadi,
            mauzo.bei_kuuza,
            mauzo.jumla,
            mauzo.faida_halisi,
            mauzo.status
            FROM mauzo
            LEFT JOIN bidhaa ON bidhaa.id = mauzo.bidhaa_id
            WHERE mauzo.deleted = 0
            ORDER BY mauzo.created_at DESC
        `);

        const header = "Tarehe,Mteja,Bidhaa,Idadi,Bei,Jumla,Faida Halisi,Status";

        const escapeCsv = (val) => {
            const s = String(val ?? "");
            return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
        };

        const lines = rows.map(r => [
            r.created_at, r.mteja_jina, r.bidhaa, r.idadi,
            r.bei_kuuza, r.jumla, r.faida_halisi, r.status
        ].map(escapeCsv).join(","));

        const csv = [header, ...lines].join("\n");

        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="lecs-ripoti-${Date.now()}.csv"`);
        res.send(csv);

    } catch (err) {

        console.log(err);
        res.status(500).json({ success: false, message: "Export Error" });

    }

});

/* =========================
EXPORT — Printable HTML (person hits Ctrl+P / Save as PDF)
========================= */

router.get("/export/pdf", async (req, res) => {

    try {

        const rows = await all(`
            SELECT
            mauzo.created_at,
            mauzo.mteja_jina,
            bidhaa.jina AS bidhaa,
            mauzo.idadi,
            mauzo.jumla,
            mauzo.faida_halisi,
            mauzo.status
            FROM mauzo
            LEFT JOIN bidhaa ON bidhaa.id = mauzo.bidhaa_id
            WHERE mauzo.deleted = 0
            ORDER BY mauzo.created_at DESC
            LIMIT 500
        `);

        const fedha = (n) => Number(n || 0).toLocaleString("en-US");

        const rowsHtml = rows.map(r => `
            <tr>
                <td>${new Date(r.created_at).toLocaleString()}</td>
                <td>${r.mteja_jina || "-"}</td>
                <td>${r.bidhaa || "-"}</td>
                <td>${r.idadi}</td>
                <td>${fedha(r.jumla)}</td>
                <td>${fedha(r.faida_halisi)}</td>
                <td>${r.status}</td>
            </tr>
        `).join("");

        res.send(`
            <!DOCTYPE html>
            <html lang="sw">
            <head>
                <meta charset="UTF-8">
                <title>LECS Ripoti</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 24px; color: #111; }
                    h1 { margin-bottom: 4px; }
                    table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13px; }
                    th, td { border: 1px solid #ccc; padding: 6px 8px; text-align: left; }
                    th { background: #f2f2f2; }
                    @media print { button { display: none; } }
                </style>
            </head>
            <body onload="window.print()">
                <h1>LECS — Ripoti ya Mauzo</h1>
                <p>Imetolewa: ${new Date().toLocaleString()}</p>
                <button onclick="window.print()">🖨 Print / Save as PDF</button>
                <table>
                    <thead>
                        <tr>
                            <th>Tarehe</th><th>Mteja</th><th>Bidhaa</th><th>Idadi</th>
                            <th>Jumla</th><th>Faida Halisi</th><th>Status</th>
                        </tr>
                    </thead>
                    <tbody>${rowsHtml}</tbody>
                </table>
            </body>
            </html>
        `);

    } catch (err) {

        console.log(err);
        res.status(500).send("Export Error");

    }

});

module.exports = router;