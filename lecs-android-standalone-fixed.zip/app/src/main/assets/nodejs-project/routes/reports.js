const express = require("express");
const db = require("../database/db");
const { startOfTodayUTC, startOfWeekUTC, endOfWeekUTC, startOfMonthUTC, endOfMonthUTC, startOfYearUTC, daysAgoStartUTC, localDateLabel } = require("../utils/localDate");

const router = express.Router();

/* HELPERS */

function get(sql, params = []) {

return new Promise((resolve, reject) => {

    db.get(sql, params, (err, row) => {

        if (err) reject(err);
        else resolve(row);

    });

});

}

function all(sql, params = []) {

return new Promise((resolve, reject) => {

    db.all(sql, params, (err, rows) => {

        if (err) reject(err);
        else resolve(rows);

    });

});

}

/* REPORTS DASHBOARD */

router.get("/", async (req, res) => {

try {

    const mauzoMwaka = await get(
        `SELECT COALESCE(SUM(jumla),0) total
         FROM mauzo
         WHERE deleted = 0
         AND created_at >= ?`,
        [startOfYearUTC()]
    );

    const mauzoMwezi = await get(
        `SELECT COALESCE(SUM(jumla),0) total
         FROM mauzo
         WHERE deleted = 0
         AND created_at >= ?
         AND created_at <= ?`,
        [startOfMonthUTC(), endOfMonthUTC()]
    );

    const mauzoWiki = await get(
        `SELECT COALESCE(SUM(jumla),0) total
         FROM mauzo
         WHERE deleted = 0
         AND created_at >= ?
         AND created_at <= ?`,
        [startOfWeekUTC(), endOfWeekUTC()]
    );

    const faidaMwaka = await get(
        `SELECT COALESCE(SUM(faida_halisi),0) total
         FROM mauzo
         WHERE deleted = 0
         AND created_at >= ?`,
        [startOfYearUTC()]
    );

    const faidaMwezi = await get(
        `SELECT COALESCE(SUM(faida_halisi),0) total
         FROM mauzo
         WHERE deleted = 0
         AND created_at >= ?
         AND created_at <= ?`,
        [startOfMonthUTC(), endOfMonthUTC()]
    );

    const faidaWiki = await get(
        `SELECT COALESCE(SUM(faida_halisi),0) total
         FROM mauzo
         WHERE deleted = 0
         AND created_at >= ?
         AND created_at <= ?`,
        [startOfWeekUTC(), endOfWeekUTC()]
    );

    // Expenses for the same periods, so Reports can show real net
    // profit (sales profit minus actual running costs), not just
    // gross sales profit.
    const gharamaWiki = await get(
        `SELECT COALESCE(SUM(kiasi),0) total FROM expenses
         WHERE deleted = 0 AND created_at >= ? AND created_at <= ?`,
        [startOfWeekUTC(), endOfWeekUTC()]
    );

    const gharamaMwezi = await get(
        `SELECT COALESCE(SUM(kiasi),0) total FROM expenses
         WHERE deleted = 0 AND created_at >= ? AND created_at <= ?`,
        [startOfMonthUTC(), endOfMonthUTC()]
    );

    const gharamaMwaka = await get(
        `SELECT COALESCE(SUM(kiasi),0) total FROM expenses
         WHERE deleted = 0 AND created_at >= ?`,
        [startOfYearUTC()]
    );

    const weeklySalesRaw = await all(
        `SELECT created_at, jumla FROM mauzo
         WHERE deleted = 0 AND created_at >= ? AND created_at <= ?
         ORDER BY created_at ASC`,
        [startOfWeekUTC(), endOfWeekUTC()]
    );
    const weeklySalesMap = {};
    weeklySalesRaw.forEach(r => {
        const label = localDateLabel(r.created_at);
        weeklySalesMap[label] = (weeklySalesMap[label] || 0) + Number(r.jumla || 0);
    });
    const weeklySalesRows = Object.keys(weeklySalesMap).sort().map(date => ({ date, total: weeklySalesMap[date] }));

    const weeklyProfitRaw = await all(
        `SELECT created_at, faida_halisi FROM mauzo
         WHERE deleted = 0 AND created_at >= ? AND created_at <= ?
         ORDER BY created_at ASC`,
        [startOfWeekUTC(), endOfWeekUTC()]
    );
    const weeklyProfitMap = {};
    weeklyProfitRaw.forEach(r => {
        const label = localDateLabel(r.created_at);
        weeklyProfitMap[label] = (weeklyProfitMap[label] || 0) + Number(r.faida_halisi || 0);
    });
    const weeklyProfitRows = Object.keys(weeklyProfitMap).sort().map(date => ({ date, total: weeklyProfitMap[date] }));

    const monthSalesRaw = await all(
        `SELECT created_at, jumla FROM mauzo
         WHERE deleted = 0 AND created_at >= ? AND created_at <= ?
         ORDER BY created_at ASC`,
        [startOfMonthUTC(), endOfMonthUTC()]
    );
    const monthSalesMap = {};
    monthSalesRaw.forEach(r => {
        const day = Number(localDateLabel(r.created_at).split("-")[2]);
        const weekNo = Math.floor((day - 1) / 7) + 1;
        monthSalesMap[weekNo] = (monthSalesMap[weekNo] || 0) + Number(r.jumla || 0);
    });
    const monthSalesRows = Object.keys(monthSalesMap).map(Number).sort((a,b)=>a-b).map(week_no => ({ week_no, total: monthSalesMap[week_no] }));

    const monthProfitRaw = await all(
        `SELECT created_at, faida_halisi FROM mauzo
         WHERE deleted = 0 AND created_at >= ? AND created_at <= ?
         ORDER BY created_at ASC`,
        [startOfMonthUTC(), endOfMonthUTC()]
    );
    const monthProfitMap = {};
    monthProfitRaw.forEach(r => {
        const day = Number(localDateLabel(r.created_at).split("-")[2]);
        const weekNo = Math.floor((day - 1) / 7) + 1;
        monthProfitMap[weekNo] = (monthProfitMap[weekNo] || 0) + Number(r.faida_halisi || 0);
    });
    const monthProfitRows = Object.keys(monthProfitMap).map(Number).sort((a,b)=>a-b).map(week_no => ({ week_no, total: monthProfitMap[week_no] }));

    const yearSalesRaw = await all(
        `SELECT created_at, jumla FROM mauzo
         WHERE deleted = 0 AND created_at >= ?
         ORDER BY created_at ASC`,
        [startOfYearUTC()]
    );
    const yearSalesMap = {};
    yearSalesRaw.forEach(r => {
        const mwezi = localDateLabel(r.created_at).split("-")[1];
        yearSalesMap[mwezi] = (yearSalesMap[mwezi] || 0) + Number(r.jumla || 0);
    });
    const yearSalesRows = Object.keys(yearSalesMap).sort().map(mwezi => ({ mwezi, total: yearSalesMap[mwezi] }));

    const yearProfitRaw = await all(
        `SELECT created_at, faida_halisi FROM mauzo
         WHERE deleted = 0 AND created_at >= ?
         ORDER BY created_at ASC`,
        [startOfYearUTC()]
    );
    const yearProfitMap = {};
    yearProfitRaw.forEach(r => {
        const mwezi = localDateLabel(r.created_at).split("-")[1];
        yearProfitMap[mwezi] = (yearProfitMap[mwezi] || 0) + Number(r.faida_halisi || 0);
    });
    const yearProfitRows = Object.keys(yearProfitMap).sort().map(mwezi => ({ mwezi, total: yearProfitMap[mwezi] }));

    res.json({

        success: true,

        mauzoMwaka: mauzoMwaka.total,
        mauzoMwezi: mauzoMwezi.total,
        mauzoWiki: mauzoWiki.total,

        faidaMwaka: faidaMwaka.total,
        faidaMwezi: faidaMwezi.total,
        faidaWiki: faidaWiki.total,

        gharamaMwaka: gharamaMwaka.total,
        gharamaMwezi: gharamaMwezi.total,
        gharamaWiki: gharamaWiki.total,

        faidaHalisiMwaka: faidaMwaka.total - gharamaMwaka.total,
        faidaHalisiMwezi: faidaMwezi.total - gharamaMwezi.total,
        faidaHalisiWiki: faidaWiki.total - gharamaWiki.total,

        weeklySales: {
            labels: weeklySalesRows.map(x => x.date),
            values: weeklySalesRows.map(x => x.total)
        },

        weeklyProfit: {
            labels: weeklyProfitRows.map(x => x.date),
            values: weeklyProfitRows.map(x => x.total)
        },

        monthSales: {
            labels: monthSalesRows.map(x => "Week " + x.week_no),
            values: monthSalesRows.map(x => x.total)
        },

        monthProfit: {
            labels: monthProfitRows.map(x => "Week " + x.week_no),
            values: monthProfitRows.map(x => x.total)
        },

        yearSales: {
            labels: yearSalesRows.map(x => x.mwezi),
            values: yearSalesRows.map(x => x.total)
        },

        yearProfit: {
            labels: yearProfitRows.map(x => x.mwezi),
            values: yearProfitRows.map(x => x.total)
        }

    });

} catch (err) {

    console.log(err);

    res.status(500).json({
        success: false,
        message: "Reports Error"
    });

}

});

/* =========================
TOP SELLING PRODUCTS
========================= */

router.get("/top-products", async (req, res) => {

    try {

        const rows = await all(`
            SELECT
            bidhaa.jina,
            COALESCE(SUM(mauzo.idadi), 0) totalSold,
            COALESCE(SUM(mauzo.jumla), 0) totalSales
            FROM mauzo
            LEFT JOIN bidhaa ON bidhaa.id = mauzo.bidhaa_id
            WHERE mauzo.deleted = 0
            GROUP BY mauzo.bidhaa_id
            ORDER BY totalSold DESC
            LIMIT 10
        `);

        res.json({ success: true, data: rows });

    } catch (err) {

        console.log(err);
        res.status(500).json({ success: false, message: "Reports Error" });

    }

});

/* =========================
LOW STOCK ALERTS
========================= */

router.get("/low-stock", async (req, res) => {

    try {

        const rows = await all(`
            SELECT jina, idadi, low_stock_limit
            FROM bidhaa
            WHERE deleted = 0
            AND idadi <= low_stock_limit
            ORDER BY idadi ASC
        `);

        res.json({ success: true, data: rows });

    } catch (err) {

        console.log(err);
        res.status(500).json({ success: false, message: "Reports Error" });

    }

});

/* =========================
SALES FOR A SPECIFIC DATE
========================= */

router.get("/sales-by-date", async (req, res) => {

    try {

        const date = req.query.date || new Date().toISOString().split("T")[0];

        const rows = await all(
            `
            SELECT mteja_jina, jumla, created_at
            FROM mauzo
            WHERE deleted = 0
            AND DATE(created_at) = ?
            ORDER BY created_at DESC
            `,
            [date]
        );

        res.json({ success: true, data: rows });

    } catch (err) {

        console.log(err);
        res.status(500).json({ success: false, message: "Reports Error" });

    }

});

/* =========================
EXPORT — CSV (opens directly in Excel)
========================= */

router.get("/export/csv", async (req, res) => {

    try {

        const rows = await all(`
            SELECT
            mauzo.created_at,
            mauzo.mteja_jina,
            bidhaa.jina AS bidhaa,
            mauzo.idadi,
            mauzo.bei_kuuza,
            mauzo.jumla,
            mauzo.faida_halisi,
            mauzo.status
            FROM mauzo
            LEFT JOIN bidhaa ON bidhaa.id = mauzo.bidhaa_id
            WHERE mauzo.deleted = 0
            ORDER BY mauzo.created_at DESC
        `);

        const header = "Tarehe,Mteja,Bidhaa,Idadi,Bei,Jumla,Faida Halisi,Status";

        const escapeCsv = (val) => {
            const s = String(val ?? "");
            return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
        };

        const lines = rows.map(r => [
            r.created_at, r.mteja_jina, r.bidhaa, r.idadi,
            r.bei_kuuza, r.jumla, r.faida_halisi, r.status
        ].map(escapeCsv).join(","));

        const csv = [header, ...lines].join("\n");

        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="lecs-ripoti-${Date.now()}.csv"`);
        res.send(csv);

    } catch (err) {

        console.log(err);
        res.status(500).json({ success: false, message: "Export Error" });

    }

});

/* =========================
EXPORT — Printable HTML (person hits Ctrl+P / Save as PDF)
========================= */

router.get("/export/pdf", async (req, res) => {

    try {

        const rows = await all(`
            SELECT
            mauzo.created_at,
            mauzo.mteja_jina,
            bidhaa.jina AS bidhaa,
            mauzo.idadi,
            mauzo.jumla,
            mauzo.faida_halisi,
            mauzo.status
            FROM mauzo
            LEFT JOIN bidhaa ON bidhaa.id = mauzo.bidhaa_id
            WHERE mauzo.deleted = 0
            ORDER BY mauzo.created_at DESC
            LIMIT 500
        `);

        const fedha = (n) => Number(n || 0).toLocaleString("en-US");

        const rowsHtml = rows.map(r => `
            <tr>
                <td>${new Date(r.created_at).toLocaleString()}</td>
                <td>${r.mteja_jina || "-"}</td>
                <td>${r.bidhaa || "-"}</td>
                <td>${r.idadi}</td>
                <td>${fedha(r.jumla)}</td>
                <td>${fedha(r.faida_halisi)}</td>
                <td>${r.status}</td>
            </tr>
        `).join("");

        res.send(`
            <!DOCTYPE html>
            <html lang="sw">
            <head>
                <meta charset="UTF-8">
                <title>LECS Ripoti</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 24px; color: #111; }
                    h1 { margin-bottom: 4px; }
                    table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13px; }
                    th, td { border: 1px solid #ccc; padding: 6px 8px; text-align: left; }
                    th { background: #f2f2f2; }
                    @media print { button { display: none; } }
                </style>
            </head>
            <body onload="window.print()">
                <h1>LECS — Ripoti ya Mauzo</h1>
                <p>Imetolewa: ${new Date().toLocaleString()}</p>
                <button onclick="window.print()">🖨 Print / Save as PDF</button>
                <table>
                    <thead>
                        <tr>
                            <th>Tarehe</th><th>Mteja</th><th>Bidhaa</th><th>Idadi</th>
                            <th>Jumla</th><th>Faida Halisi</th><th>Status</th>
                        </tr>
                    </thead>
                    <tbody>${rowsHtml}</tbody>
                </table>
            </body>
            </html>
        `);

    } catch (err) {

        console.log(err);
        res.status(500).send("Export Error");

    }

});

module.exports = router;