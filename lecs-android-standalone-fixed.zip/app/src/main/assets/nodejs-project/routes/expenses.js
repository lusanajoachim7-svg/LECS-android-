const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../database/db");
const saveLog = require("../utils/logger");
const { requireAdmin } = require("../utils/permissions");
const {
    startOfTodayUTC,
    startOfWeekUTC,
    endOfWeekUTC,
    startOfMonthUTC,
    endOfMonthUTC,
    startOfYearUTC
} = require("../utils/localDate");

const router = express.Router();

/* =========================
ADD EXPENSE
========================= */
router.post("/", (req, res) => {

    const { maelezo, kiasi, category } = req.body;

    if (!maelezo || !String(maelezo).trim()) {
        return res.status(400).json({ success: false, message: "Maelezo ya gharama yanahitajika" });
    }

    const amount = Number(kiasi);
    if (!amount || amount <= 0) {
        return res.status(400).json({ success: false, message: "Weka kiasi sahihi" });
    }

    const id = uuidv4();
    const now = new Date().toISOString();

    db.run(
        `INSERT INTO expenses (id, maelezo, kiasi, category, created_at, updated_at, deleted, synced)
         VALUES (?, ?, ?, ?, ?, ?, 0, 0)`,
        [id, String(maelezo).trim(), amount, category || null, now, now],
        (err) => {

            if (err) {
                return res.status(500).json({ success: false, message: "Imeshindikana kuhifadhi gharama" });
            }

            saveLog("SYSTEM", "ADD_EXPENSE", `Gharama: ${maelezo} - ${amount}`);

            res.json({ success: true, id });

        }
    );

});

/* =========================
LIST EXPENSES (paginated, searchable)
========================= */
router.get("/", (req, res) => {

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const search = req.query.search || "";
    const offset = (page - 1) * limit;

    db.all(
        `SELECT * FROM expenses
         WHERE deleted = 0
         AND maelezo LIKE ?
         ORDER BY created_at DESC
         LIMIT ? OFFSET ?`,
        [`%${search}%`, limit, offset],
        (err, rows) => {

            if (err) {
                return res.status(500).json({ success: false, message: "Database Error" });
            }

            db.get(
                `SELECT COUNT(*) total FROM expenses WHERE deleted = 0 AND maelezo LIKE ?`,
                [`%${search}%`],
                (err2, count) => {

                    if (err2) {
                        return res.status(500).json({ success: false, message: "Database Error" });
                    }

                    res.json({
                        success: true,
                        data: rows,
                        currentPage: page,
                        totalPages: Math.ceil((count.total || 0) / limit)
                    });

                }
            );

        }
    );

});

/* =========================
SUMMARY: leo / wiki / mwezi / mwaka
Same true local-time boundaries used everywhere else in the app —
these actually reset at midnight/Sunday/month-start/year-start in the
device's real timezone, not UTC.
========================= */
router.get("/summary", (req, res) => {

    const queries = {
        leo: [startOfTodayUTC(), null],
        wiki: [startOfWeekUTC(), endOfWeekUTC()],
        mwezi: [startOfMonthUTC(), endOfMonthUTC()],
        mwaka: [startOfYearUTC(), null]
    };

    const keys = Object.keys(queries);
    const result = {};
    let remaining = keys.length;

    keys.forEach(key => {

        const [start, end] = queries[key];
        const sql = end
            ? `SELECT COALESCE(SUM(kiasi),0) total FROM expenses WHERE deleted = 0 AND created_at >= ? AND created_at <= ?`
            : `SELECT COALESCE(SUM(kiasi),0) total FROM expenses WHERE deleted = 0 AND created_at >= ?`;
        const params = end ? [start, end] : [start];

        db.get(sql, params, (err, row) => {

            result[key] = err ? 0 : (row.total || 0);
            remaining--;

            if (remaining === 0) {
                res.json({ success: true, ...result });
            }

        });

    });

});

/* =========================
DELETE EXPENSE (admin only, matching the same pattern as
products/sales — cashiers can record expenses but not remove them)
========================= */
router.delete("/:id", requireAdmin("delete_expense"), (req, res) => {

    db.run(
        `UPDATE expenses SET deleted = 1, updated_at = ? WHERE id = ?`,
        [new Date().toISOString(), req.params.id],
        function (err) {

            if (err) {
                return res.status(500).json({ success: false, message: "Imeshindikana kufuta gharama" });
            }

            saveLog("SYSTEM", "DELETE_EXPENSE", `Gharama ${req.params.id} imefutwa`);

            res.json({ success: true });

        }
    );

});

module.exports = router;
