const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../database/db");

const router = express.Router();

/* =========================
GET ALL PAYMENTS
========================= */

router.get("/", (req,res)=>{

const page =
parseInt(req.query.page) || 1;

const limit =
parseInt(req.query.limit) || 20;

const offset =
(page - 1) * limit;

db.all(
"SELECT p.*, d.mteja_jina FROM customer_payments p LEFT JOIN madeni_kudai d ON d.id = p.deni_id WHERE p.deleted = 0 ORDER BY p.created_at DESC LIMIT ? OFFSET ?",
[
limit,
offset
],
(err,rows)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(rows);

});

});

/* =========================
PAY DEBT
========================= */

router.post("/", (req,res)=>{

const { deni_id, kiasi } = req.body;

const kiasiKulipa =
Number(kiasi || 0);

if(!deni_id || kiasiKulipa <= 0){

return res.status(400).json({
success:false,
message:"Jaza taarifa sahihi"
});

}

db.get(
"SELECT * FROM madeni_kudai WHERE id = ? AND deleted = 0",
[deni_id],
(err,deni)=>{

if(err){

return res.status(500).json({
success:false
});

}

if(!deni){

return res.status(404).json({
success:false,
message:"Deni halipo"
});

}

const kiasiAsili =
Number(deni.kiasi_asili);

let newPaid =
Number(deni.kiasi_kilicholipwa) +
kiasiKulipa;

if(newPaid > kiasiAsili){

newPaid = kiasiAsili;

}

const newBalance =
kiasiAsili - newPaid;

const status =
newBalance <= 0
? "PAID"
: "DENI";

db.run(
"UPDATE madeni_kudai SET kiasi_kilicholipwa=?, kiasi_baki=?, status=?, updated_at=? WHERE id=?",
[
newPaid,
newBalance,
status,
new Date().toISOString(),
deni_id
],
(err)=>{

if(err){

return res.status(500).json({
success:false
});

}

db.run(
"INSERT INTO customer_payments( id, customer_id, deni_id, kiasi, created_at, updated_at, deleted, synced ) VALUES(?,?,?,?,?,?,0,0)",
[
uuidv4(),
deni.customer_id || null,
deni_id,
kiasiKulipa,
new Date().toISOString(),
new Date().toISOString()
],
(err)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json({
success:true,
kiasi_baki:newBalance,
status
});

});

});

});

});

/* =========================
PAYMENT HISTORY
========================= */

router.get("/history/:deni_id",(req,res)=>{

db.all(
"SELECT * FROM customer_payments WHERE deni_id = ? AND deleted = 0 ORDER BY created_at DESC",
[
req.params.deni_id
],
(err,rows)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(rows);

});

});

/* =========================
PAYMENT STATS
========================= */

router.get("/stats/summary",(req,res)=>{

db.get(
"SELECT COUNT(*) total_payments, IFNULL(SUM(kiasi),0) total_amount FROM customer_payments WHERE deleted = 0",
[],
(err,row)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(row);

});

});

module.exports = router;