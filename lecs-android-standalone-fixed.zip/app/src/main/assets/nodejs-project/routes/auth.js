const express = require("express");
const bcrypt = require("bcryptjs");

const db = require("../database/db");

const router = express.Router();

/* =========================
LOGIN
========================= */
router.post("/login", (req, res) => {

    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            success: false,
            message: "Jaza username na password"
        });
    }

    db.get(
        "SELECT * FROM users WHERE username = ? AND deleted = 0",
        [username],
        async (err, user) => {

            if (err) {
                console.error(err);
                return res.status(500).json({
                    success: false,
                    message: "Server Error"
                });
            }

            if (!user) {
                return res.status(401).json({
                    success: false,
                    message: "Username au Password si sahihi"
                });
            }

            const valid = await bcrypt.compare(password, user.password_hash);

            if (!valid) {
                return res.status(401).json({
                    success: false,
                    message: "Username au Password si sahihi"
                });
            }

            /* SAVE SESSION */
            req.session.user = {
                id: user.id,
                username: user.username,
                jina: user.jina,
                role: user.role,
                must_change_password: !!user.must_change_password
            };

            return res.json({
                success: true,
                message: "Login successful",
                user: req.session.user
            });

        }
    );

});

/* =========================
CURRENT USER
========================= */
router.get("/me", (req, res) => {

    if (!req.session.user) {
        return res.status(401).json({
            success: false,
            message: "Unauthorized"
        });
    }

    res.json({
        success: true,
        user: req.session.user
    });

});

/* =========================
LOGOUT
========================= */
router.post("/logout", (req, res) => {

    req.session.destroy(() => {
        res.json({
            success: true,
            message: "Logged out"
        });
    });

});

/* =========================
CHECK LOGIN STATUS
========================= */
router.get("/check", (req, res) => {

    res.json({
        loggedIn: !!req.session.user,
        user: req.session.user || null
    });

});

module.exports = router;