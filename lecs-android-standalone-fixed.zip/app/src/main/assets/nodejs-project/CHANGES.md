# LECS v2 — Review & Changes

## 🔴 Critical fixes (the app could not start before these)
- `server.js` required three route files that didn't exist (`supplier_payments.js`, `debts.js`, `notifications.js`). Fixed the mounts and added the missing route files.
- `package.json` was missing `express-session` and had a `bcryptjs`/`bcrypt` mismatch — standardized on `bcrypt` everywhere.
- Removed the unused `jsonwebtoken` dependency (the app uses session auth, not JWT).

## 🟠 Bug fixes
- `routes/customers.js`: search query used a plain string instead of a template literal (`"%${search}%"`), so search silently matched nothing.
- `public/js/stock.js`: same bug — the product search/pagination URL and page-info text were never actually interpolated, so search and pagination didn't work.
- `routes/customer_payments.js`: queried a table `malipo_ya_madeni` that didn't exist — schema has `customer_payments`. Fixed, and now records `customer_id` too.
- `routes/payments.js` (supplier payments) existed but was never mounted anywhere — fixed the route mount (`/api/payments`).
- Added `routes/debts.js` (customer debts, mounted at `/api/madeni`) which `customer_payments.html` already depended on but never had a backend.
- Added `routes/notifications.js` (list / unread count / mark read).
- `public/js/customers.js`/`customers.html`: the page expects a customer *purchase history* (name, product, amount, date) but hit a plain customer-list endpoint with the wrong query params. Added `GET /api/customers/purchases` and pointed the page at it.
- `public/js/login.js`: stored the raw user object in `localStorage` (`[object Object]`) and read a `data.role` field that didn't exist.
- `routes/reports.js`: the reports page already called `/top-products`, `/low-stock`, `/export/excel`, and had a date-search box — none of that existed server-side. Added `/top-products`, `/low-stock`, `/sales-by-date`, `/export/csv`, `/export/pdf` (printable), and wired up `searchReport()` on the frontend.
- `routes/mauzo.js`: sale creation did several unguarded sequential writes (stock, customer, debt, log) — now wrapped in a real `BEGIN/COMMIT/ROLLBACK` transaction so a mid-write failure can't leave inconsistent data.
- `public/dashboard.html` + `public/js/dashboard.js`: the dashboard fetched **nothing** — every card showed a static `0` and the theme button wasn't wired up. Fully implemented.

## 🟢 Features added (as requested)
- **Better dashboard**: all summary cards now populate from `/api/dashboard`, plus three charts (weekly sales, sales-vs-profit trend, stock health doughnut) and a live notification badge.
- **Printable sale receipts**: after a sale, a "Chapisha Risiti" button opens a print-ready receipt (company info + line items) in a new window.
- **Reports export**: `Export PDF` opens a print-ready report page; `Export Excel` downloads a real CSV.
- **Company info**: new Settings card to set the business name/phone/email/address that appears on receipts.

## 🔒 Security hardening (as requested)
- `SESSION_SECRET` and other config now come from `.env` (see `.env.example`) instead of being hardcoded in `server.js`.
- Login is now rate-limited (10 attempts / 15 min per IP) via `express-rate-limit`.
- The seeded admin account (`creatAdmin.js`) now uses `ADMIN_PASSWORD` from `.env` if set, otherwise generates and prints a random password **once**, and forces a password change on first login (`must_change_password` flag + Settings-page banner).
- Session cookies are marked `secure` automatically when `NODE_ENV=production`.
- Added `.gitignore` so `.env` and the SQLite database are never committed by accident.

## 📱 Termux / Android compatibility fix
- `sqlite3` and `bcrypt` are native modules that need to compile C code — this reliably fails on Termux (Android's toolchain isn't standard glibc Linux). Both were swapped:
  - `sqlite3` → Node's built-in `node:sqlite` (no npm package, no compilation at all). Requires **Node 22.5+**.
  - `bcrypt` → `bcryptjs` (pure JavaScript, identical API, no compilation).
- `database/db.js` is now a thin adapter around `node:sqlite` that keeps the exact same callback-style API (`db.run`, `db.get`, `db.all`, `db.serialize`) so no route files needed to change.
- `package.json` engines requirement bumped to `>=22.5.0` accordingly.

## Setup
```bash
cp .env.example .env
# edit .env and set SESSION_SECRET (and optionally ADMIN_PASSWORD)
npm install
npm run create-admin   # prints the admin password once if you didn't set one
npm start
```

## Known limitations / good next steps
- No automated tests — recommend adding a few integration tests around `mauzo` (sales) and `payments` given the money math involved.
- SQLite is fine for a single shop but won't handle concurrent multi-device writes well at scale.
- The "Anza Wiki Mpya" (New Week) dashboard button currently just refreshes data — there's no real weekly archiving/reset logic, since the original code never defined what that should do.
