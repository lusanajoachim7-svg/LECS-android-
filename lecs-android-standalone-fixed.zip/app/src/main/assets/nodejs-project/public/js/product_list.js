function escapeHtml(s){
    return String(s || "").replace(/[&<>"']/g, c => ({
        "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"
    }[c]));
}

async function loadProductList(){

    const bodyEl = document.getElementById("productListBody");

    try{

        const search = document.getElementById("searchProduct").value || "";

        const res = await fetch("/api/bidhaa?limit=1000&search=" + encodeURIComponent(search));
        const data = await res.json();

        if(!res.ok || data.success === false){
            bodyEl.innerHTML = `<div class="empty-state">Imeshindikana kupakia bidhaa</div>`;
            return;
        }

        const rows = data.data || [];

        document.getElementById("totalCount").innerText = rows.length;
        document.getElementById("totalQty").innerText =
            rows.reduce((sum, r) => sum + Number(r.idadi || 0), 0).toLocaleString("en-US");

        if(rows.length === 0){
            bodyEl.innerHTML = `<div class="empty-state">Hakuna bidhaa zinazolingana</div>`;
            return;
        }

        bodyEl.innerHTML = rows.map(r => `
            <div class="product-row ${Number(r.idadi) <= 2 ? "low" : ""}">
                <span>${escapeHtml(r.jina)}</span>
                <span>${Number(r.idadi || 0).toLocaleString("en-US")}</span>
            </div>
        `).join("");

    }catch(err){
        bodyEl.innerHTML = `<div class="empty-state">Hitilafu: ${err.message}</div>`;
    }

}

document.getElementById("searchProduct").addEventListener("input", () => {
    loadProductList();
});

document.addEventListener("DOMContentLoaded", () => {
    loadProductList();
    // Same live-update pattern as Stock/Sales — reflects changes
    // synced in from other devices without needing to leave the page.
    setInterval(loadProductList, 6000);
});
