async function loadMadeni(){

try{

const res =
await fetch("/api/madeni");

const data =
await res.json();

const select =
document.getElementById("deni_id");

select.innerHTML = "";

if(data.length === 0){

select.innerHTML =
'<option value="">Hakuna deni</option>';

return;

}

data.forEach(item=>{

select.innerHTML += `
<option value="${item.id}">
${item.mteja_jina}
(Baki: ${item.kiasi_baki})
</option>
`;

});

}catch(err){

console.error(err);

}

}

async function lipa(){

try{

const body = {

deni_id:
document.getElementById(
"deni_id"
).value,

kiasi:
Number(
document.getElementById(
"kiasi"
).value
)

};

if(!body.deni_id){

alert("Chagua deni");

return;

}

if(body.kiasi <= 0){

alert("Weka kiasi sahihi");

return;

}

const res =
await fetch(
"/api/customer-payments",
{
method:"POST",

headers:{
"Content-Type":
"application/json"
},

body:JSON.stringify(body)
}
);

const data =
await res.json();

if(!res.ok){

document.getElementById(
"result"
).innerText =
data.message ||
"Malipo yameshindwa";

return;

}

document.getElementById(
"result"
).innerText =
`Baki: ${data.kiasi_baki}
Status: ${data.status}`;

loadMadeni();

}catch(err){

console.error(err);

document.getElementById(
"result"
).innerText =
"Tatizo la mfumo";

}

}

document.addEventListener(
"DOMContentLoaded",
loadMadeni
);