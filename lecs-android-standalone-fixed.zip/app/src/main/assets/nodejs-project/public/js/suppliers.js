function fedha(n){
    return Number(n || 0).toLocaleString("en-US");
}

async function loadSuppliers(){

try{

const res =
await fetch("/api/suppliers");

const result =
await res.json();

const suppliers =
result.data || result;

const table =
document.getElementById(
"supplierTable"
);

if(!table) return;

table.innerHTML = "";

suppliers.forEach(item=>{

table.innerHTML += `
<tr>
<td>${item.jina}</td>
<td>${item.simu || "-"}</td>
<td>${item.account_namba || "-"}</td>
<td><button onclick="viewPurchases('${item.id}','${item.jina.replace(/'/g, "\\'")}')">📦 Manunuzi</button></td>
</tr>
`;

});

}catch(err){

console.error(err);

}

}

let currentPurchasesSupplierId = null;
let currentPurchasesSupplierJina = "";

function renderUnpaidOrders(items, supplierId){

currentPurchasesSupplierId = supplierId;

const section =
document.getElementById("unpaidOrdersSection");

if(!items || items.length === 0){
section.innerHTML = "";
return;
}

// Items are flat per line-item, but payments happen per ORDER —
// dedupe down to one row per unpaid order.
const ordersById = {};

items.forEach(item=>{
if(Number(item.order_kiasi_baki) > 0 && !ordersById[item.order_id]){
ordersById[item.order_id] = {
order_id: item.order_id,
tarehe: item.tarehe,
jumla_order: item.jumla_order,
kiasi_kilicholipwa: item.order_kiasi_kilicholipwa,
kiasi_baki: item.order_kiasi_baki
};
}
});

const unpaidOrders = Object.values(ordersById);

if(unpaidOrders.length === 0){
section.innerHTML = "";
return;
}

section.innerHTML = `
<h3 style="margin-top:16px;">🧾 Madeni Yasiyolipwa</h3>
` + unpaidOrders.map(o => `
<div class="user-item">
Order ya ${(o.tarehe || "").slice(0,10)}
<br>Jumla: ${fedha(o.jumla_order)} TZS &nbsp;|&nbsp; Imelipwa: ${fedha(o.kiasi_kilicholipwa)} TZS
<br><b>Bado: ${fedha(o.kiasi_baki)} TZS</b>
<br><button onclick="openPaymentPanel('${o.order_id}', ${o.kiasi_baki})">💳 Lipa</button>
</div>
`).join("");

}

function openPaymentPanel(orderId, kiasiBaki){

document.getElementById("paymentOrderId").value = orderId;
document.getElementById("paymentSupplierId").value = currentPurchasesSupplierId;
document.getElementById("paymentOrderInfo").innerText = `Deni lililobaki: ${fedha(kiasiBaki)} TZS`;
document.getElementById("paymentAmount").value = "";
document.getElementById("paymentAmount").max = kiasiBaki;
document.getElementById("paymentReference").value = "";

document.getElementById("paymentPanel").style.display = "block";
document.getElementById("paymentPanel").scrollIntoView({behavior:"smooth"});

}

function closePaymentPanel(){
document.getElementById("paymentPanel").style.display = "none";
}

async function submitPayment(){

try{

const orderId = document.getElementById("paymentOrderId").value;
const supplierId = document.getElementById("paymentSupplierId").value;
const kiasi = Number(document.getElementById("paymentAmount").value || 0);
const reference = document.getElementById("paymentReference").value;

if(kiasi <= 0){
alert("Weka kiasi sahihi cha kulipa");
return;
}

const res =
await fetch("/api/payments", {
method:"POST",
headers:{"Content-Type":"application/json"},
body: JSON.stringify({
supplier_id: supplierId,
order_id: orderId,
kiasi: kiasi,
reference: reference
})
});

const data =
await res.json();

if(data.success === false){
alert(data.message || "Imeshindikana kuhifadhi malipo");
return;
}

alert("✅ Malipo yamehifadhiwa. Deni lililobaki: " + fedha(data.kiasi_baki) + " TZS");

closePaymentPanel();

// Refresh the purchases panel so totals/unpaid-orders reflect the
// payment just made.
viewPurchases(currentPurchasesSupplierId, currentPurchasesSupplierJina);

}catch(err){

console.error(err);
alert("Tatizo la mfumo");

}

}

async function viewPurchases(supplierId, supplierJina){

currentPurchasesSupplierJina = supplierJina;

try{

const res =
await fetch(`/api/suppliers/${supplierId}/purchases`);

const data =
await res.json();

if(data.success === false){
alert(data.message || "Imeshindikana kupata manunuzi");
return;
}

document.getElementById("purchasesSupplierName").innerText = supplierJina;

const fullyPaid = data.fully_paid;

document.getElementById("purchasesSummary").innerHTML = `
<div class="user-item">
<b>Jumla ya Bidhaa Zote:</b> ${fedha(data.jumla_yote)} TZS
<br><b>Kiasi Kilicholipwa:</b> ${fedha(data.jumla_kilicholipwa)} TZS
<br><b>Hali ya Malipo:</b> ${
    fullyPaid
    ? "✅ Malipo Yamekamilika"
    : `❌ Bado Anadai: <b>${fedha(data.jumla_baki)} TZS</b>`
}
</div>
`;

renderUnpaidOrders(data.items, supplierId);

const tbody =
document.getElementById("purchasesTable");

tbody.innerHTML = "";

if(!data.items || data.items.length === 0){
tbody.innerHTML = `<tr><td colspan="5">Hakuna manunuzi bado</td></tr>`;
}else{
data.items.forEach(item=>{
tbody.innerHTML += `
<tr>
<td>${item.bidhaa_jina}</td>
<td>${item.idadi}</td>
<td>${fedha(item.bei_kununua)}</td>
<td>${fedha(item.jumla)}</td>
<td>${(item.tarehe || "").slice(0,10)}</td>
</tr>
`;
});
}

document.getElementById("purchasesPanel").style.display = "block";
document.getElementById("purchasesPanel").scrollIntoView({behavior:"smooth"});

}catch(err){

console.error(err);
alert("Tatizo la mfumo");

}

}

function closePurchases(){
document.getElementById("purchasesPanel").style.display = "none";
}

async function ongezaSupplier(){

try{

const body = {

jina:
document.getElementById("jina").value,

simu:
document.getElementById("simu").value,

account_namba:
document.getElementById("account").value,

benki:
document.getElementById("benki").value,

tin:
document.getElementById("tin").value

};

if(!body.jina){

alert("Jina la supplier linahitajika");
return;

}

const res =
await fetch(
"/api/suppliers",
{
method:"POST",
headers:{
"Content-Type":
"application/json"
},
body:JSON.stringify(body)
}
);

const data =
await res.json();

if(data.success === false){

alert(
data.message ||
"Imeshindikana kuhifadhi supplier"
);

return;

}

document.getElementById("jina").value = "";
document.getElementById("simu").value = "";
document.getElementById("account").value = "";
document.getElementById("benki").value = "";
document.getElementById("tin").value = "";

loadSuppliers();

}catch(err){

console.error(err);

alert("Tatizo la mfumo");

}

}

document.addEventListener(
"DOMContentLoaded",
loadSuppliers
);