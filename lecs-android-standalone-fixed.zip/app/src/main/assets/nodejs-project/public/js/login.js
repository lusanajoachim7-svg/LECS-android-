async function login(){

try{

const username =
document.getElementById("username").value;

const password =
document.getElementById("password").value;

const response =
await fetch(
"/api/auth/login",
{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
username,
password
})
}
);

const data =
await response.json();

if(data.success){

localStorage.setItem(
"user",
JSON.stringify(data.user)
);

localStorage.setItem(
"role",
data.user.role
);

if(data.user.must_change_password){

window.location.href =
"/settings.html?force_password_change=1";

}else{

window.location.href =
"/dashboard.html";

}

}else{

document.getElementById(
"msg"
).innerText =
data.message ||
"Login Failed";

}

}catch(err){

console.error(err);

document.getElementById(
"msg"
).innerText =
"Server Error";

}

}

function toggleTheme(){

const body = document.body;

if(body.classList.contains("dark")){

body.classList.remove("dark");

localStorage.setItem(
"theme",
"light"
);

}else{

body.classList.add("dark");

localStorage.setItem(
"theme",
"dark"
);

}

}

window.onload = ()=>{

const theme =
localStorage.getItem(
"theme"
);

if(theme === "light"){

document.body.classList.remove(
"dark"
);

}else{

document.body.classList.add(
"dark"
);

}

};