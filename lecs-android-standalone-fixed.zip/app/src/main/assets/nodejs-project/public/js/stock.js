let currentPage = 1;
let totalPages = 1;
let currentUserRole = null;

// A product/supplier name is user-entered text, not trusted markup —
// without escaping, a name like `"><img src=x onerror=...>` would
// execute as real HTML/JS when rendered, and — since this data now
// syncs across every paired device — a single malicious entry could
// run arbitrary JS in every device's WebView, not just this one.
function escapeHtml(s){
    return String(s || "").replace(/[&<>"']/g, c => ({
        "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
    }[c]));
}

/* =====================
CURRENT USER / ROLE
===================== */

async function loadCurrentUser(){

try{

const res = await fetch("/api/auth/me");
const data = await res.json();

if(data.success && data.user){
currentUserRole = data.user.role;
const note = document.getElementById("cashierDeleteNote");
if(note) note.style.display = currentUserRole === "admin" ? "none" : "block";
}

}catch(err){
console.error(err);
}

}

/* =====================
LOAD SUPPLIERS
===================== */

async function loadSuppliers(){

try{

const res =
await fetch("/api/suppliers");

const result =
await res.json();

const suppliers =
result.data || result;

const select =
document.getElementById("supplier");

if(!select) return;

select.innerHTML =
'<option value="">Chagua Supplier</option>';

suppliers.forEach(item=>{

select.innerHTML += `

<option value="${item.id}">
${escapeHtml(item.jina)}
</option>
`;});

}catch(err){

console.error(err);

}

}

/* =====================
LOAD PRODUCTS
===================== */

async function loadProducts(){

try{

const search =
document.getElementById("search")
? document.getElementById("search").value
: "";

const res =
await fetch(
`/api/bidhaa?page=${currentPage}&limit=20&search=${encodeURIComponent(search)}`
);

const result =
await res.json();

const table =
document.getElementById("stockTable");

if(!table) return;

table.innerHTML = "";

result.data.forEach(item=>{

const row =
document.createElement("tr");

if(Number(item.idadi) <= 2){

row.classList.add("low-stock");

}

row.innerHTML = `

<td>${escapeHtml(item.jina)}</td><td>${item.idadi}</td><td>${Number(item.bei_kununua || 0).toLocaleString()}</td><td>
${item.idadi <= 2
? "🔴 LOW"
: "🟢 OK"}
</td><td>
${
currentUserRole === "admin"
? `<button class="delete-btn" onclick="deleteProduct('${item.id}')">Delete</button>`
: ""
}
</td>
`;table.appendChild(row);

});

totalPages =
result.totalPages || 1;

const pageInfo =
document.getElementById("pageInfo");

if(pageInfo){

pageInfo.innerText =
`Page ${currentPage} of ${totalPages}`;

}

}catch(err){

console.error(err);

}

}

/* =====================
ADD PRODUCT
===================== */

async function ongezaBidhaa(){

try{

const body = {

jina:
document.getElementById("jina").value.trim(),

idadi:
getRawNumber("idadi"),

bei_kununua:
getRawNumber("bei"),

barcode:
document.getElementById("barcode").value.trim(),

supplier_id:
document.getElementById("supplier").value

};

if(!body.jina){

alert("Weka jina la bidhaa");

return;

}

const res =
await fetch(
"/api/bidhaa",
{
method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify(body)
}
);

const data =
await res.json();

if(data.success === false){

alert(data.message);

return;

}

document.getElementById("jina").value = "";
document.getElementById("idadi").value = "";
document.getElementById("bei").value = "";
document.getElementById("barcode").value = "";

loadProducts();

}catch(err){

console.error(err);

alert("Tatizo la mfumo");

}

}

/* =====================
DELETE PRODUCT
===================== */

async function deleteProduct(id){

if(
!confirm(
"Una uhakika unataka kufuta bidhaa?"
)
){
return;
}

try{

const res = await fetch(
"/api/bidhaa/" + id,
{
method:"DELETE"
}
);

const data = await res.json().catch(() => ({}));

if(!res.ok || data.success === false){
alert(data.message || "Imeshindikana kufuta bidhaa (session au mtandao). Jaribu tena.");
return;
}

loadProducts();

}catch(err){

console.error(err);
alert("Imeshindikana kufuta bidhaa: " + err.message);

}

}

/* =====================
SEARCH
===================== */

function tafutaBidhaa(){

currentPage = 1;

loadProducts();

}

/* =====================
PAGINATION
===================== */

function nextPage(){

if(currentPage < totalPages){

currentPage++;

loadProducts();

}

}

function prevPage(){

if(currentPage > 1){

currentPage--;

loadProducts();

}

}

/* =====================
START
===================== */

document.addEventListener(
"DOMContentLoaded",
async ()=>{

await loadCurrentUser();

loadSuppliers();

loadProducts();

// Other devices on the same WiFi can add/sell stock at any time —
// their changes land in this device's database via background sync
// within a few seconds, but without this, the list would only ever
// reflect whatever was here when this screen first loaded. Refresh
// periodically so those changes actually become visible live.
setInterval(loadProducts, 6000);

}
);