async function loadUser(){

try{

const res =
await fetch("/api/auth/me");

if(!res.ok) return;

const user =
await res.json();

document.getElementById("userName").innerText =
user.jina || "-";

document.getElementById("userRole").innerText =
user.role || "-";

}catch(err){

console.log(err);

}

}

/* =====================
COMPANY INFO
===================== */

async function loadCompanyInfo(){

try{

    const res =
    await fetch("/api/settings/company");

    if(!res.ok) return;

    const result =
    await res.json();

    const data = result.data || {};

    if(document.getElementById("companyName")){
        document.getElementById("companyName").value = data.company_name || "";
        document.getElementById("companyPhone").value = data.company_phone || "";
        document.getElementById("companyEmail").value = data.company_email || "";
        document.getElementById("companyAddress").value = data.company_address || "";
    }

}catch(err){

    console.log(err);

}

}

async function saveCompanyInfo(){

try{

    const body = {
        company_name: document.getElementById("companyName").value.trim(),
        company_phone: document.getElementById("companyPhone").value.trim(),
        company_email: document.getElementById("companyEmail").value.trim(),
        company_address: document.getElementById("companyAddress").value.trim()
    };

    const res =
    await fetch("/api/settings/company",{
        method:"PUT",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify(body)
    });

    const data =
    await res.json();

    document.getElementById("companyResult").innerText =
    data.message || (data.success ? "Imehifadhiwa" : "Imeshindikana");

}catch(err){

    console.log(err);

    document.getElementById("companyResult").innerText =
    "Tatizo la mfumo";

}

}

/* =====================
FORCE PASSWORD CHANGE BANNER
===================== */

function checkForcePasswordChange(){

const params =
new URLSearchParams(window.location.search);

const user =
JSON.parse(localStorage.getItem("user") || "null");

const forced =
params.get("force_password_change") === "1" ||
(user && user.must_change_password);

const banner =
document.getElementById("forceChangeBanner");

if(forced && banner){
    banner.style.display = "block";
}

}

/* =====================
CHANGE PASSWORD
===================== */

async function changePassword(){

const oldPassword =
document.getElementById("oldPassword").value;

const newPassword =
document.getElementById("newPassword").value;

if(!oldPassword || !newPassword){

alert("Jaza taarifa zote");
return;

}

try{

const res =
await fetch(
"/api/settings/change-password",
{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
oldPassword,
newPassword
})
}
);

const data =
await res.json();

document.getElementById(
"passwordResult"
).innerText =
data.message;

if(data.success){

document.getElementById(
"oldPassword"
).value = "";

document.getElementById(
"newPassword"
).value = "";

const banner =
document.getElementById("forceChangeBanner");

if(banner){
banner.style.display = "none";
}

const user =
JSON.parse(localStorage.getItem("user") || "null");

if(user){
user.must_change_password = false;
localStorage.setItem("user", JSON.stringify(user));
}

}

}catch(err){

console.log(err);

}

}

/* =====================
ADD USER
===================== */

async function addUser(){

const username =
document.getElementById("newUsername").value;

const jina =
document.getElementById("newName").value;

const password =
document.getElementById("newUserPassword").value;

const role =
document.getElementById("newRole").value;

if(
!username ||
!jina ||
!password
){

alert("Jaza taarifa zote");
return;

}

try{

const res =
await fetch(
"/api/settings/users",
{
method:"POST",

headers:{
"Content-Type":
"application/json"
},

body:JSON.stringify({
username,
jina,
password,
role
})
}
);

const data =
await res.json();

alert(data.message);

if(data.success){

document.getElementById(
"newUsername"
).value = "";

document.getElementById(
"newName"
).value = "";

document.getElementById(
"newUserPassword"
).value = "";

loadUsers();

}

}catch(err){

console.log(err);

}

}

/* =====================
LOAD USERS
===================== */

async function loadUsers(){

try{

const res =
await fetch(
"/api/settings/users"
);

if(!res.ok){
return;
}

const data =
await res.json();

const box =
document.getElementById(
"usersList"
);

if(!box){
return;
}

box.innerHTML = "";

data.forEach(user=>{

box.innerHTML += `

<div class="user-item"><b>${user.jina}</b>

<br>${user.username}

<br>Role:
${user.role}

</div>`;

});

}catch(err){

console.log(err);

}

}

/* =====================
SYSTEM INFO
===================== */

async function loadSystemInfo(){

try{

const res =
await fetch(
"/api/settings/system"
);

if(!res.ok){
return;
}

const data =
await res.json();

document.getElementById(
"version"
).innerText =
data.version || "-";

document.getElementById(
"totalUsers"
).innerText =
data.totalUsers || 0;

document.getElementById(
"totalProducts"
).innerText =
data.totalProducts || 0;

document.getElementById(
"totalSuppliers"
).innerText =
data.totalSuppliers || 0;

}catch(err){

console.log(err);

}

}

/* =====================
AUTO-SYNC STATUS
===================== */

function timeAgo(ts){

if(!ts) return "bado";

const seconds = Math.floor((Date.now() - ts) / 1000);

if(seconds < 60) return seconds + "s zilizopita";

const minutes = Math.floor(seconds / 60);

if(minutes < 60) return minutes + "dk zilizopita";

return Math.floor(minutes / 60) + "hr zilizopita";

}

async function loadPeerStatus(){

try{

const res =
await fetch("/api/sync/peers");

if(!res.ok) return;

const data =
await res.json();

const countEl =
document.getElementById("peerCount");

const listEl =
document.getElementById("peersList");

if(!countEl || !listEl) return;

countEl.innerText = data.peers.length;

listEl.innerHTML = data.peers.map(p => `

<div class="user-item"><b>${p.device_name}</b>

<br>Ilionekana: ${timeAgo(p.last_seen_at)}

<br>Sync ya mwisho: ${p.last_synced_at ? new Date(p.last_synced_at).toLocaleString() : "bado"}

</div>`).join("");

}catch(err){

console.log(err);

}

}

/* =====================
BACKUP
===================== */

function backupDatabase(){

window.open(
"/api/settings/backup",
"_blank"
);

}

/* =====================
THEME
===================== */

function toggleTheme(){

document.body.classList.toggle(
"dark"
);

localStorage.setItem(
"theme",
document.body.classList.contains(
"dark"
)
? "dark"
: "light"
);

}

/* =====================
LOGOUT
===================== */

async function logout(){

const ok =
confirm(
"Unataka kutoka kwenye mfumo?"
);

if(!ok) return;

await fetch(
"/api/auth/logout",
{
method:"POST"
}
);

localStorage.clear();

window.location.href =
"/";

}

/* =====================
ON LOAD
===================== */

window.onload = ()=>{

const theme =
localStorage.getItem(
"theme"
);

if(theme === "dark"){

document.body.classList.add(
"dark"
);

}

loadUser();
loadUsers();
loadSystemInfo();
loadCompanyInfo();
checkForcePasswordChange();
loadPeerStatus();

setInterval(loadPeerStatus, 8000);

};