async function loadSuppliers(){

try{

const res =
await fetch("/api/orders/suppliers");

const data =
await res.json();

const select =
document.getElementById("supplier");

if(!select) return;

select.innerHTML = "";

data.forEach(item=>{

select.innerHTML += `
<option value="${item.id}">
${item.jina}
</option>
`;

});

}catch(err){

console.error(err);

}

}

async function hifadhiOrder(){

try{

const supplier_id =
document.getElementById("supplier").value;

const jumla =
Number(
document.getElementById("jumla").value
);

const malipo =
Number(
document.getElementById("malipo").value
);

if(!supplier_id){

alert("Chagua supplier");

return;

}

if(jumla <= 0){

alert("Jumla si sahihi");

return;

}

const body = {
supplier_id,
jumla_order: jumla,
kiasi_kilicholipwa: malipo
};

const res =
await fetch("/api/orders",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify(body)
});

const data =
await res.json();

if(!data.success){

alert(data.message || "Order imeshindikana");

return;

}

document.getElementById("baki").innerText =
data.kiasi_baki;

alert("Order imehifadhiwa");

}catch(err){

console.error(err);

alert("Tatizo la mfumo");

}

}

document.addEventListener(
"DOMContentLoaded",
loadSuppliers
);