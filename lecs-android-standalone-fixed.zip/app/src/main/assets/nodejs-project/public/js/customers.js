async function loadCustomers(){

try{

const name =
document.getElementById("searchName").value || "";

const date =
document.getElementById("searchDate").value || "";

let url =
"/api/customers/purchases?";

if(name){
url += "name=" + encodeURIComponent(name) + "&";
}

if(date){
url += "date=" + encodeURIComponent(date);
}

const res = await fetch(url);

const data = await res.json();

document.getElementById(
"totalCustomers"
).innerText = data.length;

const table =
document.getElementById(
"customerTable"
);

if(data.length === 0){

table.innerHTML = `

<tr>
<td colspan="4">
Hakuna taarifa zilizopatikana
</td>
</tr>
`;return;

}

table.innerHTML = data.map(row=>`

<tr><td>
${row.mteja_jina}
</td><td>
${row.bidhaa}
</td><td>
${Number(row.jumla)
.toLocaleString()}
</td><td>
${new Date(row.created_at)
.toLocaleDateString()}
</td></tr>`).join("");

}catch(err){

console.error(err);

document.getElementById(
"customerTable"
).innerHTML = `

<tr>
<td colspan="4">
Imeshindikana kupakia taarifa
</td>
</tr>
`;}

}

document.addEventListener(
"DOMContentLoaded",
()=>{

const today =
new Date()
.toISOString()
.split("T")[0];

document.getElementById(
"searchDate"
).value = today;

loadCustomers();

document
.getElementById("searchName")
.addEventListener(
"keyup",
loadCustomers
);

document
.getElementById("searchDate")
.addEventListener(
"change",
loadCustomers
);

}
);