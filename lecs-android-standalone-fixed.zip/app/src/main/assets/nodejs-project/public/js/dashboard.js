function fedha(n){
    return Number(n || 0).toLocaleString("en-US");
}

/* =====================
THEME
===================== */

function toggleTheme() {

    const body = document.body;

    body.classList.toggle("light");

    const currentTheme =
        body.classList.contains("light")
        ? "light"
        : "dark";

    localStorage.setItem("theme", currentTheme);

}

function loadTheme() {

    const savedTheme =
        localStorage.getItem("theme");

    if (savedTheme === "light") {
        document.body.classList.add("light");
    } else {
        document.body.classList.remove("light");
    }

}

/* =====================
DASHBOARD DATA + CARDS
===================== */

let charts = {};

function renderChart(canvasId, config){

    const canvas = document.getElementById(canvasId);
    if(!canvas) return;

    if(charts[canvasId]){
        charts[canvasId].destroy();
    }

    charts[canvasId] = new Chart(canvas, config);

}

async function loadDashboard(){

    try{

        const res = await fetch("/api/dashboard");
        const data = await res.json();

        if(!data.success){
            console.error("Dashboard load failed:", data.message);
            return;
        }

        const set = (id, value) => {
            const el = document.getElementById(id);
            if(el) el.innerText = fedha(value);
        };

        set("mauzoYote", data.mauzoYote);
        set("mauzoLeo", data.mauzoLeo);
        set("totalStock", data.totalStock);
        set("lowStock", data.lowStock);
        set("outOfStock", data.outOfStock);
        set("faidaWiki", data.faidaWiki);
        set("faidaLeo", data.faidaLeo);
        set("gharamaLeo", data.gharamaLeo);
        set("gharamaWiki", data.gharamaWiki);
        set("faidaHalisiLeo", data.faidaHalisiLeo);
        set("faidaHalisiWiki", data.faidaHalisiWiki);
        set("madeniTunadaiwa", data.madeniTunadaiwa);
        set("madeniTunadai", data.madeniTunadai);
        set("stockValue", data.stockValue);
        set("zakaSadaka", data.zakaSadaka);
        set("totalProducts", data.totalProducts);
        set("totalCustomers", data.totalCustomers);
        set("totalSuppliers", data.totalSuppliers);

        /* WEEKLY SALES BAR CHART */

        const labels = (data.salesChart || []).map(r => r.date);
        const values = (data.salesChart || []).map(r => r.total);

        renderChart("salesChart", {
            type: "bar",
            data: {
                labels,
                datasets: [{
                    label: "Mauzo",
                    data: values,
                    backgroundColor: "#2563eb",
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: ctx => fedha(ctx.raw) } }
                },
                scales: {
                    y: { ticks: { callback: v => fedha(v) } }
                }
            }
        });

        /* SALES VS PROFIT TREND (SAME 7 DAYS) */

        renderChart("trendChart", {
            type: "line",
            data: {
                labels,
                datasets: [
                    {
                        label: "Mauzo",
                        data: values,
                        borderColor: "#2563eb",
                        backgroundColor: "rgba(37,99,235,.15)",
                        tension: .4,
                        fill: true
                    },
                    {
                        label: "Faida (Wiki)",
                        data: labels.map(() => Number(data.faidaWiki) / (labels.length || 1)),
                        borderColor: "#22c55e",
                        backgroundColor: "rgba(34,197,94,.15)",
                        tension: .4,
                        fill: true,
                        borderDash: [6, 4]
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: ${fedha(ctx.raw)}` } }
                }
            }
        });

        /* STOCK HEALTH DOUGHNUT */

        const healthy = Math.max(0, Number(data.totalProducts) - Number(data.lowStock) - Number(data.outOfStock));

        renderChart("stockHealthChart", {
            type: "doughnut",
            data: {
                labels: ["Salama", "Low Stock", "Out of Stock"],
                datasets: [{
                    data: [healthy, data.lowStock, data.outOfStock],
                    backgroundColor: ["#22c55e", "#f59e0b", "#ef4444"]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });

    }catch(err){

        console.error(err);

    }

}

/* =====================
NOTIFICATIONS BADGE
===================== */

async function loadNotifBadge(){

    try{

        const res = await fetch("/api/notifications/unread-count");
        if(!res.ok) return;

        const data = await res.json();
        const badge = document.getElementById("notifBadge");

        if(!badge) return;

        if(data.total > 0){
            badge.style.display = "inline-block";
            badge.innerText = data.total;
        }else{
            badge.style.display = "none";
        }

    }catch(err){

        console.error(err);

    }

}

/* =====================
NEW WEEK BUTTON
===================== */

document.addEventListener("DOMContentLoaded", () => {

    loadTheme();
    loadDashboard();
    loadNotifBadge();

    const newWeekBtn = document.getElementById("newWeekBtn");

    if(newWeekBtn){

        newWeekBtn.addEventListener("click", () => {

            const ok = confirm("Unataka kuonyesha takwimu mpya za wiki? Hii itapakia upya dashboard.");

            if(ok){
                loadDashboard();
            }

        });

    }

    // auto-refresh every 60s
    setInterval(() => {
        loadDashboard();
        loadNotifBadge();
    }, 60000);

});
