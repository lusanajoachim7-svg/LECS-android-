let currentUserRole = null;

function fmt(n){
    return Number(n || 0).toLocaleString("en-US");
}

function escapeHtml(s){
    return String(s || "").replace(/[&<>"']/g, c => ({
        "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"
    }[c]));
}

async function loadCurrentUser(){
    try{
        const res = await fetch("/api/auth/me");
        const data = await res.json();
        if(data.success && data.user){
            currentUserRole = data.user.role;
            const note = document.getElementById("cashierDeleteNote");
            if(note) note.style.display = currentUserRole === "admin" ? "none" : "block";
        }
    }catch(err){
        console.error(err);
    }
}

async function ongezaGharama(){

    const maelezo = document.getElementById("maelezo").value.trim();
    const kiasi = getRawNumber("kiasi");
    const category = document.getElementById("category").value;
    const resultEl = document.getElementById("addResult");

    if(!maelezo){
        resultEl.innerText = "Weka maelezo ya gharama.";
        return;
    }

    if(kiasi <= 0){
        resultEl.innerText = "Weka kiasi sahihi.";
        return;
    }

    try{

        const res = await fetch("/api/expenses", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ maelezo, kiasi, category })
        });

        const data = await res.json();

        if(!res.ok || data.success === false){
            resultEl.innerText = data.message || "Imeshindikana kuhifadhi gharama.";
            return;
        }

        resultEl.innerText = "✅ Gharama imehifadhiwa.";
        document.getElementById("maelezo").value = "";
        document.getElementById("kiasi").value = "";
        document.getElementById("category").value = "";

        loadSummary();
        loadExpenses();

    }catch(err){
        resultEl.innerText = "Hitilafu: " + err.message;
    }

}

async function loadSummary(){

    try{

        const res = await fetch("/api/expenses/summary");
        const data = await res.json();

        if(!res.ok || data.success === false) return;

        document.getElementById("sumLeo").innerText = fmt(data.leo);
        document.getElementById("sumWiki").innerText = fmt(data.wiki);
        document.getElementById("sumMwezi").innerText = fmt(data.mwezi);
        document.getElementById("sumMwaka").innerText = fmt(data.mwaka);

    }catch(err){
        console.error(err);
    }

}

async function loadExpenses(){

    const listEl = document.getElementById("expensesList");

    try{

        const search = document.getElementById("searchGharama")
            ? document.getElementById("searchGharama").value
            : "";

        const res = await fetch("/api/expenses?limit=30&search=" + encodeURIComponent(search));
        const data = await res.json();

        if(!res.ok || data.success === false){
            listEl.innerHTML = `<div class="empty-state">Imeshindikana kupakia gharama</div>`;
            return;
        }

        const rows = data.data || [];

        if(rows.length === 0){
            listEl.innerHTML = `<div class="empty-state">Hakuna gharama bado</div>`;
            return;
        }

        listEl.innerHTML = rows.map(r => `
            <div class="expense-card">
                <div class="expense-top">
                    <strong>${escapeHtml(r.maelezo)}</strong>
                    <span class="expense-amount">${fmt(r.kiasi)}</span>
                </div>
                <div class="expense-bottom">
                    <span>${r.category ? escapeHtml(r.category) : "-"}</span>
                    <span>${(r.created_at || "").slice(0,10)}</span>
                </div>
                ${
                    currentUserRole === "admin"
                    ? `<button class="expense-delete-btn" data-expense-id="${r.id}">🗑️ Futa</button>`
                    : ""
                }
            </div>
        `).join("");

    }catch(err){
        listEl.innerHTML = `<div class="empty-state">Hitilafu: ${err.message}</div>`;
    }

}

document.addEventListener("click", (e) => {
    const btn = e.target.closest(".expense-delete-btn");
    if(!btn) return;
    futaGharama(btn.dataset.expenseId);
});

async function futaGharama(id){

    if(!confirm("Una uhakika unataka kufuta gharama hii?")){
        return;
    }

    try{

        const res = await fetch("/api/expenses/" + id, { method: "DELETE" });
        const data = await res.json().catch(() => ({}));

        if(!res.ok || data.success === false){
            alert(data.message || "Imeshindikana kufuta gharama.");
            return;
        }

        loadSummary();
        loadExpenses();

    }catch(err){
        alert("Hitilafu: " + err.message);
    }

}

document.getElementById("searchGharama") && document.getElementById("searchGharama").addEventListener("input", () => {
    loadExpenses();
});

document.addEventListener("DOMContentLoaded", async () => {
    await loadCurrentUser();
    loadSummary();
    loadExpenses();

    // Other devices can also record expenses — keep this screen live,
    // same pattern used on Stock/Sales.
    setInterval(() => {
        loadSummary();
        loadExpenses();
    }, 6000);
});
