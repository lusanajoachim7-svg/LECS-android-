let currentPayDebt = null;

function fmt(n) {
    return Number(n || 0).toLocaleString("en-US");
}

function fmtDate(iso) {
    if (!iso) return "-";
    const d = new Date(iso);
    return d.toLocaleDateString("sw-TZ", { year: "numeric", month: "short", day: "numeric" });
}

async function loadDebts() {

    const listEl = document.getElementById("debtList");
    listEl.innerHTML = `<div class="card"><p>Inapakia...</p></div>`;

    try {

        const search = document.getElementById("searchName").value || "";
        const onlyUnpaid = document.getElementById("onlyUnpaid").checked ? "1" : "0";

        const res = await fetch(
            "/api/madeni/detailed?search=" + encodeURIComponent(search) + "&onlyUnpaid=" + onlyUnpaid
        );
        const data = await res.json();

        if (!res.ok || data.success === false) {
            listEl.innerHTML = `<div class="card"><p>Imeshindikana kupakia madeni.</p></div>`;
            return;
        }

        const rows = data.data || [];

        if (rows.length === 0) {
            listEl.innerHTML = `<div class="card"><p>Hakuna madeni yanayolingana.</p></div>`;
            return;
        }

        listEl.innerHTML = rows.map(r => `
            <div class="card debt-card ${r.status === 'DENI' ? 'is-unpaid' : 'is-paid'}">
                <div class="debt-row-top">
                    <strong>${escapeHtml(r.mteja_jina || "Haijulikani")}</strong>
                    <span class="debt-status">${r.status === 'DENI' ? '🔴 DENI' : '✅ IMELIPWA'}</span>
                </div>
                <div class="debt-line">🛒 ${escapeHtml(r.bidhaa_jina || "-")} ${r.idadi ? "× " + r.idadi : ""}</div>
                <div class="debt-line">📅 ${fmtDate(r.created_at)}</div>
                <div class="debt-amounts">
                    <div><span>Jumla</span><strong>${fmt(r.kiasi_asili)}</strong></div>
                    <div><span>Alipa</span><strong>${fmt(r.kiasi_kilicholipwa)}</strong></div>
                    <div class="baki"><span>Baki</span><strong>${fmt(r.kiasi_baki)}</strong></div>
                </div>
                ${r.status === 'DENI'
                    ? `<button class="btn-primary pay-btn" onclick='openPayModal(${JSON.stringify(r)})'>💰 Lipa</button>`
                    : ""}
            </div>
        `).join("");

    } catch (err) {
        listEl.innerHTML = `<div class="card"><p>Hitilafu: ${err.message}</p></div>`;
    }

}

function escapeHtml(s) {
    return String(s || "").replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
}

function openPayModal(debt) {
    currentPayDebt = debt;
    document.getElementById("payModalTitle").innerText = "Lipa Deni — " + (debt.mteja_jina || "");
    document.getElementById("payModalSub").innerText =
        "Baki: " + fmt(debt.kiasi_baki) + " TSh (Jumla: " + fmt(debt.kiasi_asili) + ")";
    document.getElementById("payAmount").value = "";
    document.getElementById("payResult").innerText = "";
    document.getElementById("payModal").style.display = "flex";
}

function closePayModal() {
    document.getElementById("payModal").style.display = "none";
    currentPayDebt = null;
}

function fillFullAmount() {
    if (!currentPayDebt) return;
    document.getElementById("payAmount").value = fmt(currentPayDebt.kiasi_baki);
}

async function submitPayment() {

    if (!currentPayDebt) return;

    const amount = getRawNumber("payAmount");
    const resultEl = document.getElementById("payResult");

    if (amount <= 0) {
        resultEl.innerText = "Weka kiasi sahihi.";
        return;
    }

    try {

        const res = await fetch("/api/customer-payments", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ deni_id: currentPayDebt.id, kiasi: amount })
        });

        const data = await res.json();

        if (!res.ok || data.success === false) {
            resultEl.innerText = data.message || "Malipo yameshindikana.";
            return;
        }

        closePayModal();
        loadDebts();

    } catch (err) {
        resultEl.innerText = "Hitilafu: " + err.message;
    }

}

document.addEventListener("DOMContentLoaded", loadDebts);
