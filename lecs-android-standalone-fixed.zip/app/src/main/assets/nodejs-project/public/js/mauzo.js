let lastSaleId = null;
let currentUserRole = null;

/* =====================
CURRENT USER / ROLE
===================== */

async function loadCurrentUser(){

try{

const res = await fetch("/api/auth/me");
const data = await res.json();

if(data.success && data.user){
currentUserRole = data.user.role;
const note = document.getElementById("cashierDeleteNote");
if(note) note.style.display = currentUserRole === "admin" ? "none" : "block";
}

}catch(err){
console.error(err);
}

}

/* =====================
SALES HISTORY
===================== */

function escapeHtmlMauzo(s){
return String(s || "").replace(/[&<>"']/g, c => ({
"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
}[c]));
}

function fedha(n){
return Number(n || 0).toLocaleString("en-US");
}

async function loadSalesHistory(){

try{

const res = await fetch("/api/mauzo");
const data = await res.json();

const listEl = document.getElementById("salesHistoryList");
if(!listEl) return;

const sales = data.data || [];

if(sales.length === 0){
listEl.innerHTML = `<div class="empty-state">Hakuna mauzo bado</div>`;
return;
}

const isAdmin = currentUserRole === "admin";

listEl.innerHTML = sales.map(s => `
<div class="sale-card">
<div class="sale-card-top">
<strong>${escapeHtmlMauzo(s.bidhaa_jina || "Bidhaa")}</strong>
<span class="sale-date">${(s.created_at || "").slice(0,10)}</span>
</div>
<div class="sale-card-mteja">👤 ${escapeHtmlMauzo(s.mteja_jina || "Walk-in")}</div>
<div class="sale-card-bottom">
<span>Idadi: <strong>${s.idadi}</strong></span>
<span>Jumla: <strong>${fedha(s.jumla)}</strong></span>
</div>
${
isAdmin
? `<button class="sale-delete-btn" onclick="futaMauzo('${s.id}')">🗑️ Futa</button>`
: ""
}
</div>
`).join("");

}catch(err){
console.error(err);
}

}

async function futaMauzo(saleId){

if(!confirm("Una uhakika unataka kufuta mauzo haya? Stock itarudishwa kiotomatiki.")){
return;
}

try{

const res = await fetch(`/api/mauzo/${saleId}`, { method:"DELETE" });
const data = await res.json();

if(data.success === false){
alert(data.message || "Imeshindikana kufuta mauzo");
return;
}

loadSalesHistory();
loadProducts();

}catch(err){
console.error(err);
alert("Tatizo la mfumo");
}

}

/* =====================
PRINT RECEIPT
===================== */

async function printReceipt(){

if(!lastSaleId){
alert("Hakuna mauzo ya kuchapisha");
return;
}

try{

const res =
await fetch(`/api/mauzo/${lastSaleId}/receipt`);

const data =
await res.json();

if(!data.success){
alert(data.message || "Imeshindikana kupata risiti");
return;
}

const sale = data.sale;
const company = data.company || {};

const fedha = (n) =>
Number(n || 0).toLocaleString("en-US");

const win = window.open("", "_blank", "width=380,height=600");

win.document.write(`
<!DOCTYPE html>
<html lang="sw">
<head>
<meta charset="UTF-8">
<title>Risiti</title>
<style>
body{font-family:'Courier New',monospace;padding:16px;color:#111;max-width:320px;margin:0 auto;}
h2{text-align:center;margin-bottom:4px;}
p{margin:2px 0;font-size:13px;text-align:center;}
hr{border:none;border-top:1px dashed #333;margin:10px 0;}
table{width:100%;font-size:13px;border-collapse:collapse;}
td{padding:4px 0;}
.right{text-align:right;}
.total{font-weight:bold;font-size:15px;}
@media print{ button{display:none;} }
</style>
</head>
<body onload="window.print()">
<h2>${company.company_name || "LECS"}</h2>
<p>${company.company_address || ""}</p>
<p>${company.company_phone || ""} ${company.company_email ? " | " + company.company_email : ""}</p>
<hr>
<p>Risiti #: ${sale.id.slice(0,8).toUpperCase()}</p>
<p>Tarehe: ${new Date(sale.created_at).toLocaleString()}</p>
<p>Mteja: ${sale.mteja_jina || "Walk-in"}</p>
<hr>
<table>
<tr><td>${sale.bidhaa_jina || "Bidhaa"}</td><td class="right">x${sale.idadi}</td></tr>
<tr><td>Bei</td><td class="right">${fedha(sale.bei_kuuza)}</td></tr>
</table>
<hr>
<table>
<tr class="total"><td>JUMLA</td><td class="right">${fedha(sale.jumla)}</td></tr>
<tr><td>Kimelipwa</td><td class="right">${fedha(sale.kiasi_kilicholipwa)}</td></tr>
<tr><td>Baki (Deni)</td><td class="right">${fedha(sale.jumla - sale.kiasi_kilicholipwa)}</td></tr>
</table>
<hr>
<p>Asante kwa kununua nasi! 🙏</p>
<button onclick="window.print()">🖨 Print</button>
</body>
</html>
`);

win.document.close();

}catch(err){

console.error(err);
alert("Tatizo la mfumo");

}

}

async function loadProducts(){

try{

const res =
await fetch("/api/mauzo/bidhaa");

const bidhaa =
await res.json();

const select =
document.getElementById("bidhaa");

if(!select) return;

// Remember what's currently selected so a background refresh (new
// stock arriving from another device via sync) can't silently
// switch what the cashier is about to sell mid-transaction.
const previouslySelected = select.value;

select.innerHTML = "";

bidhaa.forEach(item=>{

select.innerHTML += `
<option value="${item.id}">
${item.jina}
(Stock: ${item.idadi})
</option>
`;

});

if(previouslySelected && bidhaa.some(item => item.id === previouslySelected)){
select.value = previouslySelected;
}

}catch(err){

console.error(err);

}

}

async function uzaBidhaa(){

try{

const body = {

bidhaa_id:
document.getElementById("bidhaa").value,

mteja_jina:
document.getElementById("mteja").value,

idadi:
getRawNumber("idadi"),

bei_kuuza:
getRawNumber("bei_kuuza"),

kiasi_kilicholipwa:
getRawNumber("malipo")

};

const res =
await fetch("/api/mauzo",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify(body)
});

const data =
await res.json();

if(!data.success){

alert(data.message);
return;

}

lastSaleId = data.saleId;

const printBtn =
document.getElementById("printReceiptBtn");

if(printBtn){
printBtn.style.display = "inline-block";
}

document.getElementById("jumla").innerText =
"Jumla: " + data.jumla;

document.getElementById("faida").innerText =
"Faida Ghafi: " + data.faidaGhafi;

document.getElementById("zaka").innerText =
"Zaka: " + data.zaka;

document.getElementById("sadaka").innerText =
"Sadaka: " + data.sadaka;

document.getElementById("halisi").innerText =
"Faida Halisi: " + data.faidaHalisi;

document.getElementById("deni").innerText =
"Deni: " + data.deni;

loadProducts();
loadSalesHistory();

}catch(err){

console.error(err);

alert("Tatizo la mfumo");

}

}

document.addEventListener(
"DOMContentLoaded",
async () => {
await loadCurrentUser();
loadProducts();
loadSalesHistory();

// A product added or restocked on another device syncs into this
// device's database within a few seconds in the background — refresh
// periodically so it actually becomes visible/sellable here without
// navigating away and back. The dropdown refresh preserves whatever
// the cashier already has selected (see loadProducts above), so this
// is safe to run even mid-sale.
setInterval(() => {
loadProducts();
loadSalesHistory();
}, 6000);
}
);