/* =====================
LOAD SUPPLIERS
===================== */

async function loadSuppliersForPayment(){

try{

const res =
await fetch("/api/suppliers");

const result =
await res.json();

const suppliers =
result.data || result;

const select =
document.getElementById("supplier_id");

if(!select) return;

select.innerHTML =
'<option value="">Chagua Supplier</option>';

suppliers.forEach(item=>{

select.innerHTML += `
<option value="${item.id}">
${item.jina}
</option>
`;

});

}catch(err){

console.error(err);

}

}

/* =====================
LOAD OPEN ORDERS FOR SELECTED SUPPLIER
===================== */

async function loadOrdersForSupplier(){

try{

const supplierId =
document.getElementById("supplier_id").value;

const orderSelect =
document.getElementById("order_id");

if(!orderSelect) return;

orderSelect.innerHTML =
'<option value="">Chagua Order</option>';

if(!supplierId) return;

const res =
await fetch(
"/api/orders/supplier/" + supplierId
);

const orders =
await res.json();

orders
.filter(o => Number(o.kiasi_baki) > 0)
.forEach(item=>{

orderSelect.innerHTML += `
<option value="${item.id}">
Order ${item.id.slice(0,8)} — Baki: ${Number(item.kiasi_baki).toLocaleString()}
</option>
`;

});

}catch(err){

console.error(err);

}

}

async function lipaSupplier(){

try{

const body = {

supplier_id:
document.getElementById(
"supplier_id"
).value,

order_id:
document.getElementById(
"order_id"
).value,

kiasi:
Number(
document.getElementById(
"kiasi"
).value
),

reference:
document.getElementById(
"reference"
).value

};

if(!body.supplier_id ||
!body.order_id){

alert("Supplier au Order haijachaguliwa");
return;

}

if(body.kiasi <= 0){

alert("Kiasi si sahihi");
return;

}

const res =
await fetch(
"/api/payments",
{
method:"POST",
headers:{
"Content-Type":
"application/json"
},
body:JSON.stringify(body)
}
);

const data =
await res.json();

if(!res.ok || data.success === false){

document.getElementById(
"result"
).innerText =
data.message ||
"Malipo yameshindwa";

return;

}

document.getElementById(
"result"
).innerText =
`
Baki: ${data.kiasi_baki}

Status: ${data.status}
`;

document.getElementById("kiasi").value = "";
document.getElementById("reference").value = "";
loadOrdersForSupplier();

}catch(err){

console.error(err);

document.getElementById(
"result"
).innerText =
"Tatizo la mfumo";

}

}

document.addEventListener("DOMContentLoaded", () => {

loadSuppliersForPayment();

const supplierSelect =
document.getElementById("supplier_id");

if(supplierSelect){
supplierSelect.addEventListener("change", loadOrdersForSupplier);
}

});