const db = require("./db");

db.serialize(() => {

/* =========================
USERS
========================= */
db.run("CREATE TABLE IF NOT EXISTS users ( id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, jina TEXT NOT NULL, role TEXT DEFAULT 'cashier', must_change_password INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0, synced INTEGER DEFAULT 0 )");

/* =========================
ROLE PERMISSIONS
========================= */
db.run(`
CREATE TABLE IF NOT EXISTS role_permissions (
id TEXT PRIMARY KEY,
role TEXT NOT NULL,

can_view_dashboard INTEGER DEFAULT 1,
can_manage_stock INTEGER DEFAULT 0,
can_manage_sales INTEGER DEFAULT 0,
can_manage_suppliers INTEGER DEFAULT 0,
can_manage_orders INTEGER DEFAULT 0,
can_manage_customers INTEGER DEFAULT 0,
can_view_reports INTEGER DEFAULT 0,
can_manage_users INTEGER DEFAULT 0,
can_backup_database INTEGER DEFAULT 0,

created_at TEXT,
updated_at TEXT
)
`);

/* =========================
SETTINGS
========================= */
db.run("CREATE TABLE IF NOT EXISTS settings ( id TEXT PRIMARY KEY, company_name TEXT, company_phone TEXT, company_email TEXT, company_address TEXT, currency TEXT DEFAULT 'TZS', version TEXT DEFAULT 'LECS v2.0', created_at TEXT, updated_at TEXT )");

/* =========================
SUPPLIERS
========================= */
db.run("CREATE TABLE IF NOT EXISTS suppliers ( id TEXT PRIMARY KEY, jina TEXT NOT NULL, simu TEXT, account_namba TEXT, benki TEXT, tin TEXT, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0, synced INTEGER DEFAULT 0 )");

/* =========================
CUSTOMERS
========================= */
db.run("CREATE TABLE IF NOT EXISTS customers ( id TEXT PRIMARY KEY, jina TEXT NOT NULL, simu TEXT, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0, synced INTEGER DEFAULT 0 )");

/* =========================
PRODUCTS (BIDHAA)
========================= */
db.run("CREATE TABLE IF NOT EXISTS bidhaa ( id TEXT PRIMARY KEY, jina TEXT NOT NULL, idadi INTEGER DEFAULT 0, bei_kununua REAL DEFAULT 0, bei_kuuza REAL DEFAULT 0, barcode TEXT, supplier_id TEXT, low_stock_limit INTEGER DEFAULT 2, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0, synced INTEGER DEFAULT 0 )");

/* =========================
SALES (MAUZO)
========================= */
db.run("CREATE TABLE IF NOT EXISTS mauzo ( id TEXT PRIMARY KEY, bidhaa_id TEXT, customer_id TEXT, mteja_jina TEXT, idadi INTEGER DEFAULT 0, bei_kuuza REAL DEFAULT 0, jumla REAL DEFAULT 0, kiasi_kilicholipwa REAL DEFAULT 0, faida_ghafi REAL DEFAULT 0, zaka REAL DEFAULT 0, sadaka REAL DEFAULT 0, faida_halisi REAL DEFAULT 0, status TEXT DEFAULT 'PAID', created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0, synced INTEGER DEFAULT 0 )");

/* =========================
CUSTOMER DEBTS
========================= */
db.run("CREATE TABLE IF NOT EXISTS madeni_kudai ( id TEXT PRIMARY KEY, mauzo_id TEXT, customer_id TEXT, mteja_jina TEXT, kiasi_asili REAL DEFAULT 0, kiasi_kilicholipwa REAL DEFAULT 0, kiasi_baki REAL DEFAULT 0, status TEXT DEFAULT 'DENI', created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0, synced INTEGER DEFAULT 0 )");

/* =========================
CUSTOMER PAYMENTS
========================= */
db.run("CREATE TABLE IF NOT EXISTS customer_payments ( id TEXT PRIMARY KEY, customer_id TEXT, deni_id TEXT, kiasi REAL NOT NULL, reference TEXT, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0, synced INTEGER DEFAULT 0 )");

/* =========================
ORDERS (SUPPLIERS)
========================= */
db.run("CREATE TABLE IF NOT EXISTS orders ( id TEXT PRIMARY KEY, supplier_id TEXT NOT NULL, jumla_order REAL DEFAULT 0, kiasi_kilicholipwa REAL DEFAULT 0, kiasi_baki REAL DEFAULT 0, status TEXT DEFAULT 'DENI', created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0, synced INTEGER DEFAULT 0 )");

/* =========================
ORDER ITEMS
========================= */
db.run("CREATE TABLE IF NOT EXISTS order_items ( id TEXT PRIMARY KEY, order_id TEXT NOT NULL, bidhaa_id TEXT, bidhaa_jina TEXT NOT NULL, idadi INTEGER NOT NULL, bei_kununua REAL NOT NULL, jumla REAL NOT NULL, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0, synced INTEGER DEFAULT 0 )");

/* =========================
SUPPLIER PAYMENTS
========================= */
db.run("CREATE TABLE IF NOT EXISTS supplier_payments ( id TEXT PRIMARY KEY, supplier_id TEXT NOT NULL, order_id TEXT NOT NULL, kiasi REAL NOT NULL, reference TEXT, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0, synced INTEGER DEFAULT 0 )");

/* =========================
ACTIVITY LOGS
========================= */
db.run("CREATE TABLE IF NOT EXISTS activity_logs ( id TEXT PRIMARY KEY, user_id TEXT, username TEXT, action TEXT NOT NULL, description TEXT, created_at TEXT, deleted INTEGER DEFAULT 0 )");

/* =========================
NOTIFICATIONS
========================= */
db.run("CREATE TABLE IF NOT EXISTS notifications ( id TEXT PRIMARY KEY, title TEXT, message TEXT, type TEXT DEFAULT 'INFO', is_read INTEGER DEFAULT 0, created_at TEXT, deleted INTEGER DEFAULT 0 )");

/* =========================
STOCK ALERTS
========================= */
db.run("CREATE TABLE IF NOT EXISTS stock_alerts ( id TEXT PRIMARY KEY, bidhaa_id TEXT, current_stock INTEGER DEFAULT 0, minimum_stock INTEGER DEFAULT 2, status TEXT DEFAULT 'ACTIVE', created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0 )");

/* =========================
REPORT CACHE
========================= */
db.run("CREATE TABLE IF NOT EXISTS report_cache ( id TEXT PRIMARY KEY, report_type TEXT, report_data TEXT, created_at TEXT, deleted INTEGER DEFAULT 0 )");

/* =========================
BACKUPS
========================= */
db.run("CREATE TABLE IF NOT EXISTS backups ( id TEXT PRIMARY KEY, file_name TEXT, file_size REAL, created_at TEXT, deleted INTEGER DEFAULT 0 )");

/* =========================
INDEXES
========================= */

db.run("CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)");
db.run("CREATE INDEX IF NOT EXISTS idx_bidhaa_jina ON bidhaa(jina)");
db.run("CREATE INDEX IF NOT EXISTS idx_mauzo_created ON mauzo(created_at)");
db.run("CREATE INDEX IF NOT EXISTS idx_customers_jina ON customers(jina)");
db.run("CREATE INDEX IF NOT EXISTS idx_suppliers_jina ON suppliers(jina)");
db.run("CREATE INDEX IF NOT EXISTS idx_orders_supplier ON orders(supplier_id)");
db.run("CREATE INDEX IF NOT EXISTS idx_madeni_status ON madeni_kudai(status)");
db.run("CREATE INDEX IF NOT EXISTS idx_logs_date ON activity_logs(created_at)");

/* =========================
SEED DEFAULT SETTINGS ROW
(company info shown on receipts/reports)
========================= */

const { v4: uuidv4 } = require("uuid");

db.get(
    "SELECT id FROM settings LIMIT 1",
    [],
    (err, row) => {

        if (err) {
            console.error("Settings check error:", err.message);
            return;
        }

        if (!row) {

            db.run(
                `INSERT INTO settings
                (id, company_name, company_phone, company_email, company_address, currency, version, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?,?,?)`,
                [
                    uuidv4(),
                    "Lusana Electronics",
                    "",
                    "",
                    "",
                    "TZS",
                    "LECS v2.0",
                    new Date().toISOString(),
                    new Date().toISOString()
                ]
            );

        }

    }
);

/* =========================
DONE
========================= */

console.log("✅ LECS FINAL SCHEMA LOADED SUCCESSFULLY");

});