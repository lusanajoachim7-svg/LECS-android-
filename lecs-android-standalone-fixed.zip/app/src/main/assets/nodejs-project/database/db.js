/**
 * Thin adapter that gives sql.js (a WebAssembly build of SQLite that runs
 * on ANY Node.js version, no native compilation needed) the same
 * callback-style API the route files already use, so none of them need
 * to change.
 *
 * Why not node:sqlite? It's built into Node.js 22.5+, but the Node.js
 * runtime embedded in the Android app (nodejs-mobile) currently ships
 * Node.js 18. sql.js works everywhere because it's pure WebAssembly.
 *
 * sql.js keeps the whole database in memory and has no concept of
 * "auto-save to disk" — so this adapter writes the DB file to disk after
 * every mutating call (run/exec). For a shop-scale POS database this is
 * fast and safe; it trades a little bit of write throughput for never
 * losing data if the app is killed unexpectedly.
 */

const path = require("path");
const fs = require("fs");

const dataDir = process.env.LECS_DATA_DIR || path.join(__dirname, "..", "data");

if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, "lecs.db");

let raw = null;
let SQL = null;
let ready = false;

function assertReady() {
    if (!ready) {
        throw new Error(
            "Database used before init() finished — call and await db.init() " +
            "once at app startup before requiring anything that queries the DB."
        );
    }
}

async function init() {

    if (ready) return;

    const initSqlJs = require("sql.js");

    SQL = await initSqlJs({
        // sql-wasm.wasm ships inside the sql.js package itself.
        locateFile: file => path.join(
            path.dirname(require.resolve("sql.js/package.json")),
            "dist",
            file
        )
    });

    if (fs.existsSync(dbPath)) {
        const fileBuffer = fs.readFileSync(dbPath);
        raw = new SQL.Database(fileBuffer);
    } else {
        raw = new SQL.Database();
    }

    raw.run("PRAGMA foreign_keys = ON");

    ready = true;
    console.log("LECS Database Connected Successfully (sql.js, on-device)");
}

function persist() {
    try {
        const data = raw.export();
        fs.writeFileSync(dbPath, Buffer.from(data));
    } catch (err) {
        console.error("DB persist error:", err.message);
    }
}

function normalizeArgs(params, callback) {
    if (typeof params === "function") {
        return { params: [], callback: params };
    }
    return { params: params || [], callback };
}

// sql.js wants named/positional params as an array or object; "?" style
// positional binding works the same way the old sqlite3-style callers
// already pass params, so no changes needed at call sites.

const db = {

    get raw() {
        assertReady();
        return raw;
    },

    init,

    run(sql, params, callback) {

        assertReady();
        const args = normalizeArgs(params, callback);

        try {
            const stmt = raw.prepare(sql);
            stmt.bind(args.params);
            stmt.step();

            const changes = raw.getRowsModified();

            // sql.js doesn't expose lastInsertRowid directly; since every
            // table in this app uses a TEXT (uuid) primary key supplied by
            // the caller, not an autoincrement INTEGER id, this app's
            // routes never actually rely on lastID — kept here only for
            // API compatibility with the old adapter.
            stmt.free();
            persist();

            if (args.callback) {
                args.callback.call({ changes, lastID: undefined }, null);
            }
        } catch (err) {
            if (args.callback) {
                args.callback.call({}, err);
            } else {
                console.error("DB run error:", err.message, "\nSQL:", sql);
            }
        }

        return db;
    },

    get(sql, params, callback) {

        assertReady();
        const args = normalizeArgs(params, callback);

        try {
            const stmt = raw.prepare(sql);
            stmt.bind(args.params);
            const row = stmt.step() ? stmt.getAsObject() : undefined;
            stmt.free();

            if (args.callback) args.callback(null, row);
        } catch (err) {
            if (args.callback) args.callback(err);
            else console.error("DB get error:", err.message, "\nSQL:", sql);
        }
    },

    all(sql, params, callback) {

        assertReady();
        const args = normalizeArgs(params, callback);

        try {
            const stmt = raw.prepare(sql);
            stmt.bind(args.params);

            const rows = [];
            while (stmt.step()) {
                rows.push(stmt.getAsObject());
            }
            stmt.free();

            if (args.callback) args.callback(null, rows);
        } catch (err) {
            if (args.callback) args.callback(err);
            else console.error("DB all error:", err.message, "\nSQL:", sql);
        }
    },

    exec(sql) {
        assertReady();
        raw.exec(sql);
        persist();
    },

    // sql.js runs every statement synchronously under the hood, and every
    // method above invokes its callback synchronously too — so simply
    // running fn() already preserves strict execution order. This keeps
    // db.serialize(...) calls elsewhere in the codebase working unchanged.
    serialize(fn) {
        fn();
    }

};

module.exports = db;
