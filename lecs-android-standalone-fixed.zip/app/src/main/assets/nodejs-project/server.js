require("dotenv").config();

const express = require("express");
const cors = require("cors");
const path = require("path");
const session = require("express-session");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const { v4: uuidv4 } = require("uuid");

const db = require("./database/db");

const app = express();

/* ======================
MIDDLEWARE
====================== */

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const fs = require("fs");
const crypto = require("crypto");

function getSessionSecret() {

    if (process.env.SESSION_SECRET) {
        return process.env.SESSION_SECRET;
    }

    // No secret configured — generate a real random one the first time
    // this device runs, then reuse it forever after so existing sessions
    // don't get invalidated on every restart. Every device ends up with
    // its own unique secret instead of every install sharing one
    // hardcoded string.
    const dataDir = process.env.LECS_DATA_DIR || path.join(__dirname, "data");
    const secretPath = path.join(dataDir, ".session_secret");

    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

    if (fs.existsSync(secretPath)) {
        return fs.readFileSync(secretPath, "utf8").trim();
    }

    const generated = crypto.randomBytes(48).toString("hex");
    fs.writeFileSync(secretPath, generated);
    return generated;
}

app.use(
    session({
        secret: getSessionSecret(),
        resave: false,
        saveUninitialized: false,
        cookie: {
            // This server always serves plain HTTP — 127.0.0.1 on-device,
            // or plain HTTP to LAN peers — never HTTPS. A Secure cookie
            // requires HTTPS; setting this true here would make the
            // browser silently refuse to store the session cookie after
            // every login, causing an infinite login loop. Do not tie
            // this to NODE_ENV — it must stay false for this app.
            secure: false,
            httpOnly: true,
            maxAge: 1000 * 60 * 60 * 24
        }
    })
);

/* ======================
STATIC FILES
====================== */

app.use(express.static(path.join(__dirname, "public")));

/* ======================
AUTH MIDDLEWARE
====================== */

function auth(req, res, next) {
    if (!req.session.user) {
        return res.redirect("/");
    }
    next();
}

/* ======================
ROLE MIDDLEWARE
====================== */

function role(roleName) {
    return (req, res, next) => {

        if (!req.session.user) {
            return res.redirect("/");
        }

        if (
            req.session.user.role !== roleName &&
            req.session.user.role !== "admin"
        ) {
            return res.status(403).json({
                success: false,
                message: "No Access"
            });
        }

        next();
    };
}

/* ======================
RATE LIMITING (LOGIN)
====================== */

const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // 10 attempts per window per IP
    standardHeaders: true,
    legacyHeaders: false,
    message: {
        success: false,
        message: "Majaribio mengi ya kuingia. Jaribu tena baada ya dakika 15."
    }
});

/* ======================
FIRST-RUN ADMIN CREATION
On a phone there's no terminal to run `npm run create-admin`, so if no
users exist yet at all, create a default admin the first time the server
starts and force a password change on first login.
====================== */

function ensureAdminExists() {
    return new Promise((resolve) => {

        db.get("SELECT id FROM users LIMIT 1", [], async (err, row) => {

            if (err) {
                console.error("Admin check error:", err.message);
                return resolve();
            }

            if (row) {
                return resolve();
            }

            const defaultPassword = process.env.ADMIN_PASSWORD || "admin123";
            const passwordHash = await bcrypt.hash(defaultPassword, 10);

            db.run(
                `INSERT INTO users
                (id, username, password_hash, jina, role, must_change_password, created_at, updated_at, deleted, synced)
                VALUES (?,?,?,?,?,?,?,?,?,?)`,
                [
                    uuidv4(),
                    "admin",
                    passwordHash,
                    "Administrator",
                    "admin",
                    1,
                    new Date().toISOString(),
                    new Date().toISOString(),
                    0,
                    0
                ],
                (err) => {
                    if (err) {
                        console.error("Admin creation error:", err.message);
                    } else {
                        console.log("======================================");
                        console.log("✅ First run: default admin created");
                        console.log("   Username: admin");
                        console.log("   Password: " + defaultPassword);
                        console.log("   You'll be asked to change it on first login.");
                        console.log("======================================");
                    }
                    resolve();
                }
            );
        });
    });
}

/* ======================
ROUTES
====================== */

function mountRoutes() {

    const authRoutes = require("./routes/auth");
    app.use("/api/auth/login", loginLimiter);
    app.use("/api/auth", authRoutes);

    app.use("/api/dashboard", auth, require("./routes/dashboard"));
    app.use("/api/reports", auth, require("./routes/reports"));

    app.use("/api/bidhaa", auth, require("./routes/bidhaa"));
    app.use("/api/mauzo", auth, require("./routes/mauzo"));

    app.use("/api/customers", auth, require("./routes/customers"));
    app.use("/api/customer-payments", auth, require("./routes/customer_payments"));

    app.use("/api/suppliers", auth, require("./routes/suppliers"));
    app.use("/api/payments", auth, require("./routes/payments"));

    app.use("/api/orders", auth, require("./routes/orders"));
    app.use("/api/madeni", auth, require("./routes/debts"));

    app.use("/api/activity-logs", auth, require("./routes/activity_logs"));
    app.use("/api/settings", auth, require("./routes/settings"));
    app.use("/api/notifications", auth, require("./routes/notifications"));

    // Not behind the session `auth` middleware — /api/sync/import has to
    // be reachable by other devices' own LECS servers on the same WiFi,
    // which have no browser session cookie. It protects itself instead
    // (see routes/sync.js: session OR same-LAN origin required).
    app.use("/api/sync", require("./routes/sync"));

    /* ======================
    HEALTH CHECK
    ====================== */

    app.get("/api/health", (req, res) => {
        res.json({
            app: "LECS FINAL SYSTEM",
            status: "RUNNING",
            time: new Date().toISOString()
        });
    });

    /* ======================
    LOGIN PAGE
    ====================== */

    app.get("/", (req, res) => {
        res.sendFile(path.join(__dirname, "public", "login.html"));
    });

    /* ======================
    PROTECTED PAGES
    ====================== */

    const pages = [
        "dashboard.html",
        "stock.html",
        "mauzo.html",
        "suppliers.html",
        "orders.html",
        "payments.html",
        "debts.html",
        "customers.html",
        "customer_payments.html",
        "reports.html",
        "settings.html",
        "activity_logs.html"
    ];

    pages.forEach(page => {
        app.get("/" + page, auth, (req, res) => {
            res.sendFile(path.join(__dirname, "public", page));
        });
    });

    /* ======================
    LOGOUT
    ====================== */

    app.get("/logout", (req, res) => {
        req.session.destroy(() => {
            res.redirect("/");
        });
    });

    /* ======================
    404 HANDLER
    ====================== */

    app.use((req, res) => {
        res.status(404).json({
            success: false,
            message: "Route haipatikani"
        });
    });

    /* ======================
    ERROR HANDLER
    ====================== */

    app.use((err, req, res, next) => {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Internal Server Error"
        });
    });
}

/* ======================
START SERVER
Everything that touches the database (schema creation, route handlers,
first-run admin) has to wait until the sql.js WebAssembly module has
finished loading — that's the one async step this on-device version
needs that a normal always-on server didn't.
====================== */

const PORT = process.env.PORT || 3000;

async function start() {
    await db.init();

    require("./database/schema");

    await ensureAdminExists();

    mountRoutes();

    app.listen(PORT, () => {
        console.log("🚀 LECS FINAL SYSTEM RUNNING (on-device)");
        console.log("🌐 http://localhost:" + PORT);

        try {
            require("./services/peerSync").start(PORT);
        } catch (err) {
            console.error("Auto-sync service failed to start:", err.message);
        }
    });
}

start().catch(err => {
    console.error("❌ LECS failed to start:", err);
    // IMPORTANT: no process.exit() here. This Node runtime is embedded
    // inside the Android app's own process (via node::Start() in
    // native-lib.cpp) — calling process.exit() doesn't just end "the
    // server," it kills the entire host app instantly, with no chance
    // for this error to reach Logcat or for MainActivity's error panel
    // to show. Leaving the process alive (but not listening) lets
    // MainActivity's own health-check timeout surface a normal,
    // recoverable error screen instead of a silent crash.
});
