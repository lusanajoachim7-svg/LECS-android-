const { v4: uuidv4 } = require("uuid");
const db = require("../database/db");

function saveLog(
username,
action,
description
){

db.run(
`
INSERT INTO activity_logs
(
id,
username,
action,
description,
created_at
)
VALUES
(?,?,?,?,?)
`,
[
uuidv4(),
username,
action,
description,
new Date().toISOString()
]
);

}

module.exports = saveLog;