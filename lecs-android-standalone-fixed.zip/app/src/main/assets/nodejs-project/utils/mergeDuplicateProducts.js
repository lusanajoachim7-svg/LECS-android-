const db = require("../database/db");

/**
 * Merges any existing duplicate products (same name AND same buying
 * price, different rows — e.g. two separate "Juma jack" entries from
 * before the duplicate-prevention fix in routes/bidhaa.js existed)
 * into a single row with their combined stock, and hides any row left
 * at zero.
 *
 * Rows that share a name but were bought at a DIFFERENT price are
 * deliberately NOT merged — they're treated as separate batches (e.g.
 * restocked at a new cost from the supplier), since averaging two
 * different buying prices together would corrupt profit-margin
 * calculations for both.
 *
 * Safe to run every time the app starts (or after every sync): if
 * there are no true duplicates, it does nothing.
 */
function mergeDuplicateProducts() {
    return new Promise((resolve) => {

        db.all(
            `SELECT id, jina, idadi, bei_kununua, created_at
             FROM bidhaa
             WHERE deleted = 0
             ORDER BY jina ASC, bei_kununua ASC, created_at ASC`,
            [],
            (err, rows) => {

                if (err || !rows || rows.length === 0) {
                    return resolve();
                }

                // Group by normalized name + exact buying price together.
                const groups = {};
                rows.forEach(r => {
                    const nameKey = String(r.jina || "").trim().toLowerCase();
                    const priceKey = Number(r.bei_kununua || 0);
                    const key = nameKey + "||" + priceKey;
                    if (!groups[key]) groups[key] = [];
                    groups[key].push(r);
                });

                const duplicateGroups = Object.values(groups).filter(g => g.length > 1);

                if (duplicateGroups.length === 0) {
                    return resolve();
                }

                let remaining = duplicateGroups.length;

                duplicateGroups.forEach(group => {
                    // Keep the oldest row as the "real" one, fold the rest into it.
                    const keeper = group[0];
                    const extras = group.slice(1);
                    const totalQty = group.reduce((sum, r) => sum + Number(r.idadi || 0), 0);
                    const now = new Date().toISOString();

                    db.run(
                        `UPDATE bidhaa SET idadi = ?, deleted = ?, updated_at = ? WHERE id = ?`,
                        [totalQty, totalQty > 0 ? 0 : 1, now, keeper.id],
                        () => {

                            const extraIds = extras.map(e => e.id);
                            const placeholders = extraIds.map(() => "?").join(",");

                            db.run(
                                `UPDATE bidhaa SET deleted = 1, idadi = 0, updated_at = ? WHERE id IN (${placeholders})`,
                                [now, ...extraIds],
                                () => {
                                    remaining--;
                                    if (remaining <= 0) resolve();
                                }
                            );

                        }
                    );
                });

            }
        );

    });
}

module.exports = mergeDuplicateProducts;
