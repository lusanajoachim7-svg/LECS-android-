/**
 * Automatic same-WiFi sync.
 *
 * Every LECS device broadcasts a small "I'm here" UDP announcement on
 * the local network every few seconds, and listens for the same from
 * others. Whenever it sees unsynced sales/stock/other changes AND knows
 * about at least one peer, it pushes just those changes straight to
 * that peer's /api/sync/import — no button, no file, no user action.
 *
 * This only works while devices share a WiFi network/hotspot. It's
 * silent and automatic on purpose — there's no way to require a shared
 * password without a manual setup step, so trust is scoped to "another
 * LECS device on this same WiFi", same as any other device on the
 * network.
 */

const dgram = require("dgram");
const http = require("http");
const path = require("path");
const fs = require("fs");

const BEACON_PORT = 41234;
const BEACON_INTERVAL_MS = 5000;
const PUSH_CHECK_INTERVAL_MS = 5000;
const PEER_EXPIRY_MS = 30000; // forget a peer if not heard from in 30s

const dataDir = process.env.LECS_DATA_DIR || path.join(__dirname, "..", "data");
const peersFilePath = path.join(dataDir, "peers.json");

let peers = {}; // device_id -> { device_name, ip, port, last_seen_at, last_synced_at }
let httpPort = 3000;
let sync = null; // lazy-required, once db.init() has resolved
let pushInFlight = false;

function loadPeers() {
    if (fs.existsSync(peersFilePath)) {
        try {
            peers = JSON.parse(fs.readFileSync(peersFilePath, "utf8"));
        } catch (err) {
            peers = {};
        }
    }
}

function savePeers() {
    try {
        fs.writeFileSync(peersFilePath, JSON.stringify(peers, null, 2));
    } catch (err) {
        console.error("peers.json write error:", err.message);
    }
}

function startBeacon(deviceId, deviceName) {

    const socket = dgram.createSocket({ type: "udp4", reuseAddr: true });

    socket.on("error", (err) => {
        console.error("Sync beacon socket error:", err.message);
    });

    socket.bind(BEACON_PORT, () => {
        socket.setBroadcast(true);
    });

    socket.on("message", (msg, rinfo) => {

        try {
            const announcement = JSON.parse(msg.toString());

            if (announcement.type !== "lecs_announce") return;
            if (announcement.device_id === deviceId) return; // ignore our own broadcast

            const existing = peers[announcement.device_id] || {};

            peers[announcement.device_id] = {
                device_name: announcement.device_name,
                ip: rinfo.address,
                port: announcement.http_port,
                last_seen_at: Date.now(),
                last_synced_at: existing.last_synced_at || null
            };

        } catch (err) {
            // ignore malformed packets from other devices/apps on the network
        }
    });

    setInterval(() => {

        const message = Buffer.from(JSON.stringify({
            type: "lecs_announce",
            device_id: deviceId,
            device_name: deviceName,
            http_port: httpPort
        }));

        socket.send(message, 0, message.length, BEACON_PORT, "255.255.255.255", (err) => {
            if (err) console.error("Beacon send error:", err.message);
        });

    }, BEACON_INTERVAL_MS);

    return socket;
}

function forgetStalePeers() {
    const now = Date.now();
    for (const id of Object.keys(peers)) {
        if (now - peers[id].last_seen_at > PEER_EXPIRY_MS) {
            delete peers[id];
        }
    }
}

function postJson(ip, port, urlPath, bodyObj) {
    return new Promise((resolve, reject) => {

        const data = Buffer.from(JSON.stringify(bodyObj));

        const req = http.request(
            {
                host: ip,
                port: port,
                path: urlPath,
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Content-Length": data.length
                },
                timeout: 4000
            },
            (res) => {
                let body = "";
                res.on("data", chunk => (body += chunk));
                res.on("end", () => {
                    if (res.statusCode >= 200 && res.statusCode < 300) {
                        resolve(body);
                    } else {
                        reject(new Error(`HTTP ${res.statusCode}: ${body}`));
                    }
                });
            }
        );

        req.on("timeout", () => req.destroy(new Error("timeout")));
        req.on("error", reject);
        req.write(data);
        req.end();
    });
}

async function pushToPeers(deviceId, deviceName) {

    if (pushInFlight) return; // don't overlap runs
    if (Object.keys(peers).length === 0) return;

    pushInFlight = true;

    try {

        for (const [peerId, peer] of Object.entries(peers)) {

            try {

                const payload = await sync.buildExportPayload(deviceId, deviceName, peer.last_synced_at);

                if (!sync.payloadHasRows(payload)) continue;

                await postJson(peer.ip, peer.port, "/api/sync/import", payload);

                peer.last_synced_at = payload.exported_at;
                savePeers();

            } catch (err) {
                // Peer offline/unreachable right now — fine, we'll retry
                // on the next check once it's back.
                console.log(`Auto-sync to ${peer.device_name || peerId} skipped:`, err.message);
            }
        }

    } finally {
        pushInFlight = false;
    }
}

function start(expressAppPort) {

    httpPort = expressAppPort;
    sync = require("../routes/sync");

    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    loadPeers();

    const info = sync.loadDeviceInfo();

    startBeacon(info.device_id, info.device_name);

    setInterval(() => {
        forgetStalePeers();
        pushToPeers(info.device_id, info.device_name).catch(err => {
            console.error("Auto-sync cycle error:", err.message);
        });
    }, PUSH_CHECK_INTERVAL_MS);

    console.log("🔄 Auto-sync over WiFi enabled (device: " + info.device_name + ")");
}

function getKnownPeers() {
    return peers;
}

module.exports = { start, getKnownPeers };
