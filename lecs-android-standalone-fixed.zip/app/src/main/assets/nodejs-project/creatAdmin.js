require("dotenv").config();

const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const { v4: uuidv4 } = require("uuid");
const db = require("./database/db");

function generateRandomPassword() {
    // 12 random bytes -> readable base64url string, easy to copy/paste once
    return crypto.randomBytes(9).toString("base64url");
}

async function createAdmin() {

    try {

        const password = process.env.ADMIN_PASSWORD || generateRandomPassword();
        const generated = !process.env.ADMIN_PASSWORD;

        const passwordHash = await bcrypt.hash(password, 10);

        db.get(
            "SELECT id FROM users WHERE username=?",
            ["admin"],
            (err, user) => {

                if (err) {
                    console.log("Database Error:", err.message);
                    return;
                }

                if (user) {
                    console.log("✅ Admin tayari yupo");
                    return;
                }

                db.run(
                    "INSERT INTO users( id, username, password_hash, jina, role, must_change_password, created_at, updated_at, deleted, synced ) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    [
                        uuidv4(),
                        "admin",
                        passwordHash,
                        "Administrator",
                        "admin",
                        1,
                        new Date().toISOString(),
                        new Date().toISOString(),
                        0,
                        0
                    ],
                    (err) => {

                        if (err) {
                            console.log("Insert Error:", err.message);
                            return;
                        }

                        console.log("✅ Admin ameundwa vizuri");
                        console.log("Username: admin");
                        console.log("Password: " + password);

                        if (generated) {
                            console.log(
                                "⚠️  This password was auto-generated and will not be shown again. " +
                                "You will be required to change it on first login."
                            );
                        }

                    }
                );

            }
        );

    } catch (error) {
        console.log("Error:", error.message);
    }

}

(async () => {
    await db.init();
    require("./database/schema"); // creates tables if they don't exist yet
    createAdmin();
})();
