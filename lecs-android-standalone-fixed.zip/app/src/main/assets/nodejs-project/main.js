// Entry point nodejs-mobile looks for. Keeps server.js exactly as the
// version you'd run with `npm start` anywhere else — this file just
// bootstraps it inside the Android app's embedded Node runtime.
require("./server.js");
