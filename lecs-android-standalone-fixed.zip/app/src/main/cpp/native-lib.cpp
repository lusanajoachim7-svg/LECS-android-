#include <jni.h>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <pthread.h>
#include <unistd.h>
#include <android/log.h>
#include "node.h"

#define LOG_TAG "LECS-Node"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ---------------------------------------------------------------------
// Redirects the Node process's stdout/stderr into logcat, so
// console.log()/console.error() calls from the embedded server show up
// when debugging with `adb logcat`.
// ---------------------------------------------------------------------

static int pipe_fd[2];

static void *logcat_reader_thread(void *) {

    ssize_t read_size;
    char buf[1024];

    while ((read_size = read(pipe_fd[0], buf, sizeof(buf) - 1)) > 0) {
        buf[read_size] = 0;
        __android_log_write(ANDROID_LOG_INFO, LOG_TAG, buf);
    }

    return nullptr;
}

static void start_logcat_redirect() {

    setvbuf(stdout, nullptr, _IOLBF, 0);
    setvbuf(stderr, nullptr, _IONBF, 0);

    pipe(pipe_fd);
    dup2(pipe_fd[1], STDOUT_FILENO);
    dup2(pipe_fd[1], STDERR_FILENO);

    pthread_t thread;
    pthread_create(&thread, nullptr, logcat_reader_thread, nullptr);
    pthread_detach(thread);
}

// ---------------------------------------------------------------------
// JNI entry point called from MainActivity's background thread.
// libuv/node require all argv strings laid out in contiguous memory.
// ---------------------------------------------------------------------

extern "C"
JNIEXPORT jint JNICALL
Java_com_lecs_app_MainActivity_startNodeWithArguments(
        JNIEnv *env,
        jobject /* this */,
        jobjectArray arguments) {

    start_logcat_redirect();

    jsize argument_count = env->GetArrayLength(arguments);

    std::vector<std::string> cpp_arguments;
    std::vector<char *> argv;

    for (int i = 0; i < argument_count; i++) {
        auto jstr = (jstring) env->GetObjectArrayElement(arguments, i);
        const char *raw = env->GetStringUTFChars(jstr, nullptr);
        cpp_arguments.emplace_back(raw);
        env->ReleaseStringUTFChars(jstr, raw);
        env->DeleteLocalRef(jstr);
    }

    argv.reserve(cpp_arguments.size());
    for (auto &s : cpp_arguments) {
        argv.push_back(const_cast<char *>(s.c_str()));
    }

    LOGI("Starting Node.js with %d arguments", argument_count);

    int result = node::Start((int) argv.size(), argv.data());

    LOGE("Node.js runtime exited with code %d", result);

    return result;
}
