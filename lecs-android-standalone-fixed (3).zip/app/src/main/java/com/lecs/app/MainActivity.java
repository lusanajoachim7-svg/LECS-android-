package com.lecs.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.system.Os;
import android.text.TextUtils;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    // Native bridge into libnode — see app/src/main/cpp/native-lib.cpp
    static {
        System.loadLibrary("native-lib");
        System.loadLibrary("node");
    }

    private native int startNodeWithArguments(String[] arguments);

    private static boolean nodeStarted = false;

    private static final String PREFS_NAME = "lecs_prefs";
    private static final String PREF_NODE_PORT = "node_port";
    private static final int DEFAULT_PORT = 3000;

    // How long to keep polling the embedded server before giving up and
    // showing the error panel (first boot has to unpack the JS project
    // and warm up sql.js, so give it a generous window).
    private static final int SERVER_READY_TIMEOUT_MS = 30000;
    private static final int SERVER_POLL_INTERVAL_MS = 500;

    private WebView webView;
    private LinearLayout setupPanel;
    private LinearLayout errorPanel;
    private EditText serverInput;
    private Button connectButton;
    private Button retryButton;
    private Button changeServerButton;
    private android.widget.TextView crashDetailText;

    private SharedPreferences prefs;
    private boolean pageLoadedOk = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long serverWaitStartedAt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        webView = (WebView) findViewById(R.id.webview);
        setupPanel = (LinearLayout) findViewById(R.id.setupPanel);
        errorPanel = (LinearLayout) findViewById(R.id.errorPanel);
        serverInput = (EditText) findViewById(R.id.serverInput);
        connectButton = (Button) findViewById(R.id.connectButton);
        retryButton = (Button) findViewById(R.id.retryButton);
        changeServerButton = (Button) findViewById(R.id.changeServerButton);
        crashDetailText = (android.widget.TextView) findViewById(R.id.crashDetailText);

        setupWebView();

        // The setup/change-server panel is kept only as a manual escape
        // hatch (e.g. pointing at a different device's server instead of
        // this device's own embedded one). Normal use never needs it.
        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveAndLoad();
            }
        });

        retryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                waitForServerThenLoad();
            }
        });

        changeServerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSetupPanel();
            }
        });

        startEmbeddedServerIfNeeded();
        waitForServerThenLoad();
    }

    /* ======================
    START EMBEDDED NODE SERVER
    ====================== */

    private void startEmbeddedServerIfNeeded() {

        if (nodeStarted) return;
        nodeStarted = true;

        new Thread(new Runnable() {
            @Override
            public void run() {

                try {

                    String nodeDir = getApplicationContext().getFilesDir().getAbsolutePath() + "/nodejs-project";
                    String dataDir = getApplicationContext().getFilesDir().getAbsolutePath() + "/lecs-data";

                    new File(dataDir).mkdirs();

                    if (wasAPKUpdated()) {
                        File nodeDirReference = new File(nodeDir);
                        if (nodeDirReference.exists()) {
                            deleteFolderRecursively(nodeDirReference);
                        }
                        copyAssetFolder(getApplicationContext().getAssets(), "nodejs-project", nodeDir);
                        saveLastUpdateTime();
                    }

                    int port = choosePort();
                    prefs.edit().putInt(PREF_NODE_PORT, port).apply();

                    // These are read by database/db.js and server.js on
                    // the Node side via process.env.
                    Os.setenv("LECS_DATA_DIR", dataDir, true);
                    Os.setenv("PORT", String.valueOf(port), true);
                    Os.setenv("LECS_DEVICE_NAME", deviceLabel(), true);

                    startNodeWithArguments(new String[]{"node", nodeDir + "/main.js"});

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private String deviceLabel() {
        String model = android.os.Build.MODEL;
        return TextUtils.isEmpty(model) ? "LECS Device" : model;
    }

    // Almost always DEFAULT_PORT; only probes upward if something else
    // on the device is already bound to it.
    private int choosePort() {

        int port = DEFAULT_PORT;

        for (int attempt = 0; attempt < 10; attempt++) {
            if (isPortFree(port)) return port;
            port++;
        }

        return DEFAULT_PORT;
    }

    private boolean isPortFree(int port) {
        try {
            java.net.ServerSocket socket = new java.net.ServerSocket(port);
            socket.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private boolean wasAPKUpdated() {

        SharedPreferences prefs = getApplicationContext().getSharedPreferences("NODEJS_MOBILE_PREFS", Context.MODE_PRIVATE);
        long previousLastUpdateTime = prefs.getLong("NODEJS_MOBILE_APK_LastUpdateTime", 0);
        long lastUpdateTime = 1;

        try {
            PackageInfo packageInfo = getApplicationContext()
                    .getPackageManager()
                    .getPackageInfo(getApplicationContext().getPackageName(), 0);
            lastUpdateTime = packageInfo.lastUpdateTime;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return (lastUpdateTime != previousLastUpdateTime);
    }

    private void saveLastUpdateTime() {

        long lastUpdateTime = 1;

        try {
            PackageInfo packageInfo = getApplicationContext()
                    .getPackageManager()
                    .getPackageInfo(getApplicationContext().getPackageName(), 0);
            lastUpdateTime = packageInfo.lastUpdateTime;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        SharedPreferences prefs = getApplicationContext().getSharedPreferences("NODEJS_MOBILE_PREFS", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong("NODEJS_MOBILE_APK_LastUpdateTime", lastUpdateTime);
        editor.apply();
    }

    private static boolean deleteFolderRecursively(File file) {
        try {
            boolean res = true;
            File[] children = file.listFiles();
            if (children != null) {
                for (File childFile : children) {
                    if (childFile.isDirectory()) {
                        res &= deleteFolderRecursively(childFile);
                    } else {
                        res &= childFile.delete();
                    }
                }
            }
            res &= file.delete();
            return res;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private static boolean copyAssetFolder(AssetManager assetManager, String fromAssetPath, String toPath) {
        try {

            String[] files = assetManager.list(fromAssetPath);
            if (files == null) return false;

            new File(toPath).mkdirs();
            boolean res = true;

            for (String file : files) {

                String[] children = assetManager.list(fromAssetPath + "/" + file);

                if (children != null && children.length > 0) {
                    res &= copyAssetFolder(assetManager, fromAssetPath + "/" + file, toPath + "/" + file);
                } else {
                    res &= copyAsset(assetManager, fromAssetPath + "/" + file, toPath + "/" + file);
                }
            }

            return res;

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    private static boolean copyAsset(AssetManager assetManager, String fromAssetPath, String toPath) {
        try {
            InputStream in = assetManager.open(fromAssetPath);
            new File(toPath).createNewFile();
            OutputStream out = new java.io.FileOutputStream(toPath);

            byte[] buffer = new byte[4096];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }

            in.close();
            out.flush();
            out.close();
            return true;

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /* ======================
    WEBVIEW
    ====================== */

    private void setupWebView() {

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageLoadedOk = true;
                showWebView();
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                if (!pageLoadedOk) {
                    showErrorPanel();
                }
            }

            // The embedded server is plain HTTP on localhost — this is
            // expected and not a security concern since it never leaves
            // the device.
            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();
            }
        });
    }

    /* ======================
    WAIT FOR THE EMBEDDED SERVER, THEN LOAD IT
    First boot needs a few seconds to unpack files and warm up the
    database, so this polls localhost instead of loading immediately.
    ====================== */

    private void waitForServerThenLoad() {
        serverWaitStartedAt = System.currentTimeMillis();
        pollServer();
    }

    private void pollServer() {

        final int port = prefs.getInt(PREF_NODE_PORT, DEFAULT_PORT);

        new Thread(new Runnable() {
            @Override
            public void run() {

                final boolean up = isServerUp(port);

                handler.post(new Runnable() {
                    @Override
                    public void run() {

                        if (up) {
                            pageLoadedOk = false;
                            webView.loadUrl("http://127.0.0.1:" + port + "/");
                            return;
                        }

                        long elapsed = System.currentTimeMillis() - serverWaitStartedAt;

                        if (elapsed > SERVER_READY_TIMEOUT_MS) {
                            showErrorPanel();
                            return;
                        }

                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                pollServer();
                            }
                        }, SERVER_POLL_INTERVAL_MS);
                    }
                });
            }
        }).start();
    }

    private boolean isServerUp(int port) {
        try {
            URL url = new URL("http://127.0.0.1:" + port + "/api/health");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(1000);
            conn.setReadTimeout(1000);
            int code = conn.getResponseCode();
            conn.disconnect();
            return code == 200;
        } catch (Exception e) {
            return false;
        }
    }

    /* ======================
    MANUAL "CHANGE SERVER" FALLBACK
    Only used if someone explicitly wants to point this device at a
    different device's server instead of its own embedded one.
    ====================== */

    private void saveAndLoad() {

        String url = serverInput.getText().toString().trim();

        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this, R.string.enter_server_hint, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://" + url;
        }

        while (url.endsWith("/")) {
            url = url.substring(0, url.length() - 1);
        }

        pageLoadedOk = false;
        webView.loadUrl(url + "/dashboard.html");
    }

    private void showSetupPanel() {
        setupPanel.setVisibility(View.VISIBLE);
        errorPanel.setVisibility(View.GONE);
        webView.setVisibility(View.GONE);
    }

    private void showErrorPanel() {
        errorPanel.setVisibility(View.VISIBLE);
        setupPanel.setVisibility(View.GONE);
        webView.setVisibility(View.GONE);

        // Show the actual Node startup error on-screen, if one was written.
        try {
            String dataDir = getApplicationContext().getFilesDir().getAbsolutePath() + "/lecs-data";
            File crashFile = new File(dataDir, "last_crash.log");
            if (crashFile.exists()) {
                byte[] bytes = new byte[(int) crashFile.length()];
                java.io.FileInputStream fis = new java.io.FileInputStream(crashFile);
                fis.read(bytes);
                fis.close();
                crashDetailText.setText(new String(bytes, "UTF-8"));
            } else {
                crashDetailText.setText("(No crash log found yet — the server may just be slow to start, or has not failed with a caught error.)");
            }
        } catch (Exception e) {
            crashDetailText.setText("Could not read crash log: " + e.getMessage());
        }
    }

    private void showWebView() {
        webView.setVisibility(View.VISIBLE);
        setupPanel.setVisibility(View.GONE);
        errorPanel.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (webView.getVisibility() == View.VISIBLE && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
