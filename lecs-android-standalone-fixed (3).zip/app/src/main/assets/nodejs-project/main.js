// Entry point nodejs-mobile looks for. Keeps server.js exactly as the
// version you'd run with `npm start` anywhere else — this file just
// bootstraps it inside the Android app's embedded Node runtime.

// Catch literally anything that goes wrong, anywhere, before doing
// anything else — including errors that happen outside server.js's own
// try/catch (a bad require() at the top of some file, an unhandled
// promise rejection in a route module, etc). Writes to the same file
// MainActivity's error panel already reads and displays on-screen, so
// no failure mode goes unseen no matter where it happens.

const fs = require("fs");
const path = require("path");

function writeCrashLog(label, err) {
    try {
        const dataDir = process.env.LECS_DATA_DIR || path.join(__dirname, "data");
        if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
        const text =
            label + "\n" +
            new Date().toISOString() + "\n\n" +
            (err && err.stack ? err.stack : String(err));
        fs.writeFileSync(path.join(dataDir, "last_crash.log"), text);
    } catch (writeErr) {
        // Nothing more we can do if even this fails — but don't let the
        // logging attempt itself throw and mask the original error.
    }
}

process.on("uncaughtException", (err) => {
    console.error("❌ Uncaught exception:", err);
    writeCrashLog("Uncaught exception", err);
});

process.on("unhandledRejection", (reason) => {
    console.error("❌ Unhandled promise rejection:", reason);
    writeCrashLog("Unhandled promise rejection", reason);
});

try {
    require("./server.js");
} catch (err) {
    console.error("❌ Failed to load server.js:", err);
    writeCrashLog("Failed to load server.js", err);
}
