const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../database/db");

const router = express.Router();

/* =========================
GET ALL ORDERS
========================= */

router.get("/", (req,res)=>{

const page =
parseInt(req.query.page) || 1;

const limit =
parseInt(req.query.limit) || 20;

const search =
req.query.search || "";

const offset =
(page - 1) * limit;

db.all(
`
SELECT
orders.*,
suppliers.jina AS supplier_name

FROM orders

LEFT JOIN suppliers
ON suppliers.id = orders.supplier_id

WHERE
orders.deleted = 0
AND suppliers.jina LIKE ?

ORDER BY orders.created_at DESC

LIMIT ?
OFFSET ?
`,
[
`%${search}%`,
limit,
offset
],
(err,rows)=>{

if(err){

return res.status(500).json({
success:false,
message:"Database Error"
});

}

db.get(
`
SELECT COUNT(*) total

FROM orders

LEFT JOIN suppliers
ON suppliers.id = orders.supplier_id

WHERE
orders.deleted = 0
AND suppliers.jina LIKE ?
`,
[
`%${search}%`
],
(err,count)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json({

success:true,

data:rows,

currentPage:page,

totalRows:count.total,

totalPages:
Math.ceil(
count.total / limit
)

});

});

});

});

/* =========================
SUPPLIER DEBTS
========================= */

router.get("/debts",(req,res)=>{

db.all(
`
SELECT

orders.*,

suppliers.jina AS supplier_name

FROM orders

LEFT JOIN suppliers
ON suppliers.id = orders.supplier_id

WHERE
orders.deleted = 0
AND orders.kiasi_baki > 0

ORDER BY orders.created_at DESC
`,
[],
(err,rows)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(rows);

});

});

/* =========================
ORDER STATS
========================= */

router.get("/stats/summary",(req,res)=>{

db.get(
`
SELECT

COUNT(*) total_orders,

IFNULL(
SUM(jumla_order),
0
) total_amount,

IFNULL(
SUM(kiasi_baki),
0
) total_debts

FROM orders

WHERE deleted = 0
`,
[],
(err,row)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(row);

});

});

/* =========================
GET ORDER ITEMS
========================= */

router.get("/items/:orderId",(req,res)=>{

db.all(
`
SELECT *
FROM order_items
WHERE order_id = ?
AND deleted = 0
`,
[
req.params.orderId
],
(err,rows)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(rows);

});

});

/* =========================
ORDERS BY SUPPLIER
========================= */

router.get("/supplier/:supplierId",(req,res)=>{

db.all(
`
SELECT *
FROM orders

WHERE supplier_id = ?
AND deleted = 0

ORDER BY created_at DESC
`,
[
req.params.supplierId
],
(err,rows)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(rows);

});

});

/* =========================
SUPPLIERS (for order form dropdown)
========================= */

router.get("/suppliers",(req,res)=>{

db.all(
`
SELECT id, jina
FROM suppliers
WHERE deleted = 0
ORDER BY jina ASC
`,
[],
(err,rows)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(rows);

});

});

/* =========================
GET SINGLE ORDER
========================= */

router.get("/:id",(req,res)=>{

db.get(
`
SELECT *
FROM orders
WHERE id = ?
AND deleted = 0
`,
[
req.params.id
],
(err,row)=>{

if(err){

return res.status(500).json({
success:false
});

}

res.json(row || {});

});

});

/* =========================
CREATE ORDER
========================= */

router.post("/",(req,res)=>{

const {
supplier_id,
jumla_order,
kiasi_kilicholipwa
} = req.body;

if(!supplier_id){

return res.status(400).json({
success:false,
message:"Supplier anahitajika"
});

}

const jumla =
Number(jumla_order || 0);

const malipo =
Number(kiasi_kilicholipwa || 0);

const baki =
Math.max(
0,
jumla - malipo
);

const newOrderId = uuidv4();

db.run(
`
INSERT INTO orders(

id,
supplier_id,
jumla_order,
kiasi_kilicholipwa,
kiasi_baki,
status,
created_at,
updated_at,
deleted,
synced

)

VALUES(
?,?,?,?,?,?,?,?,0,0
)
`,
[
newOrderId,
supplier_id,
jumla,
malipo,
baki,
baki > 0 ? "DENI" : "PAID",
new Date().toISOString(),
new Date().toISOString()
],
function(err){

if(err){

return res.status(500).json({
success:false,
message:"Order Save Error"
});

}

res.json({
success:true,
id: newOrderId,
jumla_order: jumla,
kiasi_kilicholipwa: malipo,
kiasi_baki: baki
});

});

});

/* =========================
ADD ORDER ITEM
========================= */

router.post("/item",(req,res)=>{

const {
order_id,
bidhaa_jina,
idadi,
bei_kununua
} = req.body;

const jumla =
Number(idadi || 0) *
Number(bei_kununua || 0);

db.run(
`
INSERT INTO order_items(

id,
order_id,
bidhaa_jina,
idadi,
bei_kununua,
jumla,
created_at,
updated_at,
deleted,
synced

)

VALUES(
?,?,?,?,?,?,?,?,0,0
)
`,
[
uuidv4(),
order_id,
bidhaa_jina,
idadi,
bei_kununua,
jumla,
new Date().toISOString(),
new Date().toISOString()
],
(err)=>{

if(err){

return res.status(500).json({
success:false
});

}

db.get(
"SELECT jumla_order, kiasi_kilicholipwa FROM orders WHERE id = ?",
[order_id],
(err, order) => {

if(err || !order){
return res.json({ success:true });
}

const newJumla = Number(order.jumla_order || 0) + jumla;
const paid = Number(order.kiasi_kilicholipwa || 0);
const newBaki = Math.max(0, newJumla - paid);
const status = newBaki <= 0 ? "PAID" : "DENI";

db.run(
`
UPDATE orders

SET
jumla_order = ?,
kiasi_baki = ?,
status = ?,
updated_at = ?

WHERE id = ?
`,
[
newJumla,
newBaki,
status,
new Date().toISOString(),
order_id
]
);

res.json({
success:true,
jumla_order: newJumla,
kiasi_baki: newBaki,
status
});

}
);

});

});

/* =========================
DELETE ORDER
========================= */

router.delete("/:id",(req,res)=>{

db.run(
`
UPDATE orders

SET
deleted = 1,
updated_at = ?

WHERE id = ?
`,
[
new Date().toISOString(),
req.params.id
],
function(err){

if(err){

return res.status(500).json({
success:false
});

}

res.json({
success:true
});

});

});

module.exports = router;