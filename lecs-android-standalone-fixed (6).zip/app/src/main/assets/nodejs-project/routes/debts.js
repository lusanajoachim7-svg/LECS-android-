const express = require("express");
const db = require("../database/db");

const router = express.Router();

/* =========================
GET OUTSTANDING CUSTOMER DEBTS
(Madeni Tunayodai — money customers owe us)
Used by customer_payments.html to populate the "pay debt" dropdown.
========================= */

router.get("/", (req, res) => {

    const search = req.query.search || "";

    db.all(
        `
        SELECT *
        FROM madeni_kudai
        WHERE deleted = 0
        AND status = 'DENI'
        AND mteja_jina LIKE ?
        ORDER BY created_at DESC
        `,
        [`%${search}%`],
        (err, rows) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Database Error"
                });
            }

            res.json(rows);

        }
    );

});

/* =========================
ALL CUSTOMER DEBTS (paid + unpaid), for reporting/history
========================= */

router.get("/all", (req, res) => {

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const offset = (page - 1) * limit;

    db.all(
        `
        SELECT *
        FROM madeni_kudai
        WHERE deleted = 0
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?
        `,
        [limit, offset],
        (err, rows) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            db.get(
                "SELECT COUNT(*) total FROM madeni_kudai WHERE deleted = 0",
                [],
                (err, count) => {

                    if (err) {
                        return res.status(500).json({ success: false });
                    }

                    res.json({
                        success: true,
                        data: rows,
                        currentPage: page,
                        totalRows: count.total,
                        totalPages: Math.ceil(count.total / limit)
                    });

                }
            );

        }
    );

});

/* =========================
DEBT STATS
========================= */

router.get("/stats/summary", (req, res) => {

    db.get(
        `
        SELECT
        COUNT(*) total_debts,
        IFNULL(SUM(kiasi_baki), 0) total_outstanding
        FROM madeni_kudai
        WHERE deleted = 0
        AND status = 'DENI'
        `,
        [],
        (err, row) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json(row);

        }
    );

});

/* =========================
DETAILED CUSTOMER DEBTS (name, goods, date, paid, unpaid)
Powers the combined debts + inline payment screen.
========================= */

router.get("/detailed", (req, res) => {

    const search = req.query.search || "";
    const onlyUnpaid = req.query.onlyUnpaid === "1";

    db.all(
        `
        SELECT
        madeni_kudai.id,
        madeni_kudai.mteja_jina,
        madeni_kudai.kiasi_asili,
        madeni_kudai.kiasi_kilicholipwa,
        madeni_kudai.kiasi_baki,
        madeni_kudai.status,
        madeni_kudai.created_at,
        bidhaa.jina AS bidhaa_jina,
        mauzo.idadi AS idadi
        FROM madeni_kudai
        LEFT JOIN mauzo ON mauzo.id = madeni_kudai.mauzo_id
        LEFT JOIN bidhaa ON bidhaa.id = mauzo.bidhaa_id
        WHERE madeni_kudai.deleted = 0
        AND madeni_kudai.mteja_jina LIKE ?
        ${onlyUnpaid ? "AND madeni_kudai.status = 'DENI'" : ""}
        ORDER BY madeni_kudai.created_at DESC
        `,
        [`%${search}%`],
        (err, rows) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Database Error"
                });
            }

            res.json({ success: true, data: rows });

        }
    );

});

module.exports = router;
