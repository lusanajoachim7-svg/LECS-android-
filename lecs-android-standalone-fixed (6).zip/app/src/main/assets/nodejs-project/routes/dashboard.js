const express = require("express");
const db = require("../database/db");
const { startOfTodayUTC, startOfWeekUTC, daysAgoStartUTC, localDateLabel, todayLocalWeekday } = require("../utils/localDate");

const router = express.Router();

/* HELPERS */

function get(sql, params = []) {
return new Promise((resolve, reject) => {
db.get(sql, params, (err, row) => {
if (err) reject(err);
else resolve(row);
});
});
}

function all(sql, params = []) {
return new Promise((resolve, reject) => {
db.all(sql, params, (err, rows) => {
if (err) reject(err);
else resolve(rows);
});
});
}

/* DASHBOARD */

router.get("/", async (req, res) => {

try {

    const mauzoYote = await get(`
        SELECT COALESCE(SUM(jumla),0) total
        FROM mauzo
        WHERE deleted = 0
    `);

    const mauzoLeo = await get(
        `SELECT COALESCE(SUM(jumla),0) total
         FROM mauzo
         WHERE deleted = 0
         AND created_at >= ?`,
        [startOfTodayUTC()]
    );

    const totalStock = await get(`
        SELECT COALESCE(SUM(idadi),0) total
        FROM bidhaa
        WHERE deleted = 0
    `);

    const stockValue = await get(`
        SELECT COALESCE(
            SUM(idadi * bei_kununua),0
        ) total
        FROM bidhaa
        WHERE deleted = 0
    `);

    const lowStock = await get(`
        SELECT COUNT(*) total
        FROM bidhaa
        WHERE deleted = 0
        AND idadi > 0
        AND idadi <= 5
    `);

    const outOfStock = await get(`
        SELECT COUNT(*) total
        FROM bidhaa
        WHERE deleted = 0
        AND idadi <= 0
    `);

    const faidaWiki = await get(
        `SELECT COALESCE(SUM(faida_halisi),0) total
         FROM mauzo
         WHERE deleted = 0
         AND created_at >= ?`,
        [daysAgoStartUTC(6)]
    );

    const faidaLeo = await get(
        `SELECT COALESCE(SUM(faida_halisi),0) total
         FROM mauzo
         WHERE deleted = 0
         AND created_at >= ?`,
        [startOfTodayUTC()]
    );

    const madeniTunadai = await get(`
        SELECT COALESCE(
            SUM(kiasi_baki),0
        ) total
        FROM madeni_kudai
        WHERE deleted = 0
        AND status='DENI'
    `);

    const madeniTunadaiwa = await get(`
        SELECT COALESCE(
            SUM(kiasi_baki),0
        ) total
        FROM orders
        WHERE deleted = 0
        AND status='DENI'
    `);

    // Zaka/Sadaka week: Sunday morning through Friday — accumulates
    // day by day across the week. Saturday is a rest day: the card
    // simply shows 0 all day, then Sunday morning starts a fresh
    // week's count from zero again. Nothing is ever deleted — every
    // sale's actual zaka (10% of profit) and sadaka (10% of profit)
    // values stay in the mauzo table forever; this only changes what
    // this one dashboard card displays.
    const todayWeekday = todayLocalWeekday(); // 0=Sunday ... 6=Saturday

    let zakaSadaka;

    if (todayWeekday === 6) {
        zakaSadaka = { total: 0 };
    } else {
        zakaSadaka = await get(
            `SELECT COALESCE(SUM(zaka + sadaka),0) total
             FROM mauzo
             WHERE deleted = 0
             AND created_at >= ?`,
            [startOfWeekUTC()]
        );
    }

    const totalProducts = await get(`
        SELECT COUNT(*) total
        FROM bidhaa
        WHERE deleted = 0
    `);

    const totalCustomers = await get(`
        SELECT COUNT(*) total
        FROM customers
        WHERE deleted = 0
    `);

    const totalSuppliers = await get(`
        SELECT COUNT(*) total
        FROM suppliers
        WHERE deleted = 0
    `);

    const salesChartRaw = await all(
        `SELECT created_at, jumla
         FROM mauzo
         WHERE deleted = 0
         AND created_at >= ?
         ORDER BY created_at ASC`,
        [daysAgoStartUTC(6)]
    );

    const salesChartMap = {};
    salesChartRaw.forEach(row => {
        const label = localDateLabel(row.created_at);
        salesChartMap[label] = (salesChartMap[label] || 0) + Number(row.jumla || 0);
    });
    const salesChart = Object.keys(salesChartMap).sort().map(date => ({ date, total: salesChartMap[date] }));

    res.json({

        success: true,

        mauzoYote: mauzoYote.total,
        mauzoLeo: mauzoLeo.total,

        totalStock: totalStock.total,
        stockValue: stockValue.total,

        lowStock: lowStock.total,
        outOfStock: outOfStock.total,

        faidaWiki: faidaWiki.total,
        faidaLeo: faidaLeo.total,

        madeniTunadai: madeniTunadai.total,
        madeniTunadaiwa: madeniTunadaiwa.total,

        zakaSadaka: zakaSadaka.total,

        totalProducts: totalProducts.total,
        totalCustomers: totalCustomers.total,
        totalSuppliers: totalSuppliers.total,

        salesChart

    });

} catch (err) {

    console.error(err);

    res.status(500).json({
        success: false,
        message: "Dashboard Error"
    });

}

});

module.exports = router;