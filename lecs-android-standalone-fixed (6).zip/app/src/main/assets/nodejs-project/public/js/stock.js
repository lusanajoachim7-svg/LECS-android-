let currentPage = 1;
let totalPages = 1;
let currentUserRole = null;

/* =====================
CURRENT USER / ROLE
===================== */

async function loadCurrentUser(){

try{

const res = await fetch("/api/auth/me");
const data = await res.json();

if(data.success && data.user){
currentUserRole = data.user.role;
}

}catch(err){
console.error(err);
}

}

/* =====================
LOAD SUPPLIERS
===================== */

async function loadSuppliers(){

try{

const res =
await fetch("/api/suppliers");

const result =
await res.json();

const suppliers =
result.data || result;

const select =
document.getElementById("supplier");

if(!select) return;

select.innerHTML =
'<option value="">Chagua Supplier</option>';

suppliers.forEach(item=>{

select.innerHTML += `

<option value="${item.id}">
${item.jina}
</option>
`;});

}catch(err){

console.error(err);

}

}

/* =====================
LOAD PRODUCTS
===================== */

async function loadProducts(){

try{

const search =
document.getElementById("search")
? document.getElementById("search").value
: "";

const res =
await fetch(
`/api/bidhaa?page=${currentPage}&limit=20&search=${encodeURIComponent(search)}`
);

const result =
await res.json();

const table =
document.getElementById("stockTable");

if(!table) return;

table.innerHTML = "";

result.data.forEach(item=>{

const row =
document.createElement("tr");

if(Number(item.idadi) <= 2){

row.classList.add("low-stock");

}

row.innerHTML = `

<td>${item.jina}</td><td>${item.idadi}</td><td>${Number(item.bei_kununua || 0).toLocaleString()}</td><td>
${item.idadi <= 2
? "🔴 LOW"
: "🟢 OK"}
</td><td>
${
currentUserRole === "admin"
? `<button class="delete-btn" onclick="deleteProduct('${item.id}')">Delete</button>`
: ""
}
</td>
`;table.appendChild(row);

});

totalPages =
result.totalPages || 1;

const pageInfo =
document.getElementById("pageInfo");

if(pageInfo){

pageInfo.innerText =
`Page ${currentPage} of ${totalPages}`;

}

}catch(err){

console.error(err);

}

}

/* =====================
ADD PRODUCT
===================== */

async function ongezaBidhaa(){

try{

const body = {

jina:
document.getElementById("jina").value.trim(),

idadi:
Number(
document.getElementById("idadi").value
),

bei_kununua:
Number(
document.getElementById("bei").value
),

barcode:
document.getElementById("barcode").value.trim(),

supplier_id:
document.getElementById("supplier").value

};

if(!body.jina){

alert("Weka jina la bidhaa");

return;

}

const res =
await fetch(
"/api/bidhaa",
{
method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify(body)
}
);

const data =
await res.json();

if(data.success === false){

alert(data.message);

return;

}

document.getElementById("jina").value = "";
document.getElementById("idadi").value = "";
document.getElementById("bei").value = "";
document.getElementById("barcode").value = "";

loadProducts();

}catch(err){

console.error(err);

alert("Tatizo la mfumo");

}

}

/* =====================
DELETE PRODUCT
===================== */

async function deleteProduct(id){

if(
!confirm(
"Una uhakika unataka kufuta bidhaa?"
)
){
return;
}

try{

const res = await fetch(
"/api/bidhaa/" + id,
{
method:"DELETE"
}
);

const data = await res.json().catch(() => ({}));

if(!res.ok || data.success === false){
alert(data.message || "Imeshindikana kufuta bidhaa (session au mtandao). Jaribu tena.");
return;
}

loadProducts();

}catch(err){

console.error(err);
alert("Imeshindikana kufuta bidhaa: " + err.message);

}

}

/* =====================
SEARCH
===================== */

function tafutaBidhaa(){

currentPage = 1;

loadProducts();

}

/* =====================
PAGINATION
===================== */

function nextPage(){

if(currentPage < totalPages){

currentPage++;

loadProducts();

}

}

function prevPage(){

if(currentPage > 1){

currentPage--;

loadProducts();

}

}

/* =====================
START
===================== */

document.addEventListener(
"DOMContentLoaded",
async ()=>{

await loadCurrentUser();

loadSuppliers();

loadProducts();

}
);