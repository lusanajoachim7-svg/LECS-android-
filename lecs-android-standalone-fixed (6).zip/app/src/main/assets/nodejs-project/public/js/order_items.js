let currentOrderId = null;
let currentSupplierId = null;

function fmt(n) {
    return Number(n || 0).toLocaleString("en-US");
}

async function loadSuppliers() {
    try {
        const res = await fetch("/api/orders/suppliers");
        const data = await res.json();
        const select = document.getElementById("supplier");
        select.innerHTML = "";
        data.forEach(item => {
            select.innerHTML += `<option value="${item.id}">${item.jina}</option>`;
        });
    } catch (err) {
        console.error(err);
    }
}

async function startOrder() {

    currentSupplierId = document.getElementById("supplier").value;

    if (!currentSupplierId) {
        alert("Chagua supplier kwanza.");
        return;
    }

    try {

        const res = await fetch("/api/orders", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                supplier_id: currentSupplierId,
                jumla_order: 0,
                kiasi_kilicholipwa: 0
            })
        });

        const data = await res.json();

        if (!res.ok || data.success === false || !data.id) {
            alert(data.message || "Imeshindikana kuanza order.");
            return;
        }

        currentOrderId = data.id;

        document.getElementById("startCard").style.display = "none";
        document.getElementById("orderArea").style.display = "block";

        updateSummary(0, 0, 0);

    } catch (err) {
        alert("Hitilafu: " + err.message);
    }

}

async function addItem() {

    const bidhaa_jina = document.getElementById("bidhaaJina").value.trim();
    const idadi = Number(document.getElementById("idadi").value || 0);
    const bei_kununua = Number(document.getElementById("beiKununua").value || 0);

    if (!bidhaa_jina || idadi <= 0 || bei_kununua <= 0) {
        alert("Jaza taarifa zote za bidhaa kwa usahihi.");
        return;
    }

    try {

        const res = await fetch("/api/orders/item", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                order_id: currentOrderId,
                bidhaa_jina,
                idadi,
                bei_kununua
            })
        });

        const data = await res.json();

        if (!res.ok || data.success === false) {
            alert(data.message || "Imeshindikana kuongeza bidhaa.");
            return;
        }

        document.getElementById("bidhaaJina").value = "";
        document.getElementById("idadi").value = "";
        document.getElementById("beiKununua").value = "";

        await loadItems();
        updateSummary(data.jumla_order, 0, data.kiasi_baki);

    } catch (err) {
        alert("Hitilafu: " + err.message);
    }

}

async function loadItems() {

    try {

        const res = await fetch("/api/orders/items/" + currentOrderId);
        const rows = await res.json();

        const tbody = document.getElementById("itemsTable");

        if (!Array.isArray(rows) || rows.length === 0) {
            tbody.innerHTML = `<tr><td colspan="4">Hakuna bidhaa bado</td></tr>`;
            return;
        }

        tbody.innerHTML = rows.map(r => `
            <tr>
                <td>${r.bidhaa_jina}</td>
                <td>${r.idadi}</td>
                <td>${fmt(r.bei_kununua)}</td>
                <td>${fmt(r.jumla)}</td>
            </tr>
        `).join("");

    } catch (err) {
        console.error(err);
    }

}

function updateSummary(total, paid, baki) {

    document.getElementById("sumTotal").innerText = fmt(total);
    document.getElementById("sumPaid").innerText = fmt(paid);
    document.getElementById("sumBaki").innerText = fmt(baki);

    document.getElementById("payCard").style.display = baki > 0 ? "block" : "none";

}

function fillFullPay() {
    const baki = Number(document.getElementById("sumBaki").innerText.replace(/,/g, ""));
    document.getElementById("payAmount").value = baki;
}

async function payOrder() {

    const amount = Number(document.getElementById("payAmount").value || 0);
    const resultEl = document.getElementById("payResult");

    if (amount <= 0) {
        resultEl.innerText = "Weka kiasi sahihi.";
        return;
    }

    try {

        const res = await fetch("/api/payments", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                supplier_id: currentSupplierId,
                order_id: currentOrderId,
                kiasi: amount
            })
        });

        const data = await res.json();

        if (!res.ok || data.success === false) {
            resultEl.innerText = data.message || "Malipo yameshindikana.";
            return;
        }

        resultEl.innerText = "✅ Malipo yamefanikiwa.";
        document.getElementById("payAmount").value = "";

        updateSummary(
            data.jumla_order !== undefined ? data.jumla_order : document.getElementById("sumTotal").innerText.replace(/,/g, ""),
            data.kiasi_kilicholipwa,
            data.kiasi_baki
        );

    } catch (err) {
        resultEl.innerText = "Hitilafu: " + err.message;
    }

}

function resetScreen() {
    currentOrderId = null;
    currentSupplierId = null;
    document.getElementById("startCard").style.display = "block";
    document.getElementById("orderArea").style.display = "none";
    document.getElementById("itemsTable").innerHTML = `<tr><td colspan="4">Hakuna bidhaa bado</td></tr>`;
    document.getElementById("payResult").innerText = "";
    loadSuppliers();
}

document.addEventListener("DOMContentLoaded", loadSuppliers);
