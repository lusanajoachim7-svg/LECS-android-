async function loadCustomers(){

try{

const name =
document.getElementById("searchName").value || "";

const date =
document.getElementById("searchDate").value || "";

let url =
"/api/customers/purchases?";

if(name){
url += "name=" + encodeURIComponent(name) + "&";
}

if(date){
url += "date=" + encodeURIComponent(date);
}

const res = await fetch(url);

const data = await res.json();

document.getElementById(
"totalCustomers"
).innerText = data.length;

const list =
document.getElementById(
"customerTable"
);

if(!Array.isArray(data) || data.length === 0){

list.innerHTML = `<div class="empty-state">Hakuna taarifa zilizopatikana</div>`;
return;

}

list.innerHTML = data.map(row => {

const jumla = Number(row.jumla || 0);
const paid = Number(row.kiasi_kilicholipwa || 0);
const baki = Number(row.baki !== undefined ? row.baki : (jumla - paid));

return `
<div class="customer-card ${baki > 0 ? 'has-debt' : ''}">
    <div class="customer-row-top">
        <strong>${escapeHtml(row.mteja_jina || "Haijulikani")}</strong>
        <span class="customer-date">${new Date(row.created_at).toLocaleDateString("sw-TZ", {year:"numeric",month:"short",day:"numeric"})}</span>
    </div>
    <div class="customer-goods">🛒 ${escapeHtml(row.bidhaa || "-")}</div>
    <div class="customer-amounts">
        <div><span>Jumla</span><strong>${jumla.toLocaleString()}</strong></div>
        <div><span>Alilipa</span><strong>${paid.toLocaleString()}</strong></div>
        <div class="${baki > 0 ? 'unpaid' : ''}"><span>Deni</span><strong>${baki.toLocaleString()}</strong></div>
    </div>
</div>
`;

}).join("");

}catch(err){

console.error(err);

document.getElementById(
"customerTable"
).innerHTML = `<div class="empty-state">Imeshindikana kupakia taarifa</div>`;

}

}

function escapeHtml(s){
return String(s || "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

document.addEventListener(
"DOMContentLoaded",
()=>{

const today =
new Date()
.toISOString()
.split("T")[0];

document.getElementById(
"searchDate"
).value = today;

loadCustomers();

document
.getElementById("searchName")
.addEventListener(
"keyup",
loadCustomers
);

document
.getElementById("searchDate")
.addEventListener(
"change",
loadCustomers
);

}
);